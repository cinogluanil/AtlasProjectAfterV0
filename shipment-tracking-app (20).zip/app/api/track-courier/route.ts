import { type NextRequest, NextResponse } from "next/server"

interface TrackingResponse {
  status: string
  statusDescription: string
  lastUpdate: string
  location?: string
  estimatedDelivery?: string
  estimatedArrival?: string
  vessel?: string
  events?: Array<{
    status: string
    location: string
    timestamp: string
    description: string
  }>
}

const courierCodeMap: Record<string, string[]> = {
  dhl: ["dhl"],
  ups: ["ups"],
  fedex: ["fedex"],
  aramex: ["aramex"],
  "yurtici kargo": ["yurtici-kargo"],
  "mng kargo": ["mng-kargo"],
  "aras kargo": ["aras-kargo"],
  "ptt kargo": ["ptt-kargo"],
  tnt: ["tnt"],
  usps: ["usps"],
}

const shippingLineCodeMap: Record<string, string[]> = {
  maersk: ["maersk"],
  msc: ["msc"],
  "cma cgm": ["cma-cgm"],
  "hapag-lloyd": ["hapag-lloyd"],
  cosco: ["cosco"],
  evergreen: ["evergreen"],
  one: ["one"],
  "yang ming": ["yang-ming"],
  hyundai: ["hmm"],
  zim: ["zim"],
}

function getCourierCodes(courierCompany: string): string[] {
  const lowerCourier = courierCompany.toLowerCase()
  for (const [key, codes] of Object.entries(courierCodeMap)) {
    if (lowerCourier.includes(key)) {
      return codes
    }
  }
  return [lowerCourier.replace(/\s+/g, "-")]
}

function getShippingLineCodes(shippingLine: string): string[] {
  const lowerLine = shippingLine.toLowerCase()
  for (const [key, codes] of Object.entries(shippingLineCodeMap)) {
    if (lowerLine.includes(key)) {
      return codes
    }
  }
  return [lowerLine.replace(/\s+/g, "-")]
}

async function trackWithShip24(
  carrier: string,
  trackingNumber: string,
  isContainer = false,
  shippingDate?: string,
  destinationCountryCode?: string,
): Promise<TrackingResponse> {
  const apiKey = process.env.SHIP24_API_KEY

  if (!apiKey) {
    throw new Error(
      "Ship24 API key not found. Please add the SHIP24_API_KEY environment variable. You can get a free API key from Ship24: https://ship24.com",
    )
  }

  const cleanTrackingNumber = trackingNumber.replace(/\s+/g, "")
  console.log(
    `[v0] Ship24: Tracking ${isContainer ? "container" : "courier"}`,
    cleanTrackingNumber,
    "with carrier",
    carrier,
  )

  const courierCodes = isContainer ? getShippingLineCodes(carrier) : getCourierCodes(carrier)
  console.log("[v0] Ship24: Trying courier codes:", courierCodes)

  const requestBody: any = {
    trackingNumber: cleanTrackingNumber,
    courierCode: courierCodes,
  }

  if (shippingDate) {
    requestBody.shippingDate = shippingDate
  }

  if (destinationCountryCode) {
    requestBody.destinationCountryCode = destinationCountryCode
  }

  console.log("[v0] Ship24: Request body:", JSON.stringify(requestBody))

  const response = await fetch("https://api.ship24.com/public/v1/trackers/track", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(requestBody),
  })

  console.log("[v0] Ship24 response status:", response.status)

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}))
    console.error("[v0] Ship24 error:", errorData)

    if (response.status === 401) {
      throw new Error("Ship24 API key invalid. Please check your API key or create a new one: https://ship24.com")
    }

    if (response.status === 429) {
      throw new Error("Ship24 API rate limit exceeded. Please try again later.")
    }

    const errorMessage = errorData.errors?.[0]?.message || errorData.message || response.statusText
    throw new Error(
      `Ship24 API error: ${errorMessage}. Tracking number or ${isContainer ? "shipping line" : "courier"} information may be incorrect.`,
    )
  }

  const data = await response.json()
  console.log("[v0] Ship24 response:", JSON.stringify(data).substring(0, 500))

  const trackings = data.data?.trackings || []

  if (trackings.length === 0) {
    throw new Error(
      `${isContainer ? "Container" : "Tracking"} number "${trackingNumber}" not found. ${isContainer ? "Container" : "Shipment"} may not be in the system yet.`,
    )
  }

  const latestTracking = trackings[0]
  const shipment = latestTracking.shipment || {}
  const events = latestTracking.events || []
  const latestEvent = events[0]

  console.log("[v0] Ship24 shipment.delivery object:", JSON.stringify(shipment.delivery, null, 2))
  console.log("[v0] Ship24 full shipment object keys:", Object.keys(shipment))

  const deliveredEvent = events.find(
    (event: any) =>
      event.statusMilestone === "delivered" ||
      event.status === "delivered" ||
      (event.statusDescription || "").toLowerCase().includes("delivered"),
  )

  const actualDeliveryDate = deliveredEvent?.datetime || deliveredEvent?.occurrenceDatetime || null
  console.log("[v0] Ship24 found delivered event:", deliveredEvent ? "YES" : "NO")
  console.log("[v0] Ship24 actual delivery date:", actualDeliveryDate)

  const estimatedDelivery =
    shipment.delivery?.estimatedDeliveryDate || shipment.delivery?.estimated || shipment.estimatedDeliveryDate || null

  console.log("[v0] Ship24 extracted estimatedDelivery:", estimatedDelivery)

  let statusMilestone = shipment.statusMilestone || "unknown"
  if (deliveredEvent && !statusMilestone.includes("delivered")) {
    console.log("[v0] Ship24 overriding status to delivered based on events")
    statusMilestone = "delivered"
  }

  const statusMap: Record<string, { status: string; description: string }> = {
    info_received: { status: "pending", description: "Info Received" },
    in_transit: { status: "in_transit", description: isContainer ? "At Sea" : "In Transit" },
    out_for_delivery: { status: "out_for_delivery", description: "Out for Delivery" },
    delivered: { status: "delivered", description: "Delivered" },
    available_for_pickup: { status: "out_for_delivery", description: "Available for Pickup" },
    exception: { status: "pending", description: "Issue" },
    expired: { status: "pending", description: "Expired" },
    unknown: { status: "pending", description: "Unknown" },
  }

  const statusInfo = statusMap[statusMilestone] || {
    status: "pending",
    description: statusMilestone || "Unknown",
  }

  return {
    status: statusInfo.status,
    statusDescription: statusInfo.description,
    lastUpdate: latestEvent?.datetime || shipment.updatedAt || new Date().toISOString(),
    location: latestEvent?.location || shipment.originCountryCode || "",
    estimatedDelivery: actualDeliveryDate || estimatedDelivery,
    estimatedArrival: actualDeliveryDate || estimatedDelivery,
    vessel: shipment.vessel?.name,
    events: events.map((event: any) => ({
      status: event.statusMilestone || event.status || "info",
      location: event.location || "",
      timestamp: event.datetime || event.occurrenceDatetime || "",
      description: event.statusDescription || event.description || event.status || "",
    })),
  }
}

export async function POST(request: NextRequest) {
  try {
    const { carrier, trackingNumber, isContainer, shippingDate, destinationCountryCode } = await request.json()

    if (!carrier || !trackingNumber) {
      return NextResponse.json(
        { error: `${isContainer ? "Shipping line" : "Courier"} and tracking number required` },
        { status: 400 },
      )
    }

    const trackingData = await trackWithShip24(
      carrier,
      trackingNumber,
      isContainer,
      shippingDate,
      destinationCountryCode,
    )

    return NextResponse.json(trackingData)
  } catch (error) {
    console.error("[v0] Tracking error:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Could not retrieve tracking information" },
      { status: 500 },
    )
  }
}
