import { put, head } from "@vercel/blob"
import { NextResponse } from "next/server"
import type { Shipment } from "@/lib/types"

const SHIPMENTS_BLOB_PATH = "data/shipments.json"

async function getShipmentsFromBlob(): Promise<Shipment[]> {
  try {
    const blobData = await head(SHIPMENTS_BLOB_PATH)
    if (!blobData) return []

    const response = await fetch(blobData.url)
    const data = await response.json()
    return data
  } catch (error) {
    console.log("[v0] No existing shipments data, returning empty array")
    return []
  }
}

export async function GET() {
  try {
    const shipments = await getShipmentsFromBlob()
    return NextResponse.json(shipments)
  } catch (error) {
    console.error("[v0] Error fetching shipments:", error)
    return NextResponse.json([], { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { action, shipment, id, updates } = body

    let shipments = await getShipmentsFromBlob()

    switch (action) {
      case "add":
        shipments.push(shipment)
        break
      case "update":
        const index = shipments.findIndex((s) => s.id === id)
        if (index !== -1) {
          shipments[index] = { ...shipments[index], ...updates }
        }
        break
      case "delete":
        shipments = shipments.filter((s) => s.id !== id)
        break
      default:
        return NextResponse.json({ error: "Invalid action" }, { status: 400 })
    }

    // Save to Blob
    const blob = await put(SHIPMENTS_BLOB_PATH, JSON.stringify(shipments), {
      access: "public",
      contentType: "application/json",
    })

    return NextResponse.json({ success: true, url: blob.url })
  } catch (error) {
    console.error("[v0] Error updating shipments:", error)
    return NextResponse.json({ error: "Failed to update shipments" }, { status: 500 })
  }
}
