import { put, head } from "@vercel/blob"
import { NextResponse } from "next/server"

const METADATA_BLOB_PATH = "data/metadata.json"

interface Metadata {
  supplier: string[]
  carriers: string[]
  companies: { id: string; name: string }[]
  countries: string[]
}

const DEFAULT_METADATA: Metadata = {
  supplier: [
    "SG Agro",
    "Horchani Dattes",
    "Al-Tahhan Golden Dates",
    "Namagro",
    "Arab African Trading Center",
    "Emirates Delight",
    "Tan Long",
    "Hadiklaim",
    "Mazaya for Dates",
    "Abu Jaber",
    "Nakheel Palestine",
    "Linah Farms",
    "Hangjinhouqi Yongtaifeng",
    "SHARIKAT MAZARE FALASTEEN LETOMOUR ALMEJOUL",
    "Minerva",
    "Select Harvest",
    "Rpac LLC",
    "Baoqing County Jinxingyuan",
    "Alraeed Dates",
    "Richcom",
    "Inner Mongolia Hongxing Industry",
    "Summit Almonds",
    "Baoqing Huabao",
    "Inner Mongolia Li Niuniu Food",
    "Inner Mongolia Kexin Foods",
    "Al Rawan",
    "Rova El Zaher",
    "ATACAMA DRIED FRUIT SPA",
    "LAMICO",
    "Baoqing Xingda",
    "Hanfimex",
    "Sheng Feng",
    "Bayannaoer Long Xing",
    "Inner Mongolia Aodong Trading",
    "HANGJINHOUQI CHANGSHI FOOD CO.,LTD",
    "Calbu",
    "Goodvalley",
    "SVC",
    "Al-Ghazal Dates Co.",
    "Al Yasmin For Import And Export",
    "LongSon",
    "Chris",
    "Al Kotof",
    "Prosi",
    "Palm Hills",
    "Pal Gardens",
    "Gastaldi",
    "Edekhar for agricultural investment",
    "Valency",
    "Vinapro",
    "Pacific",
    "Afri Ventures",
    "N.B AGRI",
    "Atlas",
    "KINGLAND CO.,LTD",
    "DALIAN HAPPY FARM NATURAL PRODUCTS CO.,LTD.",
    "HANGJINHOUQI XINGLONG AGRICULTURAL TRADE CO LTD",
  ],
  carriers: [
    "Maersk",
    "CMA CGM",
    "MSC",
    "COSCO",
    "Hapag-Lloyd",
    "Evergreen",
    "ONE",
    "Yang Ming",
    "HMM",
    "Arkas",
    "ZIM",
  ],
  companies: [
    { id: "c1", name: "Antik Kuruyemiş" },
    { id: "c2", name: "Emir Nuts" },
    { id: "c3", name: "Asya Pasifik" },
    { id: "c4", name: "Atlas Agro" },
    { id: "c5", name: "Antik Global" },
  ],
  countries: ["Vietnam", "USA", "Jordan", "China", "Israel", "Palestine", "Egypt"],
}

async function getMetadataFromBlob(): Promise<Metadata> {
  try {
    const blobData = await head(METADATA_BLOB_PATH)
    if (!blobData) return DEFAULT_METADATA

    const response = await fetch(blobData.url)
    const data = await response.json()
    return data
  } catch (error) {
    console.log("[v0] No existing metadata, returning defaults")
    return DEFAULT_METADATA
  }
}

export async function GET() {
  try {
    const metadata = await getMetadataFromBlob()
    return NextResponse.json(metadata)
  } catch (error) {
    console.error("[v0] Error fetching metadata:", error)
    return NextResponse.json(DEFAULT_METADATA, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { action, type, value } = body

    const metadata = await getMetadataFromBlob()

    if (action === "add") {
      if (type === "supplier" && !metadata.supplier.includes(value)) {
        metadata.supplier.push(value)
      } else if (type === "carrier" && !metadata.carriers.includes(value)) {
        metadata.carriers.push(value)
      }
    }

    // Save to Blob
    const blob = await put(METADATA_BLOB_PATH, JSON.stringify(metadata), {
      access: "public",
      contentType: "application/json",
    })

    return NextResponse.json({ success: true, url: blob.url })
  } catch (error) {
    console.error("[v0] Error updating metadata:", error)
    return NextResponse.json({ error: "Failed to update metadata" }, { status: 500 })
  }
}
