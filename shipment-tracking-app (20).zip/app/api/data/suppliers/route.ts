import { put, head } from "@vercel/blob"
import { NextResponse } from "next/server"
import type { Supplier } from "@/lib/types"

const SUPPLIERS_BLOB_PATH = "data/suppliers.json"

async function getSuppliersFromBlob(): Promise<Supplier[]> {
  try {
    const blobData = await head(SUPPLIERS_BLOB_PATH)
    if (!blobData) return []

    const response = await fetch(blobData.url)
    const data = await response.json()
    return data
  } catch (error) {
    console.log("[v0] No existing suppliers data, returning empty array")
    return []
  }
}

export async function GET() {
  try {
    const suppliers = await getSuppliersFromBlob()
    return NextResponse.json(suppliers)
  } catch (error) {
    console.error("[v0] Error fetching suppliers:", error)
    return NextResponse.json([], { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { action, supplier, id, updates } = body

    let suppliers = await getSuppliersFromBlob()

    switch (action) {
      case "add":
        suppliers.push(supplier)
        break
      case "update":
        const index = suppliers.findIndex((s) => s.id === id)
        if (index !== -1) {
          suppliers[index] = { ...suppliers[index], ...updates }
        }
        break
      case "delete":
        suppliers = suppliers.filter((s) => s.id !== id)
        break
      default:
        return NextResponse.json({ error: "Invalid action" }, { status: 400 })
    }

    // Save to Blob
    const blob = await put(SUPPLIERS_BLOB_PATH, JSON.stringify(suppliers), {
      access: "public",
      contentType: "application/json",
    })

    return NextResponse.json({ success: true, url: blob.url })
  } catch (error) {
    console.error("[v0] Error updating suppliers:", error)
    return NextResponse.json({ error: "Failed to update suppliers" }, { status: 500 })
  }
}
