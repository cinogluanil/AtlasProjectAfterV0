"use client"

import { useState, useMemo, useEffect } from "react"
import type { Supplier, Shipment, Note, ShippingLine } from "@/lib/types"
import { useSuppliers, useShipments, useMetadata, useShippingLines } from "@/hooks/use-store"
import { SupplierForm } from "@/components/supplier-form"
import { SuppliersTable } from "@/components/suppliers-table"
import { ShipmentForm } from "@/components/shipment-form"
import { ShipmentsTable } from "@/components/shipments-table"
import { ShippingLineForm } from "@/components/shipping-line-form"
import { ShippingLinesTable } from "@/components/shipping-lines-table"
import { DocumentUpload } from "@/components/document-upload"
import { LocalBackupBar } from "@/components/local-backup-bar"
import { Button } from "@/components/ui/button"
import { Card, CardHeader, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Menu,
  X,
  Package,
  CheckCircle2,
  Search,
  Filter,
  Save,
  Trash2,
  MessageSquare,
  History,
  Download,
  Bell,
  Anchor,
  ExternalLink,
  Truck,
  CheckCheck,
} from "lucide-react"
import { store, normStatus } from "@/lib/store"
import { migrateStatuses } from "@/lib/migrateStatus"
import { DeleteConfirmationDialog } from "@/components/delete-confirmation-dialog"
import { RecycleBinTable } from "@/components/recycle-bin-table"

const SHOW_BL_CARD = false
const SHOW_STATUS_DISTRIBUTION = false

type View =
  | "dashboard"
  | "suppliers"
  | "supplier-form"
  | "shipments"
  | "shipment-form"
  | "shipment-detail"
  | "shipping-lines"
  | "recycle-bin"

interface SavedFilter {
  id: string
  name: string
  filters: {
    product?: string | null
    status?: string | null
    carrier?: string | null
    customer?: string | null
    dateRangeStart?: string
    dateRangeEnd?: string
  }
}

const formatDate = (date: Date | string | undefined): string => {
  if (!date) return ""
  try {
    const d = typeof date === "string" ? new Date(date) : date
    return d.toLocaleDateString("en-US")
  } catch {
    return ""
  }
}

// Helper function to get courier tracking URL
const getCourierTrackingUrl = (courierCompany: string | undefined, trackingNumber: string | undefined): string => {
  if (!courierCompany || !trackingNumber) return "#"

  const lowerCaseCourier = courierCompany.toLowerCase()

  if (lowerCaseCourier.includes("dhl")) {
    return `https://www.dhl.com/en/express/tracking.html?trackingid=${trackingNumber}`
  } else if (lowerCaseCourier.includes("ups")) {
    return `https://www.ups.com/track?tracknum=${trackingNumber}`
  } else if (lowerCaseCourier.includes("fedex")) {
    return `https://www.fedex.com/apps/fedextrack/?tracknumbers=${trackingNumber}`
  } else if (lowerCaseCourier.includes("ups express")) {
    return `https://www.ups.com/track?tracknum=${trackingNumber}`
  } else if (lowerCaseCourier.includes("ups worldwide express")) {
    return `https://www.ups.com/track?tracknum=${trackingNumber}`
  } else if (lowerCaseCourier.includes("tnt")) {
    return `https://www.tnt.com/express/en_gb/site/tracking/track.html?searchType=CONNOTE&connote=${trackingNumber}`
  } else if (lowerCaseCourier.includes("fedex express")) {
    return `https://www.fedex.com/apps/fedextrack/?tracknumbers=${trackingNumber}`
  } else if (lowerCaseCourier.includes("fedex ground")) {
    return `https://www.fedex.com/apps/fedextrack/?tracknumbers=${trackingNumber}`
  } else if (lowerCaseCourier.includes("ups worldwide saver")) {
    return `https://www.ups.com/track?tracknum=${trackingNumber}`
  } else if (lowerCaseCourier.includes("ups worldwide expedited")) {
    return `https://www.ups.com/track?tracknum=${trackingNumber}`
  } else if (lowerCaseCourier.includes("yurtici kargo")) {
    return `https://www.yurticikargo.com/tr/online-takip/kargo-takip?kargono=${trackingNumber}`
  } else if (lowerCaseCourier.includes("mng kargo")) {
    return `https://mngkargo.com.tr/tr/gonderi-takip?kno=${trackingNumber}`
  } else if (lowerCaseCourier.includes("aras kargo")) {
    return `https://www.araskargo.com.tr/tr/online-takip?kargono=${trackingNumber}`
  } else if (lowerCaseCourier.includes("ptt kargo")) {
    return `https://gonderitakip.ptt.gov.tr/Home/GonderiDetay?kno=${trackingNumber}`
  } else {
    // Fallback for unknown couriers - could try a general search or prompt user
    return "#"
  }
}

export default function Home() {
  const { companies, tedarikciList, countries, carriers, reload: reloadMetadata } = useMetadata()
  const { suppliers, addSupplier, updateSupplier, deleteSupplier } = useSuppliers()

  const {
    shipments,
    addShipment,
    updateShipment,
    deleteShipment,
    getShipmentsBySupplier,
    softDeleteShipment,
    restoreShipment,
    permanentlyDeleteShipment,
    reload: reloadShipments, // Get reload function from hook
  } = useShipments()
  // </CHANGE>

  const { shippingLines, addShippingLine, updateShippingLine, deleteShippingLine } = useShippingLines()

  const [view, setView] = useState<View>("dashboard")
  const [editingSupplier, setEditingSupplier] = useState<Supplier | undefined>()
  const [editingShipment, setEditingShipment] = useState<Shipment | undefined>()
  const [editingShippingLine, setEditingShippingLine] = useState<ShippingLine | undefined>()
  const [selectedSupplier, setSelectedSupplier] = useState<Supplier | undefined>()
  const [selectedShipment, setSelectedShipment] = useState<Shipment | undefined>()

  const [selectedProduct, setSelectedProduct] = useState<string | null>(null)
  const [selectedStatus, setSelectedStatus] = useState<string | null>(null)
  const [selectedSupplierCountry, setSelectedSupplierCountry] = useState<string | null>(null)
  const [supplierSortOrder, setSupplierSortOrder] = useState<"asc" | "desc">("asc")
  const [supplierSearchQuery, setSupplierSearchQuery] = useState("")

  const [shipmentSearchQuery, setShipmentSearchQuery] = useState("")
  const [selectedCarrier, setSelectedCarrier] = useState<string | null>(null)
  const [selectedCustomer, setSelectedCustomer] = useState<string | null>(null)
  const [dateRangeStart, setDateRangeStart] = useState<string>("")
  const [dateRangeEnd, setDateRangeEnd] = useState<string>("")
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false)
  const [savedFilters, setSavedFilters] = useState<SavedFilter[]>([])
  const [filterName, setFilterName] = useState("")

  const [isEditingDetail, setIsEditingDetail] = useState(false)
  const [editedShipmentData, setEditedShipmentData] = useState<{
    status?: string
    ourOrderNumber?: string
    supplierOrderNumber?: string
    invoiceNumber?: string
    billOfLadingNumber?: string
    containerNumber?: string
    estimatedDepartureDate?: Date
    estimatedArrivalDate?: Date
    actualDelivery?: Date
    carrier?: string
    courierCompany?: string
    courierTrackingNumber?: string
  }>({})

  // Replace state variables for notes and delete confirmation with existing ones
  const [noteText, setNoteText] = useState("")

  const [selectedShipmentIds, setSelectedShipmentIds] = useState<string[]>([])
  const [bulkStatusChange, setBulkStatusChange] = useState<string>("")

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  const [isLoadingCourierTracking, setIsLoadingCourierTracking] = useState(false)

  // State for delete confirmation dialog
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [shipmentToDelete, setShipmentToDelete] = useState<string | null>(null)
  const [deletedShipments, setDeletedShipments] = useState<Shipment[]>([])

  // CHANGE: Replace container tracking with B/L tracking
  const shipmentsWithBL = shipments.filter((s) => s.carrier && s.billOfLadingNumber)

  // CHANGE: Helper function to generate shipping line tracking URL
  const getShippingLineTrackingUrl = (carrier: string, blNumber: string): string => {
    const carrierLower = carrier.toLowerCase()

    if (carrierLower.includes("maersk")) {
      return `https://www.maersk.com/tracking/${blNumber}`
    } else if (carrierLower.includes("msc")) {
      return `https://www.msc.com/track-a-shipment?agencyPath=msc&trackingNumber=${blNumber}`
    } else if (carrierLower.includes("cma") || carrierLower.includes("cgm")) {
      return `https://www.cma-cgm.com/ebusiness/tracking/search?SearchBy=BL&Reference=${blNumber}`
    } else if (carrierLower.includes("hapag")) {
      return `https://www.hapag-lloyd.com/en/online-business/track/track-by-booking-solution.html?blno=${blNumber}`
    } else if (carrierLower.includes("cosco")) {
      // FIX: Corrected the undeclared variable error here.
      return `https://elines.coscoshipping.com/ebusiness/cargoTracking?trackingType=BILL&number=${blNumber}`
    } else if (carrierLower.includes("evergreen")) {
      return `https://www.shipmentlink.com/servlet/TDB1_CargoTracking.do?blno=${blNumber}`
    } else if (carrierLower.includes("one")) {
      return `https://ecomm.one-line.com/ecom/CUP_HOM_3301.do?search_type=B&search_name=${blNumber}`
    }

    return "#"
  }

  // CHANGE: Remove container tracking functions
  // const handleFetchContainerTracking = async (shipment: Shipment) => { ... }
  // const handleUpdateAllContainerTracking = async () => { ... }

  const handleFetchCourierTracking = async (shipment: Shipment) => {
    if (!shipment.courierCompany || !shipment.courierTrackingNumber) {
      alert("Courier company and tracking number information is missing")
      return
    }

    setIsLoadingCourierTracking(true)

    try {
      const response = await fetch("/api/track-courier", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.JSON.stringify({
          carrier: shipment.courierCompany,
          trackingNumber: shipment.courierTrackingNumber,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Could not retrieve tracking information")
      }

      const trackingData = await response.json()

      const updatedShipment = {
        ...shipment,
        courierTrackingStatus: trackingData,
      }

      updateShipment(shipment.id, updatedShipment)
      if (selectedShipment?.id === shipment.id) {
        setSelectedShipment(updatedShipment)
      }

      alert("Shipment status updated!")
    } catch (error) {
      console.error("Tracking error:", error)
      alert(error instanceof Error ? error.message : "Could not retrieve tracking information")
    } finally {
      setIsLoadingCourierTracking(false)
    }
  }

  const handleUpdateAllCourierTracking = async () => {
    const courierShipments = shipments.filter((s) => s.courierCompany && s.courierTrackingNumber)

    if (courierShipments.length === 0) {
      alert("No shipments with tracking numbers found")
      return
    }

    setIsLoadingCourierTracking(true)

    let successCount = 0
    let errorCount = 0

    for (const shipment of courierShipments) {
      try {
        const response = await fetch("/api/track-courier", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            carrier: shipment.courierCompany,
            trackingNumber: shipment.courierTrackingNumber,
            isContainer: false,
            shippingDate: shipment.estimatedLoading
              ? new Date(shipment.estimatedLoading).toISOString().split("T")[0]
              : undefined,
            destinationCountryCode: "TR", // Shipments are coming to Turkey
          }),
        })

        if (!response.ok) {
          throw new Error("API error")
        }

        const trackingData = await response.json()

        updateShipment(shipment.id, {
          ...shipment,
          courierTrackingStatus: trackingData,
        })

        successCount++
      } catch (error) {
        console.error(`Error tracking ${shipment.courierTrackingNumber}:`, error)
        errorCount++
      }
    }

    setIsLoadingCourierTracking(false)
    alert(`${successCount} shipments updated${errorCount > 0 ? `, ${errorCount} shipments failed to update` : ""}`)
  }

  // CHANGE: Remove container tracking update function
  // const handleUpdateAllContainerTracking = async () => { ... }

  const handleStatusChange = (shipmentId: string, newStatus: Shipment["status"]) => {
    const shipment = shipments.find((s) => s.id === shipmentId)
    if (!shipment) return

    const statusHistory = shipment.statusHistory || []
    statusHistory.push({
      status: newStatus,
      changedAt: new Date(),
      changedBy: "User (Quick Change)",
    })

    updateShipment(shipmentId, {
      ...shipment,
      status: newStatus,
      statusHistory,
    })
  }

  // CHANGE: Removed redundant useEffect that was setting metadata - useMetadata hook handles this

  // CHANGE: Removed handleParsedShipment function

  const handleAddShipment = (shipmentData: Partial<Shipment>) => {
    if (editingShipment) {
      updateShipment(editingShipment.id, { ...editingShipment, ...shipmentData })
      setEditingShipment(undefined)
    } else {
      const newShipment: Shipment = {
        id: Date.now().toString(),
        supplier: shipmentData.supplier || "",
        product: shipmentData.product || "",
        firmaId: shipmentData.firmaId || companies[0]?.id || "",
        originCountry: shipmentData.originCountry || "",
        status: shipmentData.status || "toLoad", // Default status 'toLoad'
        estimatedLoading: shipmentData.estimatedLoading || new Date(),
        createdAt: new Date(),
        documents: shipmentData.documents || [],
        ...shipmentData, // Merge all provided data
      }
      addShipment(newShipment)
    }
    setView("shipments")
  }

  // import { normStatus } from "@/lib/store" // Already imported at the top

  const statusDistribution = useMemo(() => {
    if (!SHOW_STATUS_DISTRIBUTION) return []
    const distribution = [
      {
        name: "To Load",
        value: shipments.filter((s) => normStatus(s.status) === "toload").length,
        color: "#f59e0b",
      },
      {
        name: "On the Way",
        value: shipments.filter((s) => normStatus(s.status) === "ontheway").length,
        color: "#3b82f6",
      },
      { name: "Arrived", value: shipments.filter((s) => normStatus(s.status) === "arrived").length, color: "#10b981" },
      {
        name: "Import Completed",
        value: shipments.filter((s) => normStatus(s.status) === "completed").length,
        color: "#6b7280",
      },
    ]
    return distribution.filter((d) => d.value > 0)
  }, [shipments])

  const upcomingArrivals = useMemo(() => {
    const now = new Date()
    const sevenDaysFromNow = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000)

    return shipments
      .filter((s) => {
        if (!s.estimatedArrivalDate) return false
        const arrivalDate = new Date(s.estimatedArrivalDate)
        return arrivalDate >= now && arrivalDate <= sevenDaysFromNow && s.status !== "arrived"
      })
      .sort((a, b) => {
        const dateA = new Date(a.estimatedArrivalDate!).getTime()
        const dateB = new Date(b.estimatedArrivalDate!).getTime()
        return dateA - dateB
      })
  }, [shipments])

  const courierShipments = useMemo(() => {
    return shipments.filter((s) => s.courierCompany && s.courierTrackingNumber)
  }, [shipments])

  const transitShipments = useMemo(() => {
    const inTransitCard = (s: Shipment) => (s as any).isTransitSale === true
    const filtered = shipments.filter(inTransitCard)
    console.log("[v0] TRANSIT_SHIPMENTS", filtered.length)
    filtered.forEach((s, i) => {
      console.log(`[v0] TRANSIT_SHIP_${i}`, {
        id: s.id,
        status: s.status,
        isTransitSale: (s as any).isTransitSale,
        invoiceNo: s.invoiceNo || "N/A",
      })
    })
    return filtered
  }, [shipments])

  const onTheWayShipments = useMemo(() => {
    const inOnTheWayCard = (s: Shipment) => {
      const canon = normStatus(s.status)
      const isTransit = (s as any).isTransitSale === true
      return canon === "ontheway" && !isTransit
    }
    const filtered = shipments.filter(inOnTheWayCard)
    console.log("[v0] ON_THE_WAY_SHIPMENTS", filtered.length)

    const allOnTheWayStatus = shipments.filter((s) => normStatus(s.status) === "ontheway")
    console.log("[v0] ALL_ON_THE_WAY_STATUS_COUNT", allOnTheWayStatus.length)
    allOnTheWayStatus.forEach((s, i) => {
      console.log(`[v0] ON_THE_WAY_STATUS_${i}`, {
        id: s.id,
        status: s.status,
        isTransitSale: (s as any).isTransitSale,
        invoiceNo: s.invoiceNo || "N/A",
      })
    })

    return filtered
  }, [shipments])

  useEffect(() => {
    console.log("[v0] COUNTS", {
      transitCard: transitShipments.length,
      onTheWayCard: onTheWayShipments.length,
    })
  }, [transitShipments.length, onTheWayShipments.length])

  const displayedSuppliers = useMemo(() => {
    const existingSuppliers = suppliers

    const missingTedarikci = (Array.isArray(tedarikciList) ? tedarikciList : []).filter(
      (name) => !existingSuppliers.some((s) => s.name === name),
    )

    const placeholderSuppliers = missingTedarikci.map((name) => ({
      id: `placeholder-${name}`,
      name,
      email: "",
      phone: "",
      address: "",
      city: "",
      country: "",
      createdAt: new Date(),
    }))

    return [...existingSuppliers, ...placeholderSuppliers]
  }, [suppliers, tedarikciList])

  const [prefilledSupplierName, setPrefilledSupplierName] = useState<string | undefined>(undefined)
  const [prefilledCarrierName, setPrefilledCarrierName] = useState<string | undefined>(undefined)

  const handleAddSupplier = (supplier: Supplier) => {
    if (editingSupplier) {
      if (editingSupplier.id.startsWith("placeholder-")) {
        addSupplier(supplier)
      } else {
        updateSupplier(editingSupplier.id, supplier)
      }
      setEditingSupplier(undefined)
    } else {
      addSupplier(supplier)
    }
    setPrefilledSupplierName(undefined)
    setView("suppliers")
  }

  const handleEditSupplier = (supplier: Supplier) => {
    setEditingSupplier(supplier)
    setView("supplier-form")
  }

  const handleDeleteShipment = (id: string) => {
    setShipmentToDelete(id)
    setDeleteDialogOpen(true)
  }

  const confirmDelete = () => {
    if (shipmentToDelete) {
      softDeleteShipment(shipmentToDelete)
      setDeletedShipments(store.getDeletedShipments())
      setDeleteDialogOpen(false)
      setShipmentToDelete(null)
    }
  }
  // </CHANGE>

  const handleRestoreShipment = (id: string) => {
    restoreShipment(id)
    setDeletedShipments(store.getDeletedShipments())
  }
  // </CHANGE>

  const handlePermanentDelete = (id: string) => {
    if (confirm("Are you sure you want to permanently delete this shipment? This action cannot be undone.")) {
      permanentlyDeleteShipment(id)
      setDeletedShipments(store.getDeletedShipments())
    }
  }
  // </CHANGE>

  const handleDeleteSupplier = (id: string) => {
    if (window.confirm("Are you sure you want to delete this supplier?")) {
      deleteSupplier(id)
    }
  }

  const handleAddShippingLine = (shippingLine: ShippingLine) => {
    if (editingShippingLine) {
      updateShippingLine(editingShippingLine.id, shippingLine)
      setEditingShippingLine(undefined)
    } else {
      addShippingLine(shippingLine)
    }
    setPrefilledCarrierName(undefined)
    setView("shipping-lines")
  }

  const handleEditShippingLine = (shippingLine: ShippingLine) => {
    setEditingShippingLine(shippingLine)
    setView("shipping-line-form")
  }

  const handleDeleteShippingLine = (id: string) => {
    if (window.confirm("Are you sure you want to delete this shipping line?")) {
      deleteShippingLine(id)
    }
  }

  const handleUploadDocument = (shipmentId: string, document: any) => {
    const shipment = shipments.find((s) => s.id === shipmentId)
    if (shipment) {
      const updatedShipment = {
        ...shipment,
        documents: [...(shipment.documents || []), document],
      }
      updateShipment(shipmentId, updatedShipment)
      if (selectedShipment?.id === shipmentId) {
        setSelectedShipment(updatedShipment)
      }
    }
  }

  const handleDeleteDocument = (shipmentId: string, documentId: string) => {
    const shipment = shipments.find((s) => s.id === shipmentId)
    if (shipment) {
      const updatedShipment = {
        ...shipment,
        documents: (shipment.documents || []).filter((d) => d.id !== documentId),
      }
      updateShipment(shipmentId, updatedShipment)
      if (selectedShipment?.id === shipmentId) {
        setSelectedShipment(updatedShipment)
      }
    }
  }

  const supplierShipments = selectedSupplier
    ? selectedSupplier.id.startsWith("placeholder-")
      ? shipments.filter((s) => s.supplier === selectedSupplier.name)
      : getShipmentsBySupplier(selectedSupplier.id)
    : []

  const uniqueProducts = Array.from(new Set(shipments.map((s) => s.product))).sort()
  const statusOptions = [
    { value: "toload", label: "To Load" },
    { value: "ontheway", label: "On the Way" },
    { value: "arrived", label: "Arrived" },
    { value: "completed", label: "Import Completed" },
  ]

  const uniqueSupplierCountries = Array.from(new Set(displayedSuppliers.map((s) => s.country).filter(Boolean))).sort()

  const getFilteredAndSortedSuppliers = (baseSuppliers: Supplier[]) => {
    const filtered = baseSuppliers.filter((supplier) => {
      const matchesCountry = !selectedSupplierCountry || supplier.country === selectedSupplierCountry

      const searchableText = [
        supplier.name,
        supplier.email,
        supplier.phone,
        supplier.address,
        supplier.city,
        supplier.country,
      ]
        .filter(Boolean)
        .join(" ")
        .toLowerCase()

      const matchesSearch = !supplierSearchQuery || searchableText.includes(supplierSearchQuery.toLowerCase())

      return matchesCountry && matchesSearch
    })

    filtered.sort((a, b) => {
      const comparison = a.name.localeCompare(b.name, "tr-TR")
      return supplierSortOrder === "asc" ? comparison : -comparison
    })

    return filtered
  }

  const filteredAndSortedSuppliers = getFilteredAndSortedSuppliers(displayedSuppliers)

  const uniqueCarriers = useMemo(() => {
    return Array.from(new Set(shipments.map((s) => s.carrier).filter(Boolean))).sort()
  }, [shipments])

  const uniqueCustomers = useMemo(() => {
    return Array.from(new Set(shipments.map((s) => s.customer).filter(Boolean))).sort()
  }, [shipments])

  const getFilteredShipments = (baseShipments: Shipment[]) => {
    return baseShipments.filter((shipment) => {
      const matchesProduct = !selectedProduct || shipment.product === selectedProduct
      // Use canonical status value in filter
      const matchesStatus = !selectedStatus || normStatus(shipment.status) === selectedStatus

      const searchableText = [
        shipment.product,
        shipment.supplier,
        shipment.ourOrderNumber,
        shipment.supplierOrderNumber,
        shipment.invoiceNumber,
        shipment.billOfLadingNumber,
        shipment.carrier,
        shipment.customer,
      ]
        .filter(Boolean)
        .join(" ")
        .toLocaleLowerCase("tr-TR")

      const matchesSearch =
        !shipmentSearchQuery || searchableText.includes(shipmentSearchQuery.toLocaleLowerCase("tr-TR"))

      const matchesCarrier = !selectedCarrier || shipment.carrier === selectedCarrier
      const matchesCustomer = !selectedCustomer || shipment.customer === selectedCustomer

      let matchesDateRange = true
      if (dateRangeStart || dateRangeEnd) {
        if (shipment.estimatedArrivalDate) {
          const arrivalDate = new Date(shipment.estimatedArrivalDate)
          if (dateRangeStart) {
            matchesDateRange = matchesDateRange && arrivalDate >= new Date(dateRangeStart)
          }
          if (dateRangeEnd) {
            matchesDateRange = matchesDateRange && arrivalDate <= new Date(dateRangeEnd)
          }
        } else {
          matchesDateRange = false
        }
      }

      return matchesProduct && matchesStatus && matchesSearch && matchesCarrier && matchesCustomer && matchesDateRange
    })
  }

  const filteredShipments = getFilteredShipments(selectedSupplier ? supplierShipments : shipments)

  const handleSaveFilter = () => {
    if (!filterName.trim()) {
      alert("Please enter a name for the filter")
      return
    }

    const newFilter: SavedFilter = {
      id: Date.now().toString(),
      name: filterName,
      filters: {
        product: selectedProduct,
        status: selectedStatus,
        carrier: selectedCarrier,
        customer: selectedCustomer,
        dateRangeStart,
        dateRangeEnd,
      },
    }

    const updated = [...savedFilters, newFilter]
    setSavedFilters(updated)
    localStorage.setItem("savedFilters", JSON.JSON.stringify(updated))
    setFilterName("")
    alert("Filter saved!")
  }

  const handleLoadFilter = (filter: SavedFilter) => {
    setSelectedProduct(filter.filters.product || null)
    setSelectedStatus(filter.filters.status || null)
    setSelectedCarrier(filter.filters.carrier || null)
    setSelectedCustomer(filter.filters.customer || null)
    setDateRangeStart(filter.filters.dateRangeStart || "")
    setDateRangeEnd(filter.filters.dateRangeEnd || "")
  }

  const handleDeleteFilter = (filterId: string) => {
    const updated = savedFilters.filter((f) => f.id !== filterId)
    setSavedFilters(updated)
    localStorage.setItem("savedFilters", JSON.JSON.stringify(updated))
  }

  const handleClearFilters = () => {
    setSelectedProduct(null)
    setSelectedStatus(null)
    setSelectedCarrier(null)
    setSelectedCustomer(null)
    setDateRangeStart("")
    setDateRangeEnd("")
    setShipmentSearchQuery("")
  }

  const handleSaveShipmentDetail = () => {
    if (selectedShipment) {
      const updatedShipment = {
        ...selectedShipment,
        ...editedShipmentData,
      }

      if (editedShipmentData.status && editedShipmentData.status !== selectedShipment.status) {
        const statusHistory = selectedShipment.statusHistory || []
        statusHistory.push({
          status: editedShipmentData.status,
          changedAt: new Date(),
          changedBy: "User",
        })
        updatedShipment.statusHistory = statusHistory
      }

      updateShipment(selectedShipment.id, updatedShipment)
      setSelectedShipment(updatedShipment)
      setIsEditingDetail(false)
      setEditedShipmentData({})
    }
  }

  const handleCancelEdit = () => {
    setIsEditingDetail(false)
    setEditedShipmentData({})
  }

  const handleAddNote = () => {
    if (!selectedShipment || !noteText.trim()) return

    const newNote: Note = {
      id: Date.now().toString(),
      text: noteText,
      createdAt: new Date(),
      author: "User",
    }

    const updatedShipment = {
      ...selectedShipment,
      notes: [...(selectedShipment.notes || []), newNote],
    }

    updateShipment(selectedShipment.id, updatedShipment)
    setSelectedShipment(updatedShipment)
    setNoteText("")
  }

  const handleDeleteNote = (noteId: string) => {
    if (!selectedShipment) return

    const updatedShipment = {
      ...selectedShipment,
      notes: (selectedShipment.notes || []).filter((n) => n.id !== noteId),
    }

    updateShipment(selectedShipment.id, updatedShipment)
    setSelectedShipment(updatedShipment)
  }

  const handleBulkStatusChange = () => {
    if (!bulkStatusChange || selectedShipmentIds.length === 0) {
      alert("Please select a status and at least one shipment")
      return
    }

    selectedShipmentIds.forEach((id) => {
      const shipment = shipments.find((s) => s.id === id)
      if (shipment) {
        const statusHistory = shipment.statusHistory || []
        statusHistory.push({
          status: bulkStatusChange as any,
          changedAt: new Date(),
          changedBy: "User (Bulk Action)",
        })

        updateShipment(id, {
          ...shipment,
          status: bulkStatusChange as any,
          statusHistory,
        })
      }
    })

    setSelectedShipmentIds([])
    setBulkStatusChange("")
    alert(`${selectedShipmentIds.length} shipments updated`)
  }

  const handleExportToCSV = () => {
    const headers = [
      "Supplier",
      "Product",
      "Origin Country",
      "Company",
      "Status",
      "Estimated Loading",
      "Estimated Arrival",
      "Order No",
      "Invoice No",
      "Bill of Lading No",
      "Shipping Line",
      "Customer",
    ]

    const rows = filteredShipments.map((s) => [
      s.tedarikci,
      s.product,
      s.originCountry,
      companies.find((c) => c.id === s.firmaId)?.name || "",
      s.status,
      s.estimatedLoading ? new Date(s.estimatedLoading).toLocaleDateString("en-US") : "",
      s.estimatedArrivalDate ? new Date(s.estimatedArrivalDate).toLocaleDateString("en-US") : "",
      s.ourOrderNumber || "",
      s.invoiceNumber || "",
      s.billOfLadingNumber || "",
      s.carrier || "",
      s.customer || "",
    ])

    const csvContent = [headers, ...rows].map((row) => row.map((cell) => `"${cell}"`).join(",")).join("\n")

    const blob = new Blob(["\ufeff" + csvContent], { type: "text/csv;charset=utf-8;" })
    const link = document.createElement("a")
    const url = URL.createObjectURL(blob)
    link.setAttribute("href", url)
    link.setAttribute("download", `shipments_${new Date().toISOString().split("T")[0]}.csv`)
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const handleManualCourierUpdate = (status: string, location: string, estimatedDelivery?: string) => {
    if (!selectedShipment) return

    const courierTrackingStatus = {
      status,
      statusDescription:
        status === "delivered"
          ? "Delivered"
          : status === "in_transit"
            ? "On the Way"
            : status === "out_for_delivery"
              ? "Out for Delivery"
              : status === "pending"
                ? "Pending"
                : "Unknown",
      lastUpdate: new Date().toISOString(),
      location,
      estimatedDelivery,
      events: [
        ...(selectedShipment.courierTrackingStatus?.events || []),
        {
          status,
          location,
          timestamp: new Date().toISOString(),
          description: `Status updated: ${
            status === "delivered"
              ? "Delivered"
              : status === "in_transit"
                ? "On the Way"
                : status === "out_for_delivery"
                  ? "Out for Delivery"
                  : status === "pending"
                    ? "Pending"
                    : "Unknown"
          }`,
        },
      ],
    }

    const updatedShipment = {
      ...selectedShipment,
      courierTrackingStatus,
    }

    updateShipment(selectedShipment.id, updatedShipment)
    setSelectedShipment(updatedShipment)
  }

  // CHANGE: Added useEffect to run carrier migration when shipping-lines view is loaded
  // This useEffect will now run every time the 'shipping-lines' view is loaded, ensuring the migration happens on each visit.
  useEffect(() => {
    if (view === "shipping-lines") {
      store.mergeShippingLinesFromAllSources()
      // Force reload of shipping lines
      const lines = store.getShippingLines()
      // Force a re-render by updating state if needed
      if (lines.length !== shippingLines.length) {
        window.location.reload()
      }
    }
  }, [view, shippingLines.length])

  // CHANGE: Calculate shipment counts per carrier
  const shipmentCountsByCarrier = useMemo(() => {
    return store.getShipmentCountsByCarrier()
  }, [shipments])

  const handleQuickAddSupplier = (name: string) => {
    setPrefilledSupplierName(name)
    setEditingSupplier(undefined)
    setView("supplier-form")
  }

  useEffect(() => {
    store.initialize()
    store.migrateInvoiceAndBL()
    store.migrateStatusNormalization()
    store.migrateTransitFlag()
    store.migrateBlankStatuses()
    // CHANGE: Removed store.removeTransitStatus() - function doesn't exist
    // CHANGE: Add migration to normalize country names from Turkish to English
    store.migrateCountryNames()
  }, [])

  useEffect(() => {
    const wasUpdated = store.migrateCountryNames()
    if (wasUpdated) {
      console.log("[v0] Country data was updated, reloading shipments...")
      reloadShipments()
    }
  }, [reloadShipments])

  useEffect(() => {
    migrateStatuses()
  }, [])

  // Load data from localStorage
  useEffect(() => {
    const savedFiltersFromLocalStorage = localStorage.getItem("savedFilters")
    if (savedFiltersFromLocalStorage) {
      setSavedFilters(JSON.parse(savedFiltersFromLocalStorage))
    }
    setDeletedShipments(store.getDeletedShipments())
  }, [])

  useEffect(() => {
    store.migrateStatusV2()
  }, [])

  return (
    // CHANGE: Use a div wrapper for the main content to allow positioning of modal dialogs
    <div className="min-h-screen bg-slate-50">
      <nav className="bg-white border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-3 sm:px-4 py-3 sm:py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-lg sm:text-2xl font-bold text-slate-900">Shipment Tracking</h1>

            <div className="hidden md:flex gap-2 items-center">
              <Button
                variant={view === "dashboard" ? "default" : "outline"}
                onClick={() => setView("dashboard")}
                size="sm"
                className="relative"
              >
                Dashboard
                {upcomingArrivals.length > 0 && (
                  <span className="absolute -top-1 -right-1 h-5 w-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                    {upcomingArrivals.length}
                  </span>
                )}
              </Button>
              <Button
                variant={view === "suppliers" ? "default" : "outline"}
                onClick={() => setView("suppliers")}
                size="sm"
              >
                Suppliers
              </Button>
              <Button
                variant={view === "shipments" ? "default" : "outline"}
                onClick={() => setView("shipments")}
                size="sm"
              >
                Shipments
              </Button>
              {/* Added Shipping Lines button */}
              <Button
                variant={view === "shipping-lines" ? "default" : "outline"}
                onClick={() => setView("shipping-lines")}
                size="sm"
              >
                Shipping Lines
              </Button>
              <Button
                variant={view === "recycle-bin" ? "default" : "outline"}
                onClick={() => setView("recycle-bin")}
                size="sm"
              >
                Recycle Bin
                {deletedShipments.length > 0 && (
                  <span className="ml-2 px-2 py-0.5 bg-red-500 text-white text-xs rounded-full">
                    {deletedShipments.length}
                  </span>
                )}
              </Button>
            </div>

            <Button
              variant="ghost"
              size="sm"
              className="md:hidden"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>

          {isMobileMenuOpen && (
            <div className="md:hidden mt-3 flex flex-col gap-2">
              <Button
                variant={view === "dashboard" ? "default" : "outline"}
                onClick={() => {
                  setView("dashboard")
                  setIsMobileMenuOpen(false)
                }}
                className="w-full relative"
                size="sm"
              >
                Dashboard
                {upcomingArrivals.length > 0 && (
                  <span className="absolute -top-1 -right-1 h-5 w-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                    {upcomingArrivals.length}
                  </span>
                )}
              </Button>
              <Button
                variant={view === "suppliers" ? "default" : "outline"}
                onClick={() => {
                  setView("suppliers")
                  setIsMobileMenuOpen(false)
                }}
                className="w-full"
                size="sm"
              >
                Suppliers
              </Button>
              <Button
                variant={view === "shipments" ? "default" : "outline"}
                onClick={() => {
                  setView("shipments")
                  setIsMobileMenuOpen(false)
                }}
                className="w-full"
                size="sm"
              >
                Shipments
              </Button>
              {/* Added Shipping Lines mobile button */}
              <Button
                variant={view === "shipping-lines" ? "default" : "outline"}
                onClick={() => {
                  setView("shipping-lines")
                  setIsMobileMenuOpen(false)
                }}
                className="w-full"
                size="sm"
              >
                Shipping Lines
              </Button>
              <Button
                variant={view === "recycle-bin" ? "default" : "outline"}
                onClick={() => {
                  setView("recycle-bin")
                  setIsMobileMenuOpen(false)
                }}
                className="w-full"
                size="sm"
              >
                Recycle Bin
                {deletedShipments.length > 0 && (
                  <span className="ml-2 px-2 py-0.5 bg-red-500 text-white text-xs rounded-full">
                    {deletedShipments.length}
                  </span>
                )}
              </Button>
            </div>
          )}
        </div>
      </nav>

      {/* Added LocalBackupBar component */}
      <LocalBackupBar />

      <main className="max-w-7xl mx-auto px-3 sm:px-4 py-4 sm:py-8">
        {view === "dashboard" && (
          <div className="space-y-4 sm:space-y-6">
            {/* CHANGE: Updated statistics cards to show all 4 shipment statuses */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
              <Card className="p-4 sm:p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs sm:text-sm text-muted-foreground">To Load</p>
                    <p className="text-2xl sm:text-3xl font-bold mt-1 sm:mt-2">
                      {shipments.filter((s) => normStatus(s.status) === "toload").length}
                    </p>
                  </div>
                  <Package className="h-8 w-8 text-blue-500 opacity-80" />
                </div>
              </Card>
              <Card className="p-4 sm:p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs sm:text-sm text-muted-foreground">On the Way</p>
                    <p className="text-2xl sm:text-3xl font-bold mt-1 sm:mt-2">{onTheWayShipments.length}</p>
                  </div>
                  <Truck className="h-8 w-8 text-amber-500 opacity-80" />
                </div>
              </Card>
              <Card className="p-4 sm:p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs sm:text-sm text-muted-foreground">Arrived</p>
                    <p className="text-2xl sm:text-3xl font-bold mt-1 sm:mt-2">
                      {shipments.filter((s) => normStatus(s.status) === "arrived").length}
                    </p>
                  </div>
                  <CheckCircle2 className="h-8 w-8 text-green-500 opacity-80" />
                </div>
              </Card>
              <Card className="p-4 sm:p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs sm:text-sm text-muted-foreground">Import Completed</p>
                    <p className="text-2xl sm:text-3xl font-bold mt-1 sm:mt-2">
                      {shipments.filter((s) => normStatus(s.status) === "completed").length}
                    </p>
                  </div>
                  <CheckCheck className="h-8 w-8 text-emerald-600 opacity-80" />
                </div>
              </Card>
            </div>

            <div className="my-6 border-t-2 border-border" />

            {/* Shipments To Load */}
            <Card className="border-2 border-blue-200 shadow-md bg-blue-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Package className="h-5 w-5 text-blue-600" />
                  <h2 className="text-lg sm:text-xl font-bold text-blue-900">Shipments To Load</h2>
                </div>
              </CardHeader>
              <CardContent>
                {shipments.filter((s) => normStatus(s.status) === "toload").length > 0 ? (
                  <ShipmentsTable
                    shipments={shipments.filter((s) => normStatus(s.status) === "toload").slice(-5)}
                    companies={companies}
                    onEdit={(shipment) => {
                      setEditingShipment(shipment)
                      setView("shipment-form")
                    }}
                    onDelete={handleDeleteShipment}
                    onViewDocuments={(shipment) => {
                      setSelectedShipment(shipment)
                      setView("shipment-detail")
                    }}
                    onStatusChange={handleStatusChange}
                  />
                ) : (
                  <div className="flex items-center justify-center min-h-[120px]">
                    <p className="text-muted-foreground text-sm opacity-60">No records yet</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Shipments On the Way */}
            <Card className="p-4 sm:p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold">Shipments On the Way</h2>
                <span className="text-2xl font-bold text-blue-600">{onTheWayShipments.length}</span>
              </div>
              {onTheWayShipments.length > 0 ? (
                <ShipmentsTable
                  shipments={onTheWayShipments}
                  companies={companies}
                  onEdit={(shipment) => {
                    setEditingShipment(shipment)
                    setView("shipment-form")
                  }}
                  onDelete={handleDeleteShipment}
                  onViewDocuments={(shipment) => {
                    setSelectedShipment(shipment)
                    setView("shipment-detail")
                  }}
                  onStatusChange={handleStatusChange}
                />
              ) : (
                <div className="flex items-center justify-center min-h-[120px]">
                  <p className="text-muted-foreground text-sm opacity-60">No records yet</p>
                </div>
              )}
            </Card>

            {/* Arrived Shipments */}
            <Card className="border-2 border-green-200 shadow-md bg-green-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-5 w-5 text-green-600" />
                  <h2 className="text-lg sm:text-xl font-bold text-green-900">Arrived Shipments</h2>
                </div>
              </CardHeader>
              <CardContent>
                {shipments.filter((s) => normStatus(s.status) === "arrived").length > 0 ? (
                  <ShipmentsTable
                    shipments={shipments.filter((s) => normStatus(s.status) === "arrived").slice(-5)}
                    companies={companies}
                    onEdit={(shipment) => {
                      setEditingShipment(shipment)
                      setView("shipment-form")
                    }}
                    onDelete={handleDeleteShipment}
                    onViewDocuments={(shipment) => {
                      setSelectedShipment(shipment)
                      setView("shipment-detail")
                    }}
                    onStatusChange={handleStatusChange}
                  />
                ) : (
                  <div className="flex items-center justify-center min-h-[120px]">
                    <p className="text-muted-foreground text-sm opacity-60">No records yet</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Import Completed Shipments */}
            <Card className="border-2 border-emerald-200 shadow-md bg-emerald-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <CheckCheck className="h-5 w-5 text-emerald-600" />
                  <h2 className="text-lg sm:text-xl font-bold text-emerald-900">Import Completed Shipments</h2>
                </div>
              </CardHeader>
              <CardContent>
                {shipments.filter((s) => normStatus(s.status) === "completed").length > 0 ? (
                  <ShipmentsTable
                    shipments={shipments.filter((s) => normStatus(s.status) === "completed").slice(-5)}
                    companies={companies}
                    onEdit={(shipment) => {
                      setEditingShipment(shipment)
                      setView("shipment-form")
                    }}
                    onDelete={handleDeleteShipment}
                    onViewDocuments={(shipment) => {
                      setSelectedShipment(shipment)
                      setView("shipment-detail")
                    }}
                    onStatusChange={handleStatusChange}
                  />
                ) : (
                  <div className="flex items-center justify-center min-h-[120px]">
                    <p className="text-muted-foreground text-sm opacity-60">No records yet</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="border-2 border-purple-200 shadow-md bg-purple-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Truck className="h-5 w-5 text-purple-600" />
                  <h2 className="text-lg sm:text-xl font-bold text-purple-900">Transit Shipments</h2>
                </div>
              </CardHeader>
              <CardContent>
                {transitShipments.length > 0 ? (
                  <ShipmentsTable
                    shipments={transitShipments.slice(-5)}
                    companies={companies}
                    onEdit={(shipment) => {
                      setEditingShipment(shipment)
                      setView("shipment-form")
                    }}
                    onDelete={handleDeleteShipment}
                    onViewDocuments={(shipment) => {
                      setSelectedShipment(shipment)
                      setView("shipment-detail")
                    }}
                    onStatusChange={handleStatusChange}
                  />
                ) : (
                  <div className="flex items-center justify-center min-h-[120px]">
                    <p className="text-muted-foreground text-sm opacity-60">No records yet</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {SHOW_STATUS_DISTRIBUTION && statusDistribution.length > 0 && (
              <Card className="p-4 sm:p-6">
                <h2 className="text-lg sm:text-xl font-semibold mb-3 sm:mb-4">Status Distribution</h2>
                <div className="space-y-3">
                  {statusDistribution.map((status, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-4 h-4 rounded" style={{ backgroundColor: status.color }} />
                        <span className="text-sm font-medium">{status.name}</span>
                      </div>
                      <Badge variant="secondary">{status.value}</Badge>
                    </div>
                  ))}
                </div>
              </Card>
            )}

            {upcomingArrivals.length > 0 && (
              <Card className="p-4 sm:p-6">
                <div className="flex items-center gap-2 mb-3 sm:mb-4">
                  <Bell className="h-5 w-5 text-red-500" />
                  <h2 className="text-lg sm:text-xl font-semibold">Upcoming Arrivals (Within 7 Days)</h2>
                </div>
                <div className="space-y-3">
                  {upcomingArrivals.map((shipment) => {
                    const company = companies.find((c) => c.id === shipment.firmaId)
                    const daysUntilArrival = Math.ceil(
                      (new Date(shipment.estimatedArrivalDate!).getTime() - new Date().getTime()) /
                        (1000 * 60 * 60 * 24),
                    )
                    return (
                      <div
                        key={shipment.id}
                        className="flex flex-col sm:flex-row sm:items-center justify-between p-3 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
                        onClick={() => {
                          setSelectedShipment(shipment)
                          setView("shipment-detail")
                        }}
                      >
                        <div className="flex-1">
                          <p className="font-semibold text-sm sm:text-base">{shipment.product}</p>
                          <p className="text-xs sm:text-sm text-muted-foreground">
                            {shipment.tedarikçi} → {company?.name}
                          </p>
                        </div>
                        <div className="mt-2 sm:mt-0 flex items-center gap-2">
                          <span
                            className={`text-xs sm:text-sm font-medium px-2 py-1 rounded ${
                              daysUntilArrival <= 2
                                ? "bg-red-100 text-red-700"
                                : daysUntilArrival <= 4
                                  ? "bg-amber-100 text-amber-700"
                                  : "bg-blue-100 text-blue-700"
                            }`}
                          >
                            {daysUntilArrival} days
                          </span>
                          <span className="text-xs sm:text-sm text-muted-foreground">
                            {new Date(shipment.estimatedArrivalDate!).toLocaleDateString("en-US")}
                          </span>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </Card>
            )}

            {courierShipments.length > 0 && (
              <Card className="p-4 sm:p-6">
                <div className="flex items-center justify-between mb-3 sm:mb-4">
                  <div className="flex items-center gap-2">
                    <Package className="h-5 w-5 text-blue-500" />
                    <h2 className="text-lg sm:text-xl font-semibold">Tracking Documents (Courier Companies)</h2>
                  </div>
                  <Button
                    onClick={handleUpdateAllCourierTracking}
                    size="sm"
                    disabled={isLoadingCourierTracking}
                    className="text-xs"
                  >
                    {isLoadingCourierTracking ? "Updating..." : "Update All"}
                  </Button>
                </div>
                <div className="space-y-2">
                  {courierShipments.map((shipment) => {
                    const company = companies.find((c) => c.id === shipment.firmaId)
                    const status = shipment.courierTrackingStatus

                    console.log("[v0] COURIER_CARD", shipment.id, {
                      hasStatus: !!status,
                      estimatedDelivery: status?.estimatedDelivery,
                      statusObject: status,
                    })

                    return (
                      <div
                        key={shipment.id}
                        className="p-3 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
                        onClick={() => {
                          setSelectedShipment(shipment)
                          setView("shipment-detail")
                        }}
                      >
                        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <p className="font-semibold text-sm">{shipment.product}</p>
                              <span className="text-xs px-2 py-0.5 rounded bg-[rgba(255,204,0,1)] text-[rgba(212,5,17,1)]">
                                {shipment.courierCompany}
                              </span>
                            </div>
                            {shipment.invoiceNumber && (
                              <p className="text-sm text-gray-600 mb-1">
                                <strong>Invoice No:</strong> {shipment.invoiceNumber}
                              </p>
                            )}
                            {shipment.billOfLadingNumbers && shipment.billOfLadingNumbers.length > 0 && (
                              <p className="text-sm text-gray-600 mb-1">
                                <strong>Bill of Lading No:</strong> {shipment.billOfLadingNumbers.join(", ")}
                              </p>
                            )}
                            <p className="text-xs text-muted-foreground mb-1">
                              {shipment.tedarikçi} → {company?.name}
                            </p>
                            <p className="text-xs font-mono text-muted-foreground">
                              Tracking No: {shipment.courierTrackingNumber}
                            </p>
                          </div>
                          <div className="flex flex-col items-end gap-1">
                            {status ? (
                              <>
                                <span
                                  className={`text-xs font-medium px-2 py-1 rounded ${
                                    status.status === "delivered"
                                      ? "bg-green-100 text-green-700"
                                      : status.status === "in_transit"
                                        ? "bg-blue-100 text-blue-700"
                                        : status.status === "out_for_delivery"
                                          ? "bg-amber-100 text-amber-700"
                                          : "bg-slate-100 text-slate-700"
                                  }`}
                                >
                                  {status.statusDescription}
                                </span>
                                {status.location && (
                                  <p className="text-xs text-muted-foreground">📍 {status.location}</p>
                                )}
                                <p className="text-xs text-muted-foreground">{formatDate(status.lastUpdate)}</p>
                                {status.estimatedDelivery && (
                                  <p className="text-xs text-green-600 font-medium">
                                    Est. Delivery: {formatDate(status.estimatedDelivery)}
                                  </p>
                                )}
                              </>
                            ) : (
                              <span className="text-xs text-muted-foreground italic">Not updated yet</span>
                            )}
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </Card>
            )}

            {/* CHANGE: Always show B/L tracking card */}
            {SHOW_BL_CARD && (
              <Card className="p-4 sm:p-6">
                <div className="flex items-center justify-between mb-3 sm:mb-4">
                  <div className="flex items-center gap-2">
                    <Anchor className="h-5 w-5 text-blue-600" />
                    <h2 className="text-lg sm:text-xl font-semibold">Bill of Lading Tracking</h2>
                  </div>
                </div>
                {shipmentsWithBL.length > 0 ? (
                  <div className="space-y-3">
                    {shipmentsWithBL.map((shipment) => {
                      const company = companies.find((c) => c.id === shipment.firmaId)
                      const trackingUrl = getShippingLineTrackingUrl(shipment.carrier!, shipment.billOfLadingNumber!)

                      return (
                        <div
                          key={shipment.id}
                          className="p-3 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors"
                        >
                          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <p className="font-semibold text-sm">{shipment.product}</p>
                                <span className="text-xs px-2 py-0.5 rounded bg-blue-600 text-white">
                                  {shipment.carrier}
                                </span>
                              </div>
                              <p className="text-xs text-muted-foreground mb-1">
                                {shipment.tedarikçi} → {company?.name}
                              </p>
                              <p className="text-xs font-mono text-muted-foreground">
                                B/L: {shipment.billOfLadingNumber}
                              </p>
                            </div>
                            <div className="flex flex-col items-end gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => window.open(trackingUrl, "_blank")}
                                disabled={trackingUrl === "#"}
                                className="text-xs"
                              >
                                <ExternalLink className="h-3 w-3 mr-1" />
                                Track
                              </Button>
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => {
                                  setSelectedShipment(shipment)
                                  setView("shipment-detail")
                                }}
                                className="text-xs"
                              >
                                Detail
                              </Button>
                            </div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                ) : (
                  <div className="flex items-center justify-center py-8">
                    <div className="text-center">
                      <p className="mb-2 text-muted-foreground opacity-60">No records yet</p>
                      <p className="text-sm text-muted-foreground">
                        Add a <strong>Shipping Line</strong> and <strong>Bill of Lading Number</strong> to a shipment to
                        get started
                      </p>
                      <p className="text-xs mt-2 text-blue-600">
                        You can track directly from the carrier's website with one click
                      </p>
                    </div>
                  </div>
                )}
              </Card>
            )}

            {/* CHANGE: Removed duplicate "Son Kargolar" card from bottom */}
          </div>
        )}

        {view === "suppliers" && (
          <div className="space-y-4 sm:space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <h2 className="text-xl sm:text-2xl font-bold">Suppliers</h2>
              <Button
                onClick={() => {
                  setEditingSupplier(undefined)
                  setView("supplier-form")
                }}
                size="sm"
                className="w-full sm:w-auto"
              >
                Add Supplier
              </Button>
            </div>
            <Card className="p-4 sm:p-6">
              <Input
                type="text"
                placeholder="Search suppliers..."
                value={supplierSearchQuery}
                onChange={(e) => setSupplierSearchQuery(e.target.value)}
                className="w-full text-sm"
              />
            </Card>
            <Card className="p-4 sm:p-6">
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold mb-2 sm:mb-3 text-sm sm:text-base">Filter by Country</h3>
                  <div className="flex flex-wrap gap-1.5 sm:gap-2">
                    <Button
                      variant={selectedSupplierCountry === null ? "default" : "outline"}
                      onClick={() => setSelectedSupplierCountry(null)}
                      size="sm"
                      className="text-xs"
                    >
                      All
                    </Button>
                    {uniqueSupplierCountries.map((country) => (
                      <Button
                        key={country}
                        variant={selectedSupplierCountry === country ? "default" : "outline"}
                        onClick={() => setSelectedSupplierCountry(country)}
                        size="sm"
                        className="text-xs"
                      >
                        {country}
                      </Button>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold mb-2 sm:mb-3 text-sm sm:text-base">Sort Order</h3>
                  <div className="flex gap-1.5 sm:gap-2">
                    <Button
                      variant={supplierSortOrder === "asc" ? "default" : "outline"}
                      onClick={() => setSupplierSortOrder("asc")}
                      size="sm"
                      className="text-xs"
                    >
                      A-Z
                    </Button>
                    <Button
                      variant={supplierSortOrder === "desc" ? "default" : "outline"}
                      onClick={() => setSupplierSortOrder("desc")}
                      size="sm"
                      className="text-xs"
                    >
                      Z-A
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
            <Card className="p-4 sm:p-6">
              <SuppliersTable
                suppliers={filteredAndSortedSuppliers}
                onEdit={(supplier) => {
                  setEditingSupplier(supplier)
                  setView("supplier-form")
                }}
                onDelete={handleDeleteSupplier}
                onViewShipments={(supplier) => {
                  setSelectedSupplier(supplier)
                  setView("shipments")
                }}
              />
            </Card>
          </div>
        )}

        {view === "supplier-form" && (
          <div className="space-y-4 sm:space-y-6">
            <h2 className="text-xl sm:text-2xl font-bold">{editingSupplier ? "Edit Supplier" : "Add New Supplier"}</h2>
            <Card className="p-4 sm:p-6">
              <SupplierForm
                onSubmit={handleAddSupplier}
                initialData={editingSupplier}
                onCancel={() => setView("suppliers")}
                initialName={prefilledSupplierName}
              />
            </Card>
          </div>
        )}

        {view === "shipments" && (
          <div className="space-y-4 sm:space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div>
                <h2 className="text-xl sm:text-2xl font-bold">
                  {selectedSupplier ? `${selectedSupplier.name} Shipments` : "All Shipments"}
                </h2>
                {selectedSupplier && (
                  <Button
                    variant="link"
                    onClick={() => {
                      setSelectedSupplier(undefined)
                      setView("shipments")
                    }}
                    className="mt-1 sm:mt-2 p-0 h-auto text-xs sm:text-sm"
                  >
                    View all shipments
                  </Button>
                )}
              </div>
              <div className="flex gap-2 w-full sm:w-auto">
                <Button
                  onClick={handleExportToCSV}
                  size="sm"
                  variant="outline"
                  className="flex-1 sm:flex-none bg-transparent"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Excel
                </Button>
                <Button
                  onClick={() => {
                    setEditingShipment(undefined)
                    setView("shipment-form")
                  }}
                  size="sm"
                  className="flex-1 sm:flex-none"
                >
                  Add Shipment
                </Button>
              </div>
            </div>

            <Card className="p-4 sm:p-6">
              <div className="flex flex-col sm:flex-row gap-2">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="text"
                    placeholder="Search by product, supplier, order no, invoice no, BL no..."
                    value={shipmentSearchQuery}
                    onChange={(e) => setShipmentSearchQuery(e.target.value)}
                    className="pl-10 text-sm"
                  />
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
                  className="w-full sm:w-auto"
                >
                  <Filter className="h-4 w-4 mr-2" />
                  Advanced Filters
                </Button>
              </div>
            </Card>

            {selectedShipmentIds.length > 0 && (
              <Card className="p-4 sm:p-6 bg-blue-50 border-blue-200">
                <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
                  <p className="text-sm font-medium">{selectedShipmentIds.length} shipments selected</p>
                  <div className="flex gap-2 flex-1 w-full sm:w-auto">
                    <select
                      value={bulkStatusChange}
                      onChange={(e) => setBulkStatusChange(e.target.value)}
                      className="flex-1 sm:flex-none rounded-md border border-input bg-background px-3 py-2 text-sm"
                    >
                      <option value="">Select status...</option>
                      <option value="toload">To Load</option>
                      <option value="ontheway">On the Way</option>
                      <option value="arrived">Arrived</option>
                      <option value="completed">Import Completed</option>
                    </select>
                    <Button onClick={handleBulkStatusChange} size="sm">
                      Apply
                    </Button>
                    <Button onClick={() => setSelectedShipmentIds([])} size="sm" variant="outline">
                      Cancel
                    </Button>
                  </div>
                </div>
              </Card>
            )}

            {showAdvancedFilters && (
              <Card className="p-4 sm:p-6">
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="font-semibold text-sm sm:text-base">Advanced Filters</h3>
                    <Button variant="ghost" size="sm" onClick={handleClearFilters} className="text-xs">
                      Clear Filters
                    </Button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {uniqueCarriers.length > 0 && (
                      <div>
                        <label className="text-sm font-medium mb-2 block">Shipping Line</label>
                        <select
                          value={selectedCarrier || ""}
                          onChange={(e) => setSelectedCarrier(e.target.value || null)}
                          className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                        >
                          <option value="">All</option>
                          {uniqueCarriers.map((carrier) => (
                            <option key={carrier} value={carrier}>
                              {carrier}
                            </option>
                          ))}
                        </select>
                      </div>
                    )}

                    {uniqueCustomers.length > 0 && (
                      <div>
                        <label className="text-sm font-medium mb-2 block">Customer</label>
                        <select
                          value={selectedCustomer || ""}
                          onChange={(e) => setSelectedCustomer(e.target.value || null)}
                          className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                        >
                          <option value="">All</option>
                          {uniqueCustomers.map((customer) => (
                            <option key={customer} value={customer}>
                              {customer}
                            </option>
                          ))}
                        </select>
                      </div>
                    )}

                    <div>
                      <label className="text-sm font-medium mb-2 block">Estimated Arrival (Start)</label>
                      <Input
                        type="date"
                        value={dateRangeStart}
                        onChange={(e) => setDateRangeStart(e.target.value)}
                        className="text-sm"
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Estimated Arrival (End)</label>
                      <Input
                        type="date"
                        value={dateRangeEnd}
                        onChange={(e) => setDateRangeEnd(e.target.value)}
                        className="text-sm"
                      />
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <h4 className="font-semibold text-sm mb-3">Saved Filters</h4>
                    <div className="flex flex-col sm:flex-row gap-2 mb-3">
                      <Input
                        type="text"
                        placeholder="Enter filter name..."
                        value={filterName}
                        onChange={(e) => setFilterName(e.target.value)}
                        className="text-sm flex-1"
                      />
                      <Button onClick={handleSaveFilter} size="sm" className="w-full sm:w-auto">
                        <Save className="h-4 w-4 mr-2" />
                        Save Filter
                      </Button>
                    </div>

                    {savedFilters.length > 0 && (
                      <div className="space-y-2">
                        {savedFilters.map((filter) => (
                          <div
                            key={filter.id}
                            className="flex items-center justify-between p-2 bg-slate-50 rounded-lg text-sm"
                          >
                            <button
                              onClick={() => handleLoadFilter(filter)}
                              className="flex-1 text-left hover:text-primary transition-colors"
                            >
                              {filter.name}
                            </button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteFilter(filter.id)}
                              className="h-8 w-8 p-0"
                            >
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </Card>
            )}

            <Card className="p-4 sm:p-6">
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold mb-2 sm:mb-3 text-sm sm:text-base">Filter by Product</h3>
                  <div className="flex flex-wrap gap-1.5 sm:gap-2">
                    <Button
                      variant={selectedProduct === null ? "default" : "outline"}
                      onClick={() => setSelectedProduct(null)}
                      size="sm"
                      className="text-xs"
                    >
                      All
                    </Button>
                    {uniqueProducts.map((product) => (
                      <Button
                        key={product}
                        variant={selectedProduct === product ? "default" : "outline"}
                        onClick={() => setSelectedProduct(product)}
                        size="sm"
                        className="text-xs"
                      >
                        {product}
                      </Button>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold mb-2 sm:mb-3 text-sm sm:text-base">Filter by Status</h3>
                  <div className="flex flex-wrap gap-1.5 sm:gap-2">
                    <Button
                      variant={selectedStatus === null ? "default" : "outline"}
                      onClick={() => setSelectedStatus(null)}
                      size="sm"
                      className="text-xs"
                    >
                      All
                    </Button>
                    {statusOptions.map((status) => (
                      <Button
                        key={status.value}
                        variant={selectedStatus === status.value ? "default" : "outline"}
                        onClick={() => setSelectedStatus(status.value)}
                        size="sm"
                        className="text-xs"
                      >
                        {status.label}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
            </Card>

            <Card className="p-4 sm:p-6">
              <ShipmentsTable
                shipments={filteredShipments}
                companies={companies}
                onEdit={(shipment) => {
                  setEditingShipment(shipment)
                  setView("shipment-form")
                }}
                onDelete={handleDeleteShipment}
                onViewDocuments={(shipment) => {
                  setSelectedShipment(shipment)
                  setView("shipment-detail")
                }}
                selectedIds={selectedShipmentIds}
                onSelectionChange={setSelectedShipmentIds}
                onStatusChange={handleStatusChange}
              />
            </Card>
          </div>
        )}

        {view === "shipment-form" && (
          <div className="space-y-4 sm:space-y-6">
            <h2 className="text-xl sm:text-2xl font-bold">{editingShipment ? "Edit Shipment" : "Add New Shipment"}</h2>
            <Card className="p-4 sm:p-6">
              <ShipmentForm
                companies={companies}
                suppliers={suppliers}
                tedarikciList={tedarikciList}
                countries={countries}
                carriers={carriers}
                onSubmit={handleAddShipment}
                initialData={editingShipment}
                onCancel={() => setView("shipments")}
                onAddNewSupplier={(name) => {
                  setPrefilledSupplierName(name)
                  setView("supplier-form")
                }}
                onAddNewCarrier={(name) => {
                  setPrefilledCarrierName(name)
                  setView("shipping-line-form")
                }}
              />
            </Card>
          </div>
        )}

        {view === "shipment-detail" && selectedShipment && (
          <div className="space-y-4 sm:space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <h2 className="text-xl sm:text-2xl font-bold">Shipment Details</h2>
              <div className="flex gap-2 w-full sm:w-auto">
                {isEditingDetail ? (
                  <>
                    <Button onClick={handleSaveShipmentDetail} size="sm" className="flex-1 sm:flex-none">
                      Save
                    </Button>
                    <Button
                      variant="outline"
                      onClick={handleCancelEdit}
                      size="sm"
                      className="flex-1 sm:flex-none bg-transparent"
                    >
                      Cancel
                    </Button>
                  </>
                ) : (
                  <>
                    <Button
                      variant="outline"
                      onClick={() => {
                        setIsEditingDetail(true)
                        setEditedShipmentData({
                          status: selectedShipment.status,
                          ourOrderNumber: selectedShipment.ourOrderNumber,
                          supplierOrderNumber: selectedShipment.supplierOrderNumber,
                          invoiceNumber: selectedShipment.invoiceNumber,
                          billOfLadingNumber: selectedShipment.billOfLadingNumber,
                          containerNumber: selectedShipment.containerNumber,
                          estimatedDepartureDate: selectedShipment.estimatedDepartureDate,
                          estimatedArrivalDate: selectedShipment.estimatedArrivalDate,
                          actualDelivery: selectedShipment.actualDelivery,
                          carrier: selectedShipment.carrier,
                          courierCompany: selectedShipment.courierCompany,
                          courierTrackingNumber: selectedShipment.courierTrackingNumber,
                        })
                      }}
                      size="sm"
                      className="flex-1 sm:flex-none"
                    >
                      Edit
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => setView("shipments")}
                      size="sm"
                      className="flex-1 sm:flex-none"
                    >
                      Back
                    </Button>
                  </>
                )}
              </div>
            </div>

            <Card className="p-4 sm:p-6">
              <h3 className="font-semibold mb-4 text-sm sm:text-base">Status Tracking</h3>
              <div className="relative">
                <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-slate-200" />
                <div className="space-y-6">
                  {["toload", "ontheway", "arrived", "completed"].map((status, index) => {
                    const statusLabels = {
                      toload: "To Load",
                      ontheway: "On the Way",
                      arrived: "Arrived",
                      completed: "Import Completed",
                    }
                    const isCompleted =
                      status === "toload" ||
                      (status === "ontheway" &&
                        (selectedShipment.status === "ontheway" ||
                          selectedShipment.status === "arrived" ||
                          selectedShipment.status === "completed")) ||
                      (status === "arrived" &&
                        (selectedShipment.status === "arrived" || selectedShipment.status === "completed")) ||
                      (status === "completed" && selectedShipment.status === "completed")
                    const isCurrent = selectedShipment.status === status

                    const historyEntry = selectedShipment.statusHistory?.find((h) => h.status === status)

                    return (
                      <div key={status} className="relative flex items-start gap-4">
                        <div
                          className={`relative z-10 flex h-8 w-8 items-center justify-center rounded-full border-2 ${
                            isCompleted
                              ? "bg-green-500 border-green-500"
                              : isCurrent
                                ? "bg-blue-500 border-blue-500"
                                : "bg-white border-slate-300"
                          }`}
                        >
                          {isCompleted && <CheckCircle2 className="h-5 w-5 text-white" />}
                        </div>
                        <div className="flex-1 pt-1">
                          <p
                            className={`font-semibold text-sm ${
                              isCompleted || isCurrent ? "text-slate-900" : "text-slate-400"
                            }`}
                          >
                            {statusLabels[status as keyof typeof statusLabels]}
                          </p>
                          {historyEntry && (
                            <p className="text-xs text-muted-foreground mt-1">
                              {new Date(historyEntry.changedAt).toLocaleString("en-US")}
                              {historyEntry.changedBy && ` - ${historyEntry.changedBy}`}
                            </p>
                          )}
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
              <Card className="p-4 sm:p-6">
                <h3 className="font-semibold mb-3 sm:mb-4 text-sm sm:text-base">Shipment Information</h3>
                <div className="space-y-2 sm:space-y-3 text-xs sm:text-sm">
                  <div>
                    <p className="text-muted-foreground">Supplier</p>
                    <p className="font-semibold">{selectedShipment.tedarikçi}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Product</p>
                    <p className="font-semibold">{selectedShipment.product}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Origin Country</p>
                    <p>{selectedShipment.originCountry}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Company</p>
                    <p>{companies.find((c) => c.id === selectedShipment.firmaId)?.name}</p>
                  </div>
                  {selectedShipment.customer && (
                    <div>
                      <p className="text-muted-foreground">Customer (Transit Sale)</p>
                      <p className="font-semibold">{selectedShipment.customer}</p>
                    </div>
                  )}
                  <div>
                    <p className="text-muted-foreground">Status</p>
                    {isEditingDetail ? (
                      <select
                        value={editedShipmentData.status || selectedShipment.status}
                        onChange={(e) =>
                          setEditedShipmentData({ ...editedShipmentData, status: e.target.value as any })
                        }
                        className="mt-2 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                      >
                        <option value="toload">To Load</option>
                        <option value="ontheway">On the Way</option>
                        <option value="arrived">Arrived</option>
                        <option value="completed">Import Completed</option>
                      </select>
                    ) : (
                      <p className="text-2xl sm:text-3xl font-bold mt-1 sm:mt-2 capitalize">
                        {selectedShipment.status === "toload" && "To Load"}
                        {selectedShipment.status === "ontheway" && "On the Way"}
                        {selectedShipment.status === "arrived" && "Arrived"}
                        {selectedShipment.status === "completed" && "Import Completed"}
                      </p>
                    )}
                  </div>
                  {(isEditingDetail || selectedShipment.actualDelivery) && (
                    <div>
                      <p className="text-muted-foreground">Actual Delivery Date</p>
                      {isEditingDetail ? (
                        <Input
                          type="date"
                          value={
                            editedShipmentData.actualDelivery
                              ? new Date(editedShipmentData.actualDelivery).toISOString().split("T")[0]
                              : selectedShipment.actualDelivery
                                ? new Date(selectedShipment.actualDelivery).toISOString().split("T")[0]
                                : ""
                          }
                          onChange={(e) =>
                            setEditedShipmentData({
                              ...editedShipmentData,
                              actualDelivery: e.target.value ? new Date(e.target.value) : undefined,
                            })
                          }
                          className="mt-2 text-sm"
                        />
                      ) : (
                        selectedShipment.actualDelivery && (
                          <p>{new Date(selectedShipment.actualDelivery).toLocaleDateString("en-US")}</p>
                        )
                      )}
                    </div>
                  )}
                </div>
              </Card>

              <Card className="p-4 sm:p-6">
                <h3 className="font-semibold mb-3 sm:mb-4 text-sm sm:text-base">Order and Document Information</h3>
                <div className="space-y-2 sm:space-y-3 text-xs sm:text-sm">
                  <div>
                    <p className="text-muted-foreground">Our Order Number</p>
                    {isEditingDetail ? (
                      <Input
                        value={editedShipmentData.ourOrderNumber || selectedShipment.ourOrderNumber || ""}
                        onChange={(e) =>
                          setEditedShipmentData({ ...editedShipmentData, ourOrderNumber: e.target.value })
                        }
                        placeholder="Enter order number"
                        className="mt-2 text-sm"
                      />
                    ) : (
                      selectedShipment.ourOrderNumber && (
                        <p className="font-semibold">{selectedShipment.ourOrderNumber}</p>
                      )
                    )}
                  </div>
                  <div>
                    <p className="text-muted-foreground">Supplier Order Number</p>
                    {isEditingDetail ? (
                      <Input
                        value={editedShipmentData.supplierOrderNumber || selectedShipment.supplierOrderNumber || ""}
                        onChange={(e) =>
                          setEditedShipmentData({ ...editedShipmentData, supplierOrderNumber: e.target.value })
                        }
                        placeholder="Enter supplier order number"
                        className="mt-2 text-sm"
                      />
                    ) : (
                      selectedShipment.supplierOrderNumber && (
                        <p className="font-semibold">{selectedShipment.supplierOrderNumber}</p>
                      )
                    )}
                  </div>
                  <div>
                    <p className="text-muted-foreground">Invoice Number</p>
                    {isEditingDetail ? (
                      <Input
                        value={editedShipmentData.invoiceNumber || selectedShipment.invoiceNumber || ""}
                        onChange={(e) =>
                          setEditedShipmentData({ ...editedShipmentData, invoiceNumber: e.target.value })
                        }
                        placeholder="Enter invoice number"
                        className="mt-2 text-sm"
                      />
                    ) : (
                      selectedShipment.invoiceNumber && (
                        <p className="font-semibold">{selectedShipment.invoiceNumber}</p>
                      )
                    )}
                  </div>
                  <div>
                    <p className="text-muted-foreground">Shipping Line</p>
                    {isEditingDetail ? (
                      <Input
                        value={editedShipmentData.carrier || selectedShipment.carrier || ""}
                        onChange={(e) => setEditedShipmentData({ ...editedShipmentData, carrier: e.target.value })}
                        placeholder="Enter shipping line name (e.g., Maersk, CMA CGM)"
                        className="mt-2 text-sm"
                      />
                    ) : (
                      selectedShipment.carrier && <p className="font-semibold">{selectedShipment.carrier}</p>
                    )}
                  </div>
                  <div>
                    <p className="text-muted-foreground">Bill of Lading Number</p>
                    {isEditingDetail ? (
                      <Input
                        value={editedShipmentData.billOfLadingNumber || selectedShipment.billOfLadingNumber || ""}
                        onChange={(e) =>
                          setEditedShipmentData({ ...editedShipmentData, billOfLadingNumber: e.target.value })
                        }
                        placeholder="Enter bill of lading number"
                        className="mt-2 text-sm"
                      />
                    ) : (
                      selectedShipment.billOfLadingNumber && (
                        <div className="flex items-center gap-2">
                          <p className="font-semibold">{selectedShipment.billOfLadingNumber}</p>
                          {selectedShipment.carrier && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                const url = getShippingLineTrackingUrl(
                                  selectedShipment.carrier!,
                                  selectedShipment.billOfLadingNumber!,
                                )
                                if (url !== "#") {
                                  window.open(url, "_blank")
                                }
                              }}
                              className="text-xs"
                            >
                              <ExternalLink className="h-3 w-3 mr-1" />
                              Track
                            </Button>
                          )}
                        </div>
                      )
                    )}
                  </div>
                  <div>
                    <p className="text-muted-foreground">Estimated Departure Date</p>
                    {isEditingDetail ? (
                      <Input
                        type="date"
                        value={
                          editedShipmentData.estimatedDepartureDate
                            ? new Date(editedShipmentData.estimatedDepartureDate).toISOString().split("T")[0]
                            : selectedShipment.estimatedDepartureDate
                              ? new Date(selectedShipment.estimatedDepartureDate).toISOString().split("T")[0]
                              : ""
                        }
                        onChange={(e) =>
                          setEditedShipmentData({
                            ...editedShipmentData,
                            estimatedDepartureDate: e.target.value ? new Date(e.target.value) : undefined,
                          })
                        }
                        className="mt-2 text-sm"
                      />
                    ) : (
                      selectedShipment.estimatedDepartureDate && (
                        <p>{new Date(selectedShipment.estimatedDepartureDate).toLocaleDateString("en-US")}</p>
                      )
                    )}
                  </div>
                  <div>
                    <p className="text-muted-foreground">Estimated Arrival Date</p>
                    {isEditingDetail ? (
                      <Input
                        type="date"
                        value={
                          editedShipmentData.estimatedArrivalDate
                            ? new Date(editedShipmentData.estimatedArrivalDate).toISOString().split("T")[0]
                            : selectedShipment.estimatedArrivalDate
                              ? new Date(selectedShipment.estimatedArrivalDate).toISOString().split("T")[0]
                              : ""
                        }
                        onChange={(e) =>
                          setEditedShipmentData({
                            ...editedShipmentData,
                            estimatedArrivalDate: e.target.value ? new Date(e.target.value) : undefined,
                          })
                        }
                        className="mt-2 text-sm"
                      />
                    ) : (
                      selectedShipment.estimatedArrivalDate && (
                        <p>{new Date(selectedShipment.estimatedArrivalDate).toLocaleDateString("en-US")}</p>
                      )
                    )}
                  </div>
                  {!isEditingDetail &&
                    !selectedShipment.ourOrderNumber &&
                    !selectedShipment.supplierOrderNumber &&
                    !selectedShipment.invoiceNumber &&
                    !selectedShipment.carrier &&
                    !selectedShipment.billOfLadingNumber &&
                    !selectedShipment.estimatedDepartureDate &&
                    !selectedShipment.estimatedArrivalDate && (
                      <p className="text-muted-foreground italic text-xs">No order and document info added yet</p>
                    )}
                </div>
              </Card>

              {(isEditingDetail || selectedShipment.courierCompany || selectedShipment.courierTrackingNumber) && (
                <Card className="p-4 sm:p-6">
                  <h3 className="font-semibold mb-3 sm:mb-4 text-sm sm:text-base">
                    Courier Company Tracking Information
                  </h3>
                  <p className="text-xs text-muted-foreground mb-3">
                    Courier company that the supplier sent documents with
                  </p>
                  <div className="space-y-2 sm:space-y-3 text-xs sm:text-sm">
                    <div>
                      <p className="text-muted-foreground">Courier Company</p>
                      {isEditingDetail ? (
                        <Input
                          value={editedShipmentData.courierCompany || selectedShipment.courierCompany || ""}
                          onChange={(e) =>
                            setEditedShipmentData({ ...editedShipmentData, courierCompany: e.target.value })
                          }
                          placeholder="Enter courier company name (e.g., DHL, UPS, FedEx)"
                          className="mt-2 text-sm"
                        />
                      ) : (
                        selectedShipment.courierCompany && (
                          <p className="font-semibold">{selectedShipment.courierCompany}</p>
                        )
                      )}
                    </div>
                    <div>
                      <p className="text-muted-foreground">Tracking Number</p>
                      {isEditingDetail ? (
                        <Input
                          value={
                            editedShipmentData.courierTrackingNumber || selectedShipment.courierTrackingNumber || ""
                          }
                          onChange={(e) =>
                            setEditedShipmentData({ ...editedShipmentData, courierTrackingNumber: e.target.value })
                          }
                          placeholder="Tracking number"
                          className="mt-2 text-sm"
                        />
                      ) : (
                        selectedShipment.courierTrackingNumber && (
                          <div className="flex items-center gap-2 mt-2">
                            <p className="font-semibold">{selectedShipment.courierTrackingNumber}</p>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                navigator.clipboard.writeText(selectedShipment.courierTrackingNumber!)
                                alert("Tracking number copied!")
                              }}
                              className="h-7 px-2 text-xs"
                            >
                              Copy
                            </Button>
                            {selectedShipment.courierCompany && (
                              <Button size="sm" asChild className="h-7 px-2 text-xs">
                                <a
                                  href={getCourierTrackingUrl(
                                    selectedShipment.courierCompany,
                                    selectedShipment.courierTrackingNumber,
                                  )}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                >
                                  Track
                                </a>
                              </Button>
                            )}
                          </div>
                        )
                      )}
                    </div>
                    {!isEditingDetail && selectedShipment.courierCompany && selectedShipment.courierTrackingNumber && (
                      <div className="pt-3 border-t">
                        <div className="flex items-center justify-between mb-3">
                          <p className="text-muted-foreground font-medium">Current Status</p>
                          <Button
                            onClick={() => handleFetchCourierTracking(selectedShipment)}
                            size="sm"
                            disabled={isLoadingCourierTracking}
                            className="text-xs"
                          >
                            {isLoadingCourierTracking ? "Updating..." : "Update Status"}
                          </Button>
                        </div>
                        {selectedShipment.courierTrackingStatus ? (
                          <div className="space-y-3">
                            <div className="p-3 bg-blue-50 rounded-lg">
                              <p className="font-semibold text-sm">
                                {selectedShipment.courierTrackingStatus.statusDescription}
                              </p>
                              {selectedShipment.courierTrackingStatus.location && (
                                <p className="text-xs text-muted-foreground mt-1">
                                  📍 {selectedShipment.courierTrackingStatus.location}
                                </p>
                              )}
                              <p className="text-xs text-muted-foreground mt-1">
                                Last update:{" "}
                                {new Date(selectedShipment.courierTrackingStatus.lastUpdate).toLocaleString("en-US")}
                              </p>
                              {selectedShipment.courierTrackingStatus.estimatedDelivery && (
                                <p className="text-xs text-muted-foreground mt-1">
                                  Estimated delivery:{" "}
                                  {new Date(
                                    selectedShipment.courierTrackingStatus.estimatedDelivery,
                                  ).toLocaleDateString("en-US")}
                                </p>
                              )}
                            </div>
                            {selectedShipment.courierTrackingStatus.events &&
                              selectedShipment.courierTrackingStatus.events.length > 0 && (
                                <div>
                                  <p className="text-xs font-medium mb-2">Tracking History</p>
                                  <div className="space-y-2">
                                    {selectedShipment.courierTrackingStatus.events.map((event, index) => (
                                      <div key={index} className="p-2 bg-slate-50 rounded text-xs">
                                        <p className="font-medium">{event.description}</p>
                                        <p className="text-muted-foreground">
                                          📍 {event.location} • {new Date(event.timestamp).toLocaleString("en-US")}
                                        </p>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}
                          </div>
                        ) : (
                          <p className="text-xs text-muted-foreground italic">
                            No status information added yet. You can add it manually using the form below.
                          </p>
                        )}
                        <div className="mt-4 p-3 bg-slate-50 rounded-lg space-y-3">
                          <p className="text-xs font-medium">Manual Status Update</p>
                          <div className="space-y-2">
                            <div>
                              <label className="text-xs text-muted-foreground">Status</label>
                              <select
                                id="courier-status"
                                className="w-full mt-1 rounded-md border border-input bg-background px-3 py-2 text-sm"
                                defaultValue="in_transit"
                              >
                                <option value="pending">Pending</option>
                                <option value="in_transit">On the Way</option>
                                <option value="out_for_delivery">Out for Delivery</option>
                                <option value="delivered">Delivered</option>
                              </select>
                            </div>
                            <div>
                              <label className="text-xs text-muted-foreground">Location</label>
                              <Input
                                id="courier-location"
                                placeholder="e.g., Istanbul, Turkey"
                                className="mt-1 text-sm"
                              />
                            </div>
                            <div>
                              <label className="text-xs text-muted-foreground">Estimated Delivery (Optional)</label>
                              <Input id="courier-delivery" type="date" className="mt-1 text-sm" />
                            </div>
                            <Button
                              size="sm"
                              onClick={() => {
                                const status = (document.getElementById("courier-status") as HTMLSelectElement).value
                                const location = (document.getElementById("courier-location") as HTMLInputElement).value
                                const delivery = (document.getElementById("courier-delivery") as HTMLInputElement).value

                                if (!location.trim()) {
                                  alert("Please enter location information")
                                  return
                                }

                                handleManualCourierUpdate(status, location, delivery || undefined)
                                alert("Shipment status updated!")

                                // Clear form
                                ;(document.getElementById("courier-location") as HTMLInputElement).value = ""
                                ;(document.getElementById("courier-delivery") as HTMLInputElement).value = ""
                              }}
                              className="w-full"
                            >
                              Update Status
                            </Button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </Card>
              )}

              <Card className="p-4 sm:p-6">
                <div className="flex items-center gap-2 mb-3 sm:mb-4">
                  <MessageSquare className="h-5 w-5" />
                  <h3 className="font-semibold text-sm sm:text-base">Notes</h3>
                </div>
                <div className="space-y-3">
                  {selectedShipment.notes && selectedShipment.notes.length > 0 ? (
                    selectedShipment.notes.map((note) => (
                      <div key={note.id} className="p-3 bg-slate-50 rounded-lg">
                        <p className="text-sm">{note.text}</p>
                        <div className="flex items-center justify-between mt-2">
                          <p className="text-xs text-muted-foreground">
                            {new Date(note.createdAt).toLocaleString("en-US")}
                            {note.author && ` - ${note.author}`}
                          </p>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteNote(note.id)}
                            className="h-6 px-2 text-xs text-red-500 hover:text-red-700"
                          >
                            Delete
                          </Button>
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-muted-foreground italic">No notes added yet</p>
                  )}
                  <div className="flex gap-2">
                    <Input
                      type="text"
                      placeholder="Add a note..."
                      value={noteText}
                      onChange={(e) => setNoteText(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          handleAddNote()
                        }
                      }}
                      className="text-sm"
                    />
                    <Button onClick={handleAddNote} size="sm">
                      Add
                    </Button>
                  </div>
                </div>
              </Card>

              {selectedShipment.statusHistory && selectedShipment.statusHistory.length > 0 && (
                <Card className="p-4 sm:p-6">
                  <div className="flex items-center gap-2 mb-3 sm:mb-4">
                    <History className="h-5 w-5" />
                    <h3 className="font-semibold text-sm sm:text-base">Status History</h3>
                  </div>
                  <div className="space-y-2">
                    {selectedShipment.statusHistory.map((entry, index) => {
                      const statusLabels = {
                        toload: "To Load",
                        ontheway: "On the Way",
                        arrived: "Arrived",
                        completed: "Import Completed",
                      }
                      return (
                        <div key={index} className="flex items-center justify-between p-2 bg-slate-50 rounded text-sm">
                          <span className="font-medium">{statusLabels[entry.status as keyof typeof statusLabels]}</span>
                          <span className="text-xs text-muted-foreground">
                            {new Date(entry.changedAt).toLocaleString("en-US")}
                            {entry.changedBy && ` - ${entry.changedBy}`}
                          </span>
                        </div>
                      )
                    })}
                  </div>
                </Card>
              )}

              <Card className="p-4 sm:p-6 md:col-span-2">
                <h3 className="font-semibold mb-3 sm:mb-4 text-sm sm:text-base">Documents</h3>
                <DocumentUpload
                  shipment={selectedShipment}
                  onUpload={(doc) => handleUploadDocument(selectedShipment.id, doc)}
                  onDelete={(docId) => handleDeleteDocument(selectedShipment.id, docId)}
                />
              </Card>
            </div>
          </div>
        )}

        {/* Added Shipping Lines View */}
        {view === "shipping-lines" && (
          <div className="space-y-4 sm:space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <h2 className="text-xl sm:text-2xl font-bold">Shipping Lines</h2>
              <Button
                onClick={() => {
                  setEditingShippingLine(undefined)
                  setView("shipping-line-form")
                }}
                size="sm"
                className="w-full sm:w-auto"
              >
                Add Shipping Line
              </Button>
            </div>
            <ShippingLinesTable
              shippingLines={shippingLines}
              shipmentCounts={shipmentCountsByCarrier}
              onEdit={handleEditShippingLine}
              onDelete={handleDeleteShippingLine}
            />
          </div>
        )}

        {/* Added Shipping Line Form View */}
        {view === "shipping-line-form" && (
          <div className="space-y-4 sm:space-y-6">
            <h2 className="text-xl sm:text-2xl font-bold">
              {editingShippingLine ? "Edit Shipping Line" : "Add New Shipping Line"}
            </h2>
            <Card className="p-4 sm:p-6">
              <ShippingLineForm
                onSubmit={handleAddShippingLine}
                initialData={editingShippingLine}
                onCancel={() => setView("shipping-lines")}
                initialName={prefilledCarrierName}
              />
            </Card>
          </div>
        )}

        {view === "recycle-bin" && (
          <div className="space-y-4 sm:space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <h2 className="text-xl sm:text-2xl font-bold">Recycle Bin</h2>
              <p className="text-sm text-muted-foreground">
                {deletedShipments.length} deleted {deletedShipments.length === 1 ? "shipment" : "shipments"}
              </p>
            </div>
            <Card className="p-4 sm:p-6">
              <RecycleBinTable
                deletedShipments={deletedShipments}
                companies={companies}
                onRestore={handleRestoreShipment}
                onPermanentDelete={handlePermanentDelete}
              />
            </Card>
          </div>
        )}
      </main>

      <DeleteConfirmationDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen} onConfirm={confirmDelete} />

      <footer className="text-[10px] text-gray-400 p-2">BUILD CHECK: {new Date().toLocaleString()}</footer>
    </div>
  )
}
