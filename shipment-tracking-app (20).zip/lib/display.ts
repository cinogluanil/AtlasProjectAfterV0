export function displayInvoiceBL(s: any) {
  const inv = (s?.invoiceNo ?? s?.invoiceNumber ?? "").toString().trim()
  const blCandidate =
    s?.blNo ?? s?.billOfLading ?? s?.bl ?? (Array.isArray(s?.billOfLadingNumbers) ? s.billOfLadingNumbers[0] : "") ?? ""

  const bl = (blCandidate ?? "").toString().trim()

  return `${inv || "N/A"} • ${bl || "N/A"}`
}
