export interface Supplier {
  id: string
  name: string
  email: string
  phone: string
  address: string
  city: string
  country: string
  createdAt: Date
}

export interface Company {
  id: string
  name: string
}

export interface Document {
  id: string
  name: string
  type: string
  size: number
  uploadedAt: Date
  shipmentId: string
  url: string
  data?: string
}

export interface Note {
  id: string
  text: string
  createdAt: Date
  author?: string
}

export interface StatusHistoryEntry {
  status: "yüklenecek" | "yolda" | "vardı" | "ithalatı-bitti"
  changedAt: Date
  changedBy?: string
}

export interface CourierTrackingStatus {
  status: string
  statusDescription: string
  lastUpdate: string
  location?: string
  estimatedDelivery?: string
  events?: Array<{
    status: string
    location: string
    timestamp: string
    description: string
  }>
}

export interface ContainerTrackingStatus {
  status: string
  statusDescription: string
  lastUpdate: string
  location?: string
  estimatedArrival?: string
  vessel?: string
  events?: Array<{
    status: string
    location: string
    timestamp: string
    description: string
  }>
}

export interface Shipment {
  id: string
  supplier: string
  product: string
  firmaId: string
  originCountry: string
  status: "toLoad" | "onTheWay" | "arrived" | "completed"
  estimatedLoading: Date
  actualDelivery?: Date
  createdAt: Date
  documents: Document[]
  customer?: string
  carrier?: string
  ourOrderNumber?: string
  supplierOrderNumber?: string
  invoiceNumber?: string
  billOfLadingNumbers?: string[]
  estimatedDepartureDate?: Date
  estimatedArrivalDate?: Date
  notes?: Note[]
  statusHistory?: StatusHistoryEntry[]
  courierCompany?: string
  courierTrackingNumber?: string
  courierTrackingStatus?: CourierTrackingStatus
}

export interface DeletedShipment extends Shipment {
  deletedAt: Date
  reason?: string
}

export interface ShippingLine {
  id: string
  name: string
  code?: string
  website?: string
  createdAt: Date
}
