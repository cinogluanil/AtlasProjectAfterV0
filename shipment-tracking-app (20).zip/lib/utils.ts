import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function getCourierTrackingUrl(courierCompany: string, trackingNumber: string): string {
  const company = courierCompany.toLowerCase()

  if (company.includes("dhl")) {
    return `https://www.dhl.com/tr-tr/home/tracking.html?tracking-id=${trackingNumber}`
  } else if (company.includes("ups")) {
    return `https://www.ups.com/track?tracknum=${trackingNumber}`
  } else if (company.includes("fedex")) {
    return `https://www.fedex.com/fedextrack/?trknbr=${trackingNumber}`
  } else if (company.includes("aramex")) {
    return `https://www.aramex.com/track/results?ShipmentNumber=${trackingNumber}`
  } else if (company.includes("tnt")) {
    return `https://www.tnt.com/express/tr_tr/site/shipping-tools/tracking.html?searchType=con&cons=${trackingNumber}`
  } else if (company.includes("dpd")) {
    return `https://www.dpd.com/tr/tr/takip/?parcelNumber=${trackingNumber}`
  }

  // Default: Google search for tracking number
  return `https://www.google.com/search?q=${encodeURIComponent(courierCompany + " " + trackingNumber + " tracking")}`
}
