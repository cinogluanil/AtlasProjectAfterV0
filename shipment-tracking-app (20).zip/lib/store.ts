import type { Supplier, Shipment, Company, ShippingLine } from "./types"

const SUPPLIERS_KEY = "shipment_suppliers"
const COMPANIES_KEY = "shipment_companies"
const SHIPMENTS_KEY = "shipment_shipments"
const DELETED_SHIPMENTS_KEY = "shipment_deleted_shipments"
const SUPPLIERS_LIST_KEY = "shipment_suppliers_list"
const COUNTRIES_KEY = "shipment_countries"
const CARRIERS_KEY = "shipment_carriers"
const SHIPPING_LINES_KEY = "shipment_shipping_lines"
const INITIALIZED_KEY = "shipment_initialized"

const DEFAULT_SUPPLIERS: Supplier[] = [
  {
    id: "1",
    name: "Antik Kuruyemiş",
    email: "info@antikkuruyemis.com",
    phone: "+90 212 XXX XXXX",
    address: "",
    city: "",
    country: "Turkey",
    createdAt: new Date(),
  },
  {
    id: "2",
    name: "Emir Nuts",
    email: "contact@emirnuts.com",
    phone: "+90 216 XXX XXXX",
    address: "",
    city: "",
    country: "Turkey",
    createdAt: new Date(),
  },
  {
    id: "3",
    name: "Asya Pasifik",
    email: "sales@asyapasifik.com",
    phone: "+90 212 XXX XXXX",
    address: "",
    city: "",
    country: "Turkey",
    createdAt: new Date(),
  },
  {
    id: "4",
    name: "Atlas Agro",
    email: "info@atlasagro.com",
    phone: "+90 216 XXX XXXX",
    address: "",
    city: "",
    country: "Turkey",
    createdAt: new Date(),
  },
  {
    id: "5",
    name: "Antik Global",
    email: "export@antikglobal.com",
    phone: "+90 212 XXX XXXX",
    address: "",
    city: "",
    country: "Turkey",
    createdAt: new Date(),
  },
]

const DEFAULT_COMPANIES: Company[] = [
  { id: "c1", name: "Antik Kuruyemiş" },
  { id: "c2", name: "Emir Nuts" },
  { id: "c3", name: "Asya Pasifik" },
  { id: "c4", name: "Atlas Agro" },
  { id: "c5", name: "Antik Global" },
]

const DEFAULT_SUPPLIERS_LIST: string[] = [
  "SG Agro",
  "Horchani Dattes",
  "Al-Tahhan Golden Dates",
  "Namagro",
  "Arab African Trading Center",
  "Emirates Delight",
  "Tan Long",
  "Hadiklaim",
  "Mazaya for Dates",
  "Abu Jaber",
  "Nakheel Palestine",
  "Linah Farms",
  "Hangjinhouqi Yongtaifeng",
  "SHARIKAT MAZARE FALASTEEN LETOMOUR ALMEJOUL",
  "Minerva",
  "Select Harvest",
  "Rpac LLC",
  "Baoqing County Jinxingyuan",
  "Alraeed Dates",
  "Richcom",
  "Inner Mongolia Hongxing Industry",
  "Summit Almonds",
  "Baoqing Huabao",
  "Inner Mongolia Li Niuniu Food",
  "Inner Mongolia Kexin Foods",
  "Al Rawan",
  "Rova El Zaher",
  "ATACAMA DRIED FRUIT SPA",
  "LAMICO",
  "Baoqing Xingda",
  "Hanfimex",
  "Sheng Feng",
  "Bayannaoer Long Xing",
  "Inner Mongolia Aodong Trading",
  "HANGJINHOUQI CHANGSHI FOOD CO.,LTD",
  "Calbu",
  "Goodvalley",
  "SVC",
  "Al-Ghazal Dates Co.",
  "Al Yasmin For Import And Export",
  "LongSon",
  "Chris",
  "Al Kotof",
  "Prosi",
  "Palm Hills",
  "Pal Gardens",
  "Gastaldi",
  "Edekhar for agricultural investment",
  "Valency",
  "Vinapro",
  "Pacific",
  "Afri Ventures",
  "N.B AGRI",
  "Atlas",
  "KINGLAND CO.,LTD",
  "DALIAN HAPPY FARM NATURAL PRODUCTS CO.,LTD.",
  "HANGJINHOUQI XINGLONG AGRICULTURAL TRADE CO LTD",
]

const DEFAULT_COUNTRIES: string[] = ["Vietnam", "USA", "Jordan", "China", "Israel", "Palestine", "Egypt"]

const DEFAULT_CARRIERS: string[] = [
  "Maersk",
  "CMA CGM",
  "MSC",
  "COSCO",
  "Hapag-Lloyd",
  "Evergreen",
  "ONE",
  "Yang Ming",
  "HMM",
  "Arkas",
  "ZIM",
]

const COUNTRY_NAME_MAP: Record<string, string> = {
  ürdün: "Jordan",
  urdun: "Jordan",
  çin: "China",
  cin: "China",
  vietnam: "Vietnam",
  mısır: "Egypt",
  misir: "Egypt",
  filistin: "Palestine",
  israil: "Israel",
  i̇srail: "Israel", // Turkish lowercase i with dot
  İsrail: "Israel", // Turkish uppercase İ
  isrâil: "Israel", // Alternative spelling
  amerika: "USA",
  abd: "USA",
  türkiye: "Turkey",
  turkiye: "Turkey",
  hindistan: "India",
  iran: "Iran",
  irak: "Iraq",
  suriye: "Syria",
  lübnan: "Lebanon",
  lubnan: "Lebanon",
  "suudi arabistan": "Saudi Arabia",
  "birleşik arap emirlikleri": "UAE",
  "birlesmis arap emirlikleri": "UAE",
  bae: "UAE",
  yemen: "Yemen",
  kuveyt: "Kuwait",
  katar: "Qatar",
  bahreyn: "Bahrain",
  umman: "Oman",
  afganistan: "Afghanistan",
  pakistan: "Pakistan",
  bangladeş: "Bangladesh",
  banglades: "Bangladesh",
  tayland: "Thailand",
  endonezya: "Indonesia",
  malezya: "Malaysia",
  singapur: "Singapore",
  filipinler: "Philippines",
  japonya: "Japan",
  "güney kore": "South Korea",
  "guney kore": "South Korea",
  "kuzey kore": "North Korea",
  moğolistan: "Mongolia",
  mogolistan: "Mongolia",
  rusya: "Russia",
  ukrayna: "Ukraine",
  polonya: "Poland",
  almanya: "Germany",
  fransa: "France",
  ispanya: "Spain",
  italya: "Italy",
  ingiltere: "United Kingdom",
  hollanda: "Netherlands",
  belçika: "Belgium",
  belcika: "Belgium",
  isviçre: "Switzerland",
  isvicre: "Switzerland",
  avusturya: "Austria",
  yunanistan: "Greece",
  romanya: "Romania",
  bulgaristan: "Bulgaria",
  sırbistan: "Serbia",
  sirbistan: "Serbia",
  hırvatistan: "Croatia",
  hirvatistan: "Croatia",
  slovenya: "Slovenia",
  macaristan: "Hungary",
  "çek cumhuriyeti": "Czech Republic",
  "cek cumhuriyeti": "Czech Republic",
  slovakya: "Slovakia",
  norveç: "Norway",
  norvec: "Norway",
  isveç: "Sweden",
  isvec: "Sweden",
  finlandiya: "Finland",
  danimarka: "Denmark",
  portekiz: "Portugal",
  fas: "Morocco",
  cezayir: "Algeria",
  tunus: "Tunisia",
  libya: "Libya",
  sudan: "Sudan",
  etiyopya: "Ethiopia",
  kenya: "Kenya",
  tanzanya: "Tanzania",
  uganda: "Uganda",
  "güney afrika": "South Africa",
  "guney afrika": "South Africa",
  nijerya: "Nigeria",
  gana: "Ghana",
  "fildişi sahili": "Ivory Coast",
  "fildisi sahili": "Ivory Coast",
  senegal: "Senegal",
  kamerun: "Cameroon",
  zimbabve: "Zimbabwe",
  mozambik: "Mozambique",
  angola: "Angola",
  brezilya: "Brazil",
  arjantin: "Argentina",
  şili: "Chile",
  sili: "Chile",
  kolombiya: "Colombia",
  peru: "Peru",
  venezüella: "Venezuela",
  venezuella: "Venezuela",
  ekvador: "Ecuador",
  bolivya: "Bolivia",
  paraguay: "Paraguay",
  uruguay: "Uruguay",
  meksika: "Mexico",
  kanada: "Canada",
  küba: "Cuba",
  kuba: "Cuba",
  jamaika: "Jamaica",
  haiti: "Haiti",
  "dominik cumhuriyeti": "Dominican Republic",
  "porto riko": "Puerto Rico",
  "kosta rika": "Costa Rica",
  panama: "Panama",
  guatemala: "Guatemala",
  honduras: "Honduras",
  nikaragua: "Nicaragua",
  "el salvador": "El Salvador",
  avustralya: "Australia",
  "yeni zelanda": "New Zealand",
}

function norm(s: string | undefined | null): string {
  return (s || "").toString().trim().toLowerCase().replace(/\s+/g, " ")
}

export function normStatus(s: string | undefined | null): string {
  return (s || "").toString().trim().toLowerCase()
}

export function normalizeCountryName(country: string | undefined | null): string {
  if (!country) return ""

  const original = country.toString().trim()
  const normalized = original.toLowerCase()

  // Check original first (for uppercase Turkish İ)
  if (COUNTRY_NAME_MAP[original]) {
    return COUNTRY_NAME_MAP[original]
  }

  // Check lowercase version
  if (COUNTRY_NAME_MAP[normalized]) {
    return COUNTRY_NAME_MAP[normalized]
  }

  // Return original with proper capitalization if not found in map
  return original
}

const CANON = {
  toLoad: "toLoad",
  onTheWay: "onTheWay",
  arrived: "arrived",
  completed: "completed",
}

export function toCanonStatus(s: string | undefined | null): string {
  const v = (s || "").toLowerCase().trim()

  // English variants
  if (["to load", "toload", "loading", "yuklenecek", "yükleme", "yüklenecek"].includes(v)) return CANON.toLoad
  if (["on the way", "ontheway", "in-transit", "yolda", "in transit"].includes(v)) return CANON.onTheWay
  if (["arrived", "arrival", "arrive", "varmış", "varmis", "varis", "vardı"].includes(v)) return CANON.arrived
  if (
    [
      "completed",
      "done",
      "import completed",
      "ithalat bitti",
      "ithalatı bitti",
      "ithalatı-bitti",
      "ithalati-bitmis",
      "complied",
    ].includes(v)
  )
    return CANON.completed

  // Handle transit as onTheWay
  if (["transit", "aktarma", "aktarmada", "yolda-transit"].includes(v)) return CANON.onTheWay

  return v || CANON.toLoad
}

export const store = {
  initialize: () => {
    if (typeof window === "undefined") return

    const initialized = localStorage.getItem(INITIALIZED_KEY)
    if (!initialized) {
      localStorage.setItem(SUPPLIERS_KEY, JSON.stringify(DEFAULT_SUPPLIERS))
      localStorage.setItem(COMPANIES_KEY, JSON.stringify(DEFAULT_COMPANIES))
      localStorage.setItem(SHIPMENTS_KEY, JSON.stringify([]))
      localStorage.setItem(DELETED_SHIPMENTS_KEY, JSON.stringify([]))
      localStorage.setItem(SUPPLIERS_LIST_KEY, JSON.stringify(DEFAULT_SUPPLIERS_LIST))
      localStorage.setItem(COUNTRIES_KEY, JSON.stringify(DEFAULT_COUNTRIES))
      localStorage.setItem(CARRIERS_KEY, JSON.stringify(DEFAULT_CARRIERS))
      localStorage.setItem(SHIPPING_LINES_KEY, JSON.stringify([]))
      localStorage.setItem(INITIALIZED_KEY, "true")
    }

    const currentCountries = localStorage.getItem(COUNTRIES_KEY)
    if (currentCountries) {
      try {
        const parsed = JSON.parse(currentCountries)
        // Check if any Turkish country names exist
        const hasTurkish = parsed.some((c: string) => {
          const normalized = c.toLowerCase()
          return COUNTRY_NAME_MAP[normalized] !== undefined
        })

        if (hasTurkish) {
          console.log("[v0] Resetting countries list to English")
          localStorage.setItem(COUNTRIES_KEY, JSON.stringify(DEFAULT_COUNTRIES))
        }
      } catch (e) {
        // If parsing fails, reset to default
        localStorage.setItem(COUNTRIES_KEY, JSON.stringify(DEFAULT_COUNTRIES))
      }
    }
  },

  migrateInvoiceAndBL: () => {
    if (typeof window === "undefined") return

    const MIGRATION_FLAG = "migr_v1_invoice_bl_done"

    if (localStorage.getItem(MIGRATION_FLAG)) {
      console.log("[v0] Invoice/BL migration already completed")
      return
    }

    console.log("[v0] Starting invoice/BL backfill migration...")

    const candidateKeys = ["shipments", "data", "shipmentData", "appState", SHIPMENTS_KEY]
    let shipmentsUpdated = false

    candidateKeys.forEach((key) => {
      try {
        const data = localStorage.getItem(key)
        if (!data) return

        const parsed = JSON.parse(data)
        if (!Array.isArray(parsed)) return

        let updated = false

        parsed.forEach((s: any) => {
          const inv = (s.invoiceNo ?? s.invoiceNumber ?? "").toString().trim()

          const bl = (s.billOfLading ?? s.bl ?? s.blNo ?? s.konsimento ?? s.billOfLadingNumber ?? "").toString().trim()

          if (inv) {
            if (!s.invoiceNo) {
              s.invoiceNo = inv
              updated = true
            }
            if (!s.invoiceNumber) {
              s.invoiceNumber = inv
              updated = true
            }
          }

          if (bl) {
            if (!s.billOfLading) {
              s.billOfLading = bl
              updated = true
            }
            if (!s.bl) {
              s.bl = bl
              updated = true
            }
            if (!s.blNo) {
              s.blNo = bl
              updated = true
            }
            if (!s.konsimento) {
              s.konsimento = bl
              updated = true
            }
          }
        })

        if (updated) {
          localStorage.setItem(key, JSON.stringify(parsed))
          shipmentsUpdated = true
          console.log(`[v0] Backfilled invoice/BL for ${parsed.length} shipments in key: ${key}`)
        }
      } catch (e) {
        console.error(`[v0] Error migrating key ${key}:`, e)
      }
    })

    localStorage.setItem(MIGRATION_FLAG, "true")
    console.log("[v0] Invoice/BL migration completed", { shipmentsUpdated })
  },

  migrateStatusNormalization: () => {
    if (typeof window === "undefined") return

    const MIGRATION_FLAG = "statusMigration_v1_done"

    if (localStorage.getItem(MIGRATION_FLAG)) {
      console.log("[v0] Status normalization migration already completed")
      return
    }

    console.log("[v0] Starting status normalization migration...")

    const candidateKeys = ["shipments", "data", "shipmentData", "appState", SHIPMENTS_KEY]
    let shipmentsUpdated = false

    candidateKeys.forEach((key) => {
      try {
        const data = localStorage.getItem(key)
        if (!data) return

        const parsed = JSON.parse(data)
        if (!Array.isArray(parsed)) return

        let updated = false

        parsed.forEach((s: any) => {
          const oldStatus = s.status
          const newStatus = toCanonStatus(s.status)

          if (oldStatus !== newStatus) {
            s.status = newStatus
            updated = true
          }

          s.isTransit = s.status === "transit"
        })

        if (updated) {
          localStorage.setItem(key, JSON.stringify(parsed))
          shipmentsUpdated = true
          console.log(`[v0] Normalized status for ${parsed.length} shipments in key: ${key}`)
        }
      } catch (e) {
        console.error(`[v0] Error migrating key ${key}:`, e)
      }
    })

    localStorage.setItem(MIGRATION_FLAG, "true")
    console.log("[v0] Status normalization migration completed", { shipmentsUpdated })
  },

  migrateStatusV2: () => {
    if (typeof window === "undefined") return

    const MIGRATION_FLAG = "statusMigration_v2_done"

    if (localStorage.getItem(MIGRATION_FLAG)) {
      console.log("[v0] Status V2 migration already completed")
      return
    }

    console.log("[v0] Starting status V2 migration (with toggle)...")

    const candidateKeys = ["shipments", "data", "shipmentData", "appState", SHIPMENTS_KEY]
    let shipmentsUpdated = false

    candidateKeys.forEach((key) => {
      try {
        const data = localStorage.getItem(key)
        if (!data) return

        const parsed = JSON.parse(data)
        if (!Array.isArray(parsed)) return

        let updated = false

        parsed.forEach((s: any) => {
          const toggle = Boolean(s.isTransit ?? s.transitSale ?? s.transitSatis)

          const oldStatus = s.status
          s.status = toCanonStatus(s.status)

          if (toggle) {
            s.status = "transit"
          }

          s.isTransit = s.status === "transit"

          if (oldStatus !== s.status) {
            updated = true
          }
        })

        if (updated) {
          localStorage.setItem(key, JSON.stringify(parsed))
          shipmentsUpdated = true
          console.log(`[v0] Migrated status V2 for ${parsed.length} shipments in key: ${key}`)
        }
      } catch (e) {
        console.error(`[v0] Error migrating key ${key}:`, e)
      }
    })

    localStorage.setItem(MIGRATION_FLAG, "true")
    console.log("[v0] Status V2 migration completed", { shipmentsUpdated })
  },

  migrateTransitFlag: () => {
    if (typeof window === "undefined") return

    const MIGRATION_FLAG = "transitFlagMigration_v1_done"

    if (localStorage.getItem(MIGRATION_FLAG)) {
      console.log("[v0] Transit flag migration already completed")
      return
    }

    console.log("[v0] Starting transit flag migration...")

    const candidateKeys = ["shipments", "data", "shipmentData", "appState", SHIPMENTS_KEY]
    let shipmentsUpdated = false

    candidateKeys.forEach((key) => {
      try {
        const data = localStorage.getItem(key)
        if (!data) return

        const parsed = JSON.parse(data)
        if (!Array.isArray(parsed)) return

        let updated = false

        parsed.forEach((s: any) => {
          const flag = Boolean(s.isTransit ?? s.transitSale ?? s.transitSatis)

          if (s.isTransitSale !== flag) {
            s.isTransitSale = flag
            updated = true
          }
        })

        if (updated) {
          localStorage.setItem(key, JSON.stringify(parsed))
          shipmentsUpdated = true
          console.log(`[v0] Migrated transit flag for ${parsed.length} shipments in key: ${key}`)
        }
      } catch (e) {
        console.error(`[v0] Error migrating key ${key}:`, e)
      }
    })

    localStorage.setItem(MIGRATION_FLAG, "true")
    console.log("[v0] Transit flag migration completed", { shipmentsUpdated })
  },

  migrateBlankStatuses: () => {
    if (typeof window === "undefined") return

    const MIGRATION_FLAG = "statusBackfill_v1_done"

    if (localStorage.getItem(MIGRATION_FLAG)) {
      console.log("[v0] Blank status backfill already completed")
      return
    }

    console.log("[v0] Starting blank status backfill...")

    const candidateKeys = ["shipments", "data", "shipmentData", "appState", SHIPMENTS_KEY]
    let shipmentsUpdated = false

    candidateKeys.forEach((key) => {
      try {
        const data = localStorage.getItem(key)
        if (!data) return

        const parsed = JSON.parse(data)
        if (!Array.isArray(parsed)) return

        let updated = false

        parsed.forEach((s: any) => {
          const normalized = normStatus(s.status)

          if (!normalized) {
            s.status = "toLoad"
            updated = true
            console.log("[v0] Backfilled blank status for shipment:", s.id)
          }
        })

        if (updated) {
          localStorage.setItem(key, JSON.stringify(parsed))
          shipmentsUpdated = true
          console.log(`[v0] Backfilled blank statuses for shipments in key: ${key}`)
        }
      } catch (e) {
        console.error(`[v0] Error migrating key ${key}:`, e)
      }
    })

    localStorage.setItem(MIGRATION_FLAG, "true")
    console.log("[v0] Blank status backfill completed", { shipmentsUpdated })
  },

  migrateCountryNames: () => {
    if (typeof window === "undefined") return false

    const MIGRATION_FLAG = "countryNameMigration_v3_done"

    if (localStorage.getItem(MIGRATION_FLAG)) {
      console.log("[v0] Country name migration already completed")
      return false
    }

    console.log("[v0] Starting country name normalization migration v3...")

    const candidateKeys = ["shipments", "data", "shipmentData", "appState", SHIPMENTS_KEY]
    let totalUpdated = 0

    candidateKeys.forEach((key) => {
      try {
        const data = localStorage.getItem(key)
        if (!data) return

        const parsed = JSON.parse(data)
        if (!Array.isArray(parsed)) return

        let updated = false

        parsed.forEach((s: any) => {
          // Check all possible country field names
          const fields = ["originCountry", "menşeiÜlke", "menseiUlke", "origin_country", "country"]

          fields.forEach((field) => {
            if (s[field]) {
              const oldCountry = s[field]
              const normalizedCountry = normalizeCountryName(oldCountry)

              if (normalizedCountry && normalizedCountry !== oldCountry) {
                s[field] = normalizedCountry
                updated = true
                totalUpdated++
                console.log(`[v0] Normalized ${field}:`, oldCountry, "→", normalizedCountry)
              }
            }
          })
        })

        if (updated) {
          localStorage.setItem(key, JSON.stringify(parsed))
          console.log(`[v0] Updated ${key} with normalized country names`)
        }
      } catch (e) {
        console.error(`[v0] Error migrating key ${key}:`, e)
      }
    })

    // Remove old migration flags
    localStorage.removeItem("countryNameMigration_v1_done")
    localStorage.removeItem("countryNameMigration_v2_done")

    localStorage.setItem(MIGRATION_FLAG, "true")
    console.log("[v0] Country name migration v3 completed. Total fields updated:", totalUpdated)

    return totalUpdated > 0
  },

  // Suppliers
  getSuppliers: (): Supplier[] => {
    if (typeof window === "undefined") return []
    const data = localStorage.getItem(SUPPLIERS_KEY)
    return data ? JSON.parse(data) : []
  },

  addSupplier: (supplier: Supplier) => {
    if (typeof window === "undefined") return
    const suppliers = store.getSuppliers()
    suppliers.push(supplier)
    localStorage.setItem(SUPPLIERS_KEY, JSON.stringify(suppliers))
    store.addSupplierToList(supplier.name)
  },

  updateSupplier: (id: string, updates: Partial<Supplier>) => {
    if (typeof window === "undefined") return
    const suppliers = store.getSuppliers()
    const index = suppliers.findIndex((s) => s.id === id)
    if (index !== -1) {
      suppliers[index] = { ...suppliers[index], ...updates }
      localStorage.setItem(SUPPLIERS_KEY, JSON.stringify(suppliers))
    }
  },

  deleteSupplier: (id: string) => {
    if (typeof window === "undefined") return
    const suppliers = store.getSuppliers()
    const filtered = suppliers.filter((s) => s.id !== id)
    localStorage.setItem(SUPPLIERS_KEY, JSON.stringify(filtered))
  },

  getCompanies: (): Company[] => {
    if (typeof window === "undefined") return []
    const data = localStorage.getItem(COMPANIES_KEY)
    return data ? JSON.parse(data) : DEFAULT_COMPANIES
  },

  getSuppliersList: (): string[] => {
    if (typeof window === "undefined") return []
    const data = localStorage.getItem(SUPPLIERS_LIST_KEY)
    const storedList = data ? JSON.parse(data) : []
    const merged = Array.from(new Set([...DEFAULT_SUPPLIERS_LIST, ...storedList]))
    return merged
  },

  addSupplierToList: (name: string) => {
    if (typeof window === "undefined") return
    const list = store.getSuppliersList()
    if (!list.includes(name)) {
      list.push(name)
      localStorage.setItem(SUPPLIERS_LIST_KEY, JSON.stringify(list))
    }
  },

  getCarriers: (): string[] => {
    if (typeof window === "undefined") return []
    const data = localStorage.getItem(CARRIERS_KEY)
    return data ? JSON.parse(data) : DEFAULT_CARRIERS
  },

  addCarrier: (name: string) => {
    if (typeof window === "undefined") return
    const list = store.getCarriers()
    if (!list.includes(name)) {
      list.push(name)
      localStorage.setItem(CARRIERS_KEY, JSON.stringify(list))
    }
  },

  // Shipments
  getShipments: (): Shipment[] => {
    if (typeof window === "undefined") return []
    const data = localStorage.getItem(SHIPMENTS_KEY)
    return data ? JSON.parse(data) : []
  },

  addShipment: (shipment: Shipment) => {
    if (typeof window === "undefined") return

    const normalizedShipment = {
      ...shipment,
      status: toCanonStatus(shipment.status) as any,
    }

    console.log("[v0] STATUS_SAVE", shipment.status, "->", normalizedShipment.status)

    store.addSupplierToList(normalizedShipment.supplier)
    if (normalizedShipment.carrier) {
      store.addCarrier(normalizedShipment.carrier)
    }
    const shipments = store.getShipments()
    shipments.push(normalizedShipment)
    localStorage.setItem(SHIPMENTS_KEY, JSON.stringify(shipments))
  },

  updateShipment: (id: string, updates: Partial<Shipment>) => {
    if (typeof window === "undefined") return

    const normalizedUpdates = { ...updates }
    if (updates.status) {
      normalizedUpdates.status = toCanonStatus(updates.status) as any
      console.log("[v0] STATUS_SAVE", updates.status, "->", normalizedUpdates.status)
    }

    if (normalizedUpdates.carrier) {
      store.addCarrier(normalizedUpdates.carrier)
    }
    const shipments = store.getShipments()
    const index = shipments.findIndex((s) => s.id === id)
    if (index !== -1) {
      shipments[index] = { ...shipments[index], ...normalizedUpdates }
      localStorage.setItem(SHIPMENTS_KEY, JSON.stringify(shipments))
    }
  },

  deleteShipment: (id: string) => {
    if (typeof window === "undefined") return
    const shipments = store.getShipments()
    const filtered = shipments.filter((s) => s.id !== id)
    localStorage.setItem(SHIPMENTS_KEY, JSON.stringify(filtered))
  },

  softDeleteShipment: (id: string, reason?: string) => {
    if (typeof window === "undefined") return

    const shipments = store.getShipments()
    const shipment = shipments.find((s) => s.id === id)

    if (!shipment) return

    const filtered = shipments.filter((s) => s.id !== id)
    localStorage.setItem(SHIPMENTS_KEY, JSON.stringify(filtered))

    const deletedShipments = store.getDeletedShipments()
    const deletedShipment = {
      ...shipment,
      deletedAt: new Date(),
      reason: reason || undefined,
    }
    deletedShipments.push(deletedShipment)
    localStorage.setItem(DELETED_SHIPMENTS_KEY, JSON.stringify(deletedShipments))

    console.log("[v0] Soft-deleted shipment:", id)
  },

  getDeletedShipments: (): any[] => {
    if (typeof window === "undefined") return []
    const data = localStorage.getItem(DELETED_SHIPMENTS_KEY)
    return data ? JSON.parse(data) : []
  },

  restoreShipment: (id: string) => {
    if (typeof window === "undefined") return

    const deletedShipments = store.getDeletedShipments()
    const shipment = deletedShipments.find((s: any) => s.id === id)

    if (!shipment) return

    const filtered = deletedShipments.filter((s: any) => s.id !== id)
    localStorage.setItem(DELETED_SHIPMENTS_KEY, JSON.stringify(filtered))

    const { deletedAt, reason, ...restoredShipment } = shipment
    const shipments = store.getShipments()
    shipments.push(restoredShipment)
    localStorage.setItem(SHIPMENTS_KEY, JSON.stringify(shipments))

    console.log("[v0] Restored shipment:", id)
  },

  permanentlyDeleteShipment: (id: string) => {
    if (typeof window === "undefined") return

    const deletedShipments = store.getDeletedShipments()
    const filtered = deletedShipments.filter((s: any) => s.id !== id)
    localStorage.setItem(DELETED_SHIPMENTS_KEY, JSON.stringify(filtered))

    console.log("[v0] Permanently deleted shipment:", id)
  },

  getShipmentsBySupplierName: (supplierName: string): Shipment[] => {
    return store.getShipments().filter((s) => s.supplier === supplierName)
  },

  getShipmentsBySupplier: (supplierId: string): Shipment[] => {
    const supplier = store.getSuppliers().find((s) => s.id === supplierId)
    if (!supplier) return []
    return store.getShipments().filter((s) => s.supplier === supplier.name)
  },

  getShipmentCountsByCarrier: (): Record<string, number> => {
    if (typeof window === "undefined") return {}

    const candidateKeys = ["shipments", "data", "shipmentData", "appState", SHIPMENTS_KEY]
    const allShipments: any[] = []

    candidateKeys.forEach((key) => {
      try {
        const data = localStorage.getItem(key)
        if (data) {
          const parsed = JSON.parse(data)
          if (Array.isArray(parsed)) {
            allShipments.push(...parsed)
          }
        }
      } catch (e) {
        // Ignore parse errors
      }
    })

    const counts: Record<string, number> = {}

    allShipments.forEach((rec) => {
      const carrierName = rec.armator || rec.carrier || rec.shippingLine
      if (carrierName) {
        const normalized = norm(carrierName)
        if (normalized) {
          counts[normalized] = (counts[normalized] || 0) + 1
        }
      }
    })

    const sample = Object.entries(counts).slice(0, 3)
    console.log("[v0] ARMATOR_COUNTS_SAMPLE", sample)

    return counts
  },

  // Countries
  getCountries: (): string[] => {
    if (typeof window === "undefined") return []
    const data = localStorage.getItem(COUNTRIES_KEY)
    const countries = data ? JSON.parse(data) : DEFAULT_COUNTRIES

    return countries.map((c: string) => {
      const normalized = normalizeCountryName(c)
      return normalized || c
    })
  },

  // Shipping Lines
  getShippingLines: (): ShippingLine[] => {
    if (typeof window === "undefined") return []
    const data = localStorage.getItem(SHIPPING_LINES_KEY)
    return data ? JSON.parse(data) : []
  },

  addShippingLine: (shippingLine: ShippingLine) => {
    if (typeof window === "undefined") return
    const shippingLines = store.getShippingLines()
    shippingLines.push(shippingLine)
    localStorage.setItem(SHIPPING_LINES_KEY, JSON.stringify(shippingLines))
    store.addCarrier(shippingLine.name)
  },

  updateShippingLine: (id: string, updates: Partial<ShippingLine>) => {
    if (typeof window === "undefined") return
    const shippingLines = store.getShippingLines()
    const index = shippingLines.findIndex((s) => s.id === id)
    if (index !== -1) {
      shippingLines[index] = { ...shippingLines[index], ...updates }
      localStorage.setItem(SHIPPING_LINES_KEY, JSON.stringify(shippingLines))
    }
  },

  deleteShippingLine: (id: string) => {
    if (typeof window === "undefined") return
    const shippingLines = store.getShippingLines()
    const filtered = shippingLines.filter((s) => s.id !== id)
    localStorage.setItem(SHIPPING_LINES_KEY, JSON.stringify(filtered))
  },

  SEED_SHIPPING_LINES: ["Maersk", "MSC", "CMA CGM", "Hapag-Lloyd", "COSCO", "Evergreen", "ONE"],

  mergeShippingLinesFromAllSources: () => {
    if (typeof window === "undefined") return

    console.log("[v0] Merging shipping lines from all sources...")

    const fromSeed: ShippingLine[] = store.SEED_SHIPPING_LINES.map((name) => ({
      id: crypto.randomUUID(),
      name,
      createdAt: new Date().toISOString(),
    }))

    const candidateKeys = ["shipments", "data", "shipmentData", "appState", SHIPMENTS_KEY]
    const allShipments: any[] = []

    candidateKeys.forEach((key) => {
      try {
        const data = localStorage.getItem(key)
        if (data) {
          const parsed = JSON.parse(data)
          if (Array.isArray(parsed)) {
            allShipments.push(...parsed)
          }
        }
      } catch (e) {
        // Ignore parse errors
      }
    })

    const discoveredNames = new Set<string>()
    allShipments.forEach((rec) => {
      const carrierName = rec.armator || rec.carrier || rec.shippingLine
      if (carrierName) {
        const normalized = norm(carrierName)
        if (normalized) {
          discoveredNames.add(carrierName.trim())
        }
      }
    })

    const fromShipments: ShippingLine[] = Array.from(discoveredNames).map((name) => ({
      id: crypto.randomUUID(),
      name,
      createdAt: new Date().toISOString(),
    }))

    const existing = store.getShippingLines()

    const mergedMap = new Map<string, ShippingLine>()

    existing.forEach((line) => {
      mergedMap.set(norm(line.name), line)
    })

    fromSeed.forEach((line) => {
      const key = norm(line.name)
      if (!mergedMap.has(key)) {
        mergedMap.set(key, line)
      }
    })

    fromShipments.forEach((line) => {
      const key = norm(line.name)
      if (!mergedMap.has(key)) {
        mergedMap.set(key, line)
      }
    })

    const merged = Array.from(mergedMap.values())

    const existingNormalized = new Set(existing.map((l) => norm(l.name)))
    const mergedNormalized = new Set(merged.map((l) => norm(l.name)))

    if (existingNormalized.size !== mergedNormalized.size) {
      localStorage.setItem(SHIPPING_LINES_KEY, JSON.stringify(merged))
      console.log("[v0] ARMATOR_TOTAL", merged.length)
    } else {
      console.log("[v0] ARMATOR_TOTAL", merged.length, "(no changes)")
    }
  },
}
