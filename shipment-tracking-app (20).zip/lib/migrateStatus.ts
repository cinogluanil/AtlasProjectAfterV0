export function migrateStatuses() {
  if (typeof window === "undefined") return

  const MIGRATION_FLAG = "statusMigration_english_v1_done"

  // Check if migration already ran
  if (localStorage.getItem(MIGRATION_FLAG)) {
    console.log("[v0] English status migration already completed")
    return
  }

  console.log("[v0] Starting English status migration...")

  const keys = Object.keys(localStorage)
  let totalMigrated = 0

  for (const key of keys) {
    try {
      const raw = localStorage.getItem(key)
      if (!raw) continue
      const data = JSON.parse(raw)
      if (!Array.isArray(data)) continue

      let changed = false
      for (const item of data) {
        if (item && typeof item === "object" && item.status) {
          const oldStatus = item.status
          switch (item.status) {
            case "yuklenecek":
              item.status = "toLoad"
              changed = true
              break
            case "yolda":
              item.status = "onTheWay"
              changed = true
              break
            case "varmis":
              item.status = "arrived"
              changed = true
              break
            case "ithalati-bitmis":
              item.status = "completed"
              changed = true
              break
          }
          if (changed && oldStatus !== item.status) {
            console.log(`[v0] Migrated status: ${oldStatus} → ${item.status}`)
            totalMigrated++
          }
        }
      }
      if (changed) {
        localStorage.setItem(key, JSON.stringify(data))
        console.log(`[v0] Updated ${data.length} items in key: ${key}`)
      }
    } catch {
      // Ignore parse errors
    }
  }

  // Set flag to prevent re-running
  localStorage.setItem(MIGRATION_FLAG, "true")
  console.log(`[v0] English status migration completed. Total migrated: ${totalMigrated}`)
}
