"use client"

import { useState, useEffect, useCallback } from "react"
import type { Supplier, Shipment, Company, ShippingLine } from "@/lib/types"
import { store } from "@/lib/store"

export function useSuppliers() {
  const [suppliers, setSuppliers] = useState<Supplier[]>([])
  const [loading, setLoading] = useState(true)

  const loadSuppliers = useCallback(() => {
    setSuppliers(store.getSuppliers())
    setLoading(false)
  }, [])

  useEffect(() => {
    loadSuppliers()
  }, [loadSuppliers])

  const addSupplier = useCallback(
    (supplier: Supplier) => {
      store.addSupplier(supplier)
      loadSuppliers()
    },
    [loadSuppliers],
  )

  const updateSupplier = useCallback(
    (id: string, updates: Partial<Supplier>) => {
      store.updateSupplier(id, updates)
      loadSuppliers()
    },
    [loadSuppliers],
  )

  const deleteSupplier = useCallback(
    (id: string) => {
      store.deleteSupplier(id)
      loadSuppliers()
    },
    [loadSuppliers],
  )

  return { suppliers, loading, addSupplier, updateSupplier, deleteSupplier }
}

export function useShipments() {
  const [shipments, setShipments] = useState<Shipment[]>([])
  const [loading, setLoading] = useState(true)

  const loadShipments = useCallback(() => {
    setShipments(store.getShipments())
    setLoading(false)
  }, [])

  useEffect(() => {
    loadShipments()
  }, [loadShipments])

  const addShipment = useCallback(
    (shipment: Shipment) => {
      store.addShipment(shipment)
      loadShipments()
    },
    [loadShipments],
  )

  const updateShipment = useCallback(
    (id: string, updates: Partial<Shipment>) => {
      store.updateShipment(id, updates)
      loadShipments()
    },
    [loadShipments],
  )

  const deleteShipment = useCallback(
    (id: string) => {
      store.deleteShipment(id)
      loadShipments()
    },
    [loadShipments],
  )

  const softDeleteShipment = useCallback(
    (id: string, reason?: string) => {
      store.softDeleteShipment(id, reason)
      loadShipments()
    },
    [loadShipments],
  )

  const restoreShipment = useCallback(
    (id: string) => {
      store.restoreShipment(id)
      loadShipments()
    },
    [loadShipments],
  )

  const permanentlyDeleteShipment = useCallback(
    (id: string) => {
      store.permanentlyDeleteShipment(id)
      loadShipments()
    },
    [loadShipments],
  )

  const getShipmentsBySupplier = useCallback((supplierId: string) => {
    return store.getShipmentsBySupplier(supplierId)
  }, [])

  const reload = useCallback(() => {
    loadShipments()
  }, [loadShipments])

  return {
    shipments,
    loading,
    addShipment,
    updateShipment,
    deleteShipment,
    softDeleteShipment,
    restoreShipment,
    permanentlyDeleteShipment,
    getShipmentsBySupplier,
    reload,
  }
}

export function useMetadata() {
  const [companies, setCompanies] = useState<Company[]>([])
  const [suppliersList, setSuppliersList] = useState<string[]>([])
  const [countries, setCountries] = useState<string[]>([])
  const [carriers, setCarriers] = useState<string[]>([])
  const [loading, setLoading] = useState(true)

  const loadMetadata = useCallback(() => {
    setCompanies(store.getCompanies())
    setSuppliersList(store.getSuppliersList())
    setCountries(store.getCountries())
    setCarriers(store.getCarriers())
    setLoading(false)
  }, [])

  useEffect(() => {
    loadMetadata()
  }, [loadMetadata])

  return { companies, suppliersList, countries, carriers, loading, reload: loadMetadata }
}

export function useShippingLines() {
  const [shippingLines, setShippingLines] = useState<ShippingLine[]>([])
  const [loading, setLoading] = useState(true)

  const loadShippingLines = useCallback(() => {
    setShippingLines(store.getShippingLines())
    setLoading(false)
  }, [])

  useEffect(() => {
    loadShippingLines()
  }, [loadShippingLines])

  const addShippingLine = useCallback(
    (shippingLine: ShippingLine) => {
      store.addShippingLine(shippingLine)
      loadShippingLines()
    },
    [loadShippingLines],
  )

  const updateShippingLine = useCallback(
    (id: string, updates: Partial<ShippingLine>) => {
      store.updateShippingLine(id, updates)
      loadShippingLines()
    },
    [loadShippingLines],
  )

  const deleteShippingLine = useCallback(
    (id: string) => {
      store.deleteShippingLine(id)
      loadShippingLines()
    },
    [loadShippingLines],
  )

  return { shippingLines, loading, addShippingLine, updateShippingLine, deleteShippingLine }
}
