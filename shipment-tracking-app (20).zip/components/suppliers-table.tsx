"use client"

import type { Supplier } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface SuppliersTableProps {
  suppliers: Supplier[]
  onEdit: (supplier: Supplier) => void
  onDelete: (id: string) => void
  onViewShipments: (supplier: Supplier) => void
}

export function SuppliersTable({ suppliers, onEdit, onDelete, onViewShipments }: SuppliersTableProps) {
  if (suppliers.length === 0) {
    return (
      <Card className="p-6 sm:p-8 flex items-center justify-center min-h-[200px]">
        <p className="text-muted-foreground text-sm opacity-60">No records yet</p>
      </Card>
    )
  }

  return (
    <>
      <div className="hidden md:block overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b">
              <th className="text-left py-3 px-4 font-semibold text-sm">Name</th>
              <th className="text-left py-3 px-4 font-semibold text-sm">Email</th>
              <th className="text-left py-3 px-4 font-semibold text-sm">Phone</th>
              <th className="text-left py-3 px-4 font-semibold text-sm">Location</th>
              <th className="text-left py-3 px-4 font-semibold text-sm">Notes</th>
              <th className="text-right py-3 px-4 font-semibold text-sm">Actions</th>
            </tr>
          </thead>
          <tbody>
            {suppliers.map((supplier) => (
              <tr key={supplier.id} className="border-b hover:bg-muted/50">
                <td className="py-3 px-4 text-sm">{supplier.name}</td>
                <td className="py-3 px-4 text-sm">{supplier.email}</td>
                <td className="py-3 px-4 text-sm">{supplier.phone}</td>
                <td className="py-3 px-4 text-sm">
                  {supplier.city}, {supplier.country}
                </td>
                <td className="py-3 px-4 text-sm">
                  {supplier.notes ? (
                    <span className="text-muted-foreground">{supplier.notes}</span>
                  ) : (
                    <span className="text-muted-foreground/50 italic">-</span>
                  )}
                </td>
                <td className="py-3 px-4 text-right">
                  <div className="flex gap-2 justify-end">
                    <Button size="sm" variant="outline" onClick={() => onViewShipments(supplier)}>
                      Shipments
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => onEdit(supplier)}>
                      Edit
                    </Button>
                    <Button size="sm" variant="destructive" onClick={() => onDelete(supplier.id)}>
                      Delete
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="md:hidden space-y-3">
        {suppliers.map((supplier) => (
          <Card key={supplier.id} className="p-4">
            <div className="space-y-2">
              <div>
                <p className="font-semibold text-sm">{supplier.name}</p>
                <p className="text-xs text-muted-foreground">
                  {supplier.city}, {supplier.country}
                </p>
              </div>

              <div className="space-y-1 text-xs">
                {supplier.email && (
                  <div>
                    <p className="text-muted-foreground">Email</p>
                    <p className="font-medium truncate">{supplier.email}</p>
                  </div>
                )}
                {supplier.phone && (
                  <div>
                    <p className="text-muted-foreground">Phone</p>
                    <p className="font-medium">{supplier.phone}</p>
                  </div>
                )}
                {supplier.notes && (
                  <div>
                    <p className="text-muted-foreground">Notes</p>
                    <p className="font-medium">{supplier.notes}</p>
                  </div>
                )}
              </div>

              <div className="flex gap-2 pt-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => onViewShipments(supplier)}
                  className="flex-1 text-xs"
                >
                  Shipments
                </Button>
                <Button size="sm" variant="outline" onClick={() => onEdit(supplier)} className="flex-1 text-xs">
                  Edit
                </Button>
                <Button size="sm" variant="destructive" onClick={() => onDelete(supplier.id)} className="text-xs">
                  Delete
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </>
  )
}
