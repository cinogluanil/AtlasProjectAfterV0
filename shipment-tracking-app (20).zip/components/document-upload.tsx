"use client"

import type React from "react"

import { useState } from "react"
import type { Document, Shipment } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface DocumentUploadProps {
  shipment: Shipment
  onUpload: (document: Document) => void
  onDelete: (documentId: string) => void
}

export function DocumentUpload({ shipment, onUpload, onDelete }: DocumentUploadProps) {
  const [uploading, setUploading] = useState(false)
  const [isDragging, setIsDragging] = useState(false)

  const processFile = async (file: File) => {
    setUploading(true)

    try {
      const formData = new FormData()
      formData.append("file", file)

      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) {
        throw new Error("Upload failed")
      }

      const data = await response.json()

      const document: Document = {
        id: Date.now().toString(),
        name: file.name,
        type: file.type,
        size: file.size,
        uploadedAt: new Date(),
        shipmentId: shipment.id,
        url: data.url, // Vercel Blob URL
      }

      onUpload(document)
    } catch (error) {
      console.error("Upload error:", error)
      alert("An error occurred while uploading the file")
    } finally {
      setUploading(false)
    }
  }

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    await processFile(file)
    e.target.value = ""
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(true)
  }

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()

    const rect = e.currentTarget.getBoundingClientRect()
    const x = e.clientX
    const y = e.clientY

    if (x <= rect.left || x >= rect.right || y <= rect.top || y >= rect.bottom) {
      setIsDragging(false)
    }
  }

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(false)

    const file = e.dataTransfer.files?.[0]
    if (file) {
      await processFile(file)
    }
  }

  const handleDelete = async (doc: Document) => {
    try {
      if (doc.url && !doc.data) {
        // New format: Delete from Vercel Blob
        const response = await fetch("/api/delete", {
          method: "DELETE",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ url: doc.url }),
        })

        if (!response.ok) {
          throw new Error("Delete failed")
        }
      }
      // Old format documents (base64 data) don't need API call, just remove from state

      onDelete(doc.id)
    } catch (error) {
      console.error("Delete error:", error)
      alert("An error occurred while deleting the file")
    }
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + " " + sizes[i]
  }

  return (
    <div className="space-y-4">
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
          isDragging ? "border-primary bg-primary/5" : "border-muted-foreground/25"
        }`}
      >
        <label className="cursor-pointer block">
          <div className="space-y-2">
            <p className="text-sm font-medium">Upload File</p>
            <p className="text-xs text-muted-foreground">
              {uploading ? "Uploading..." : "Drag files here or click to select"}
            </p>
          </div>
          <input type="file" onChange={handleFileUpload} disabled={uploading} className="hidden" />
        </label>
      </div>

      {shipment.documents && shipment.documents.length > 0 && (
        <div className="space-y-2">
          <h4 className="font-semibold text-sm">Uploaded Files</h4>
          {shipment.documents.map((doc) => (
            <Card key={doc.id} className="p-3 flex items-center justify-between">
              <div className="flex-1">
                <p className="text-sm font-medium">{doc.name}</p>
                <p className="text-xs text-muted-foreground">
                  {formatFileSize(doc.size)} • {new Date(doc.uploadedAt).toLocaleDateString()}
                </p>
              </div>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" asChild>
                  <a href={doc.url || doc.data} download={doc.name} target="_blank" rel="noopener noreferrer">
                    Download
                  </a>
                </Button>
                <Button size="sm" variant="destructive" onClick={() => handleDelete(doc)}>
                  Delete
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
