"use client"

import type React from "react"
import { useState, useMemo } from "react"
import type { Shipment, Company, Supplier } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Plus, X, ExternalLink } from "lucide-react"

const ENABLE_SUPPLIER_QUICK_ADD = true
const ENABLE_CARRIER_QUICK_ADD = true

function normalizeForSearch(str: string): string {
  return str
    .toLowerCase()
    .replace(/ı/g, "i") // Turkish ı → i
    .replace(/İ/g, "i") // Turkish İ → i
    .replace(/ğ/g, "g") // Turkish ğ → g
    .replace(/Ğ/g, "g") // Turkish Ğ → g
    .replace(/ü/g, "u") // Turkish ü → u
    .replace(/Ü/g, "u") // Turkish Ü → u
    .replace(/ş/g, "s") // Turkish ş → s
    .replace(/Ş/g, "s") // Turkish Ş → s
    .replace(/ö/g, "o") // Turkish ö → o
    .replace(/Ö/g, "o") // Turkish Ö → o
    .replace(/ç/g, "c") // Turkish ç → c
    .replace(/Ç/g, "c") // Turkish Ç → c
}

interface ShipmentFormProps {
  companies: Company[]
  suppliers: Supplier[]
  tedarikciList: string[]
  countries: string[]
  carriers: string[]
  onSubmit: (shipment: Shipment) => void
  initialData?: Shipment
  onCancel?: () => void
  onAddNewSupplier?: (name: string) => void
  onAddNewCarrier?: (name: string) => void
}

export function ShipmentForm({
  companies,
  suppliers,
  tedarikciList,
  countries,
  carriers,
  onSubmit,
  initialData,
  onCancel,
  onAddNewSupplier,
  onAddNewCarrier,
}: ShipmentFormProps) {
  const [formData, setFormData] = useState<Partial<Shipment>>(
    initialData || {
      tedarikçi: "",
      product: "",
      firmaId: "",
      originCountry: "",
      status: "toLoad",
      estimatedLoading: new Date(),
      customer: "",
      carrier: "",
      ourOrderNumber: "",
      supplierOrderNumber: "",
      invoiceNumber: "",
      billOfLadingNumbers: [],
      estimatedDepartureDate: undefined,
      estimatedArrivalDate: undefined,
      courierCompany: "",
      courierTrackingNumber: "",
    },
  )

  const [billOfLadingInputs, setBillOfLadingInputs] = useState<string[]>(
    initialData?.billOfLadingNumbers && initialData.billOfLadingNumbers.length > 0
      ? initialData.billOfLadingNumbers
      : [""],
  )

  const allSuppliers = useMemo(() => {
    const supplierNames = (suppliers || []).map((s) => s.name).filter(Boolean)
    const seedSuppliers = tedarikciList || []
    let historySuppliers: string[] = []
    if (typeof window !== "undefined") {
      try {
        const keys = ["shipments", "data", "shipmentData", "appState", "shipment_shipments"]
        for (const key of keys) {
          const data = localStorage.getItem(key)
          if (data) {
            const parsed = JSON.parse(data)
            const shipments = Array.isArray(parsed) ? parsed : parsed.shipments || []
            historySuppliers = shipments.map((s: any) => s.supplier || s.tedarikçi).filter(Boolean)
            if (historySuppliers.length > 0) break
          }
        }
      } catch (e) {
        console.error("Error loading history suppliers:", e)
      }
    }
    const combined = Array.from(
      new Set([...supplierNames, ...seedSuppliers, ...historySuppliers].map((s) => s.trim()).filter(Boolean)),
    )
    console.log("[v0] AUTO_SUPPLIERS_total", combined.length, combined)
    return combined
  }, [tedarikciList, suppliers])

  const [tedarikciInput, setTedarikciInput] = useState(initialData?.tedarikçi || "")
  const [countryInput, setCountryInput] = useState(initialData?.originCountry || "")
  const [customerInput, setCustomerInput] = useState(initialData?.customer || "")
  const [carrierInput, setCarrierInput] = useState(initialData?.carrier || "")
  const [courierCompanyInput, setCourierCompanyInput] = useState(initialData?.courierCompany || "")
  const [showTedarikciSuggestions, setShowTedarikciSuggestions] = useState(false)
  const [showCountrySuggestions, setShowCountrySuggestions] = useState(false)
  const [showCustomerSuggestions, setShowCustomerSuggestions] = useState(false)
  const [showCarrierSuggestions, setShowCarrierSuggestions] = useState(false)
  const [showCourierCompanySuggestions, setShowCourierCompanySuggestions] = useState(false)
  const [isTransitSale, setIsTransitSale] = useState(!!initialData?.customer)

  const showTransitSaleOption = useMemo(() => {
    const selectedCompany = companies.find((c) => c.id === formData.firmaId)
    return tedarikciInput === "Hadiklaim" && selectedCompany?.name === "Atlas Agro"
  }, [tedarikciInput, formData.firmaId, companies])

  useMemo(() => {
    if (!showTransitSaleOption) {
      setIsTransitSale(false)
      setCustomerInput("")
    }
  }, [showTransitSaleOption])

  const filteredTedarikci = useMemo(() => {
    if (!tedarikciInput) return []
    const normalizedQuery = normalizeForSearch(tedarikciInput)
    const filtered = allSuppliers.filter((t) => normalizeForSearch(t).startsWith(normalizedQuery))
    console.log("SUPPLIER_QUERY", tedarikciInput, "MATCHES", filtered.length)
    return filtered
  }, [tedarikciInput, allSuppliers])

  const filteredCountries = useMemo(() => {
    if (!countryInput) return []
    const normalizedQuery = normalizeForSearch(countryInput)
    return countries.filter((c) => normalizeForSearch(c).startsWith(normalizedQuery))
  }, [countryInput, countries])

  const filteredCustomers = useMemo(() => {
    if (!customerInput) return []
    return ["Seyfullah", "Şumkar", "Alpha", "Diruz"].filter((c) =>
      c.toLocaleLowerCase("tr-TR").startsWith(customerInput.toLocaleLowerCase("tr-TR")),
    )
  }, [customerInput])

  const filteredCarriers = useMemo(() => {
    if (!carrierInput) return []
    const normalizedQuery = normalizeForSearch(carrierInput)
    const filtered = carriers.filter((c) => normalizeForSearch(c).startsWith(normalizedQuery))
    console.log("[v0] ARMATOR_QUERY", carrierInput, "MATCHES", filtered.length)
    return filtered
  }, [carrierInput, carriers])

  const courierCompanies = ["DHL", "Aramex", "FedEx", "UPS", "TNT", "DPD", "GLS"]
  const filteredCourierCompanies = useMemo(() => {
    if (!courierCompanyInput) return []
    const normalizedQuery = normalizeForSearch(courierCompanyInput)
    return courierCompanies.filter((c) => normalizeForSearch(c).startsWith(normalizedQuery))
  }, [courierCompanyInput])

  const firstTedarikciMatch = filteredTedarikci.length > 0 ? filteredTedarikci[0] : null
  const firstCountryMatch = filteredCountries.length > 0 ? filteredCountries[0] : null
  const firstCustomerMatch = filteredCustomers.length > 0 ? filteredCustomers[0] : null
  const firstCarrierMatch = filteredCarriers.length > 0 ? filteredCarriers[0] : null
  const firstCourierCompanyMatch = filteredCourierCompanies.length > 0 ? filteredCourierCompanies[0] : null

  const addBillOfLadingInput = () => {
    setBillOfLadingInputs([...billOfLadingInputs, ""])
  }

  const removeBillOfLadingInput = (index: number) => {
    if (billOfLadingInputs.length > 1) {
      const newInputs = billOfLadingInputs.filter((_, i) => i !== index)
      setBillOfLadingInputs(newInputs)
    }
  }

  const updateBillOfLadingInput = (index: number, value: string) => {
    const newInputs = [...billOfLadingInputs]
    newInputs[index] = value
    setBillOfLadingInputs(newInputs)
  }

  const handleTedarikciChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    setTedarikciInput(value)
    setShowTedarikciSuggestions(true)
  }

  const handleTedarikciKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "ArrowDown" && firstTedarikciMatch && tedarikciInput !== firstTedarikciMatch) {
      setTedarikciInput(firstTedarikciMatch)
    } else if (e.key === "Enter" && firstTedarikciMatch) {
      e.preventDefault()
      setTedarikciInput(firstTedarikciMatch)
      setShowTedarikciSuggestions(false)
    } else if (e.key === "Escape") {
      setShowTedarikciSuggestions(false)
    }
  }

  const handleCountryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    setCountryInput(value)
    setShowCountrySuggestions(true)
  }

  const handleCountryKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "ArrowDown" && firstCountryMatch && countryInput !== firstCountryMatch) {
      setCountryInput(firstCountryMatch)
    } else if (e.key === "Enter" && firstCountryMatch) {
      e.preventDefault()
      setCountryInput(firstCountryMatch)
      setShowCountrySuggestions(false)
    } else if (e.key === "Escape") {
      setShowCountrySuggestions(false)
    }
  }

  const handleCustomerChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    setCustomerInput(value)
    setShowCustomerSuggestions(true)
  }

  const handleCustomerKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "ArrowDown" && firstCustomerMatch && customerInput !== firstCustomerMatch) {
      setCustomerInput(firstCustomerMatch)
    } else if (e.key === "Enter" && firstCustomerMatch) {
      e.preventDefault()
      setCustomerInput(firstCustomerMatch)
      setShowCustomerSuggestions(false)
    } else if (e.key === "Escape") {
      setShowCustomerSuggestions(false)
    }
  }

  const handleCarrierChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    setCarrierInput(value)
    setShowCarrierSuggestions(true)
  }

  const handleCarrierKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "ArrowDown" && firstCarrierMatch && carrierInput !== firstCarrierMatch) {
      setCarrierInput(firstCarrierMatch)
    } else if (e.key === "Enter" && firstCarrierMatch) {
      e.preventDefault()
      setCarrierInput(firstCarrierMatch)
      setShowCarrierSuggestions(false)
    } else if (e.key === "Escape") {
      setShowCarrierSuggestions(false)
    }
  }

  const handleCourierCompanyChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    setCourierCompanyInput(value)
    setShowCourierCompanySuggestions(true)
  }

  const handleCourierCompanyKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "ArrowDown" && firstCourierCompanyMatch && courierCompanyInput !== firstCourierCompanyMatch) {
      setCourierCompanyInput(firstCourierCompanyMatch)
    } else if (e.key === "Enter" && firstCourierCompanyMatch) {
      e.preventDefault()
      setCourierCompanyInput(firstCourierCompanyMatch)
      setShowCourierCompanySuggestions(false)
    } else if (e.key === "Escape") {
      setShowCourierCompanySuggestions(false)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const validBillOfLadingNumbers = billOfLadingInputs.filter((num) => num.trim() !== "")

    console.log("[v0] BL_VISIBLE", Boolean(validBillOfLadingNumbers.length > 0), validBillOfLadingNumbers)

    const inv = (formData.invoiceNumber ?? formData.invoiceNo ?? formData.faturaNo ?? "").toString().trim()
    const bl = validBillOfLadingNumbers.length > 0 ? validBillOfLadingNumbers[0] : ""

    const isTransitSaleFlag = Boolean(isTransitSale)
    const status = formData.status || "toLoad"

    console.log("[v0] SAVE_TRANSIT_FLAG", {
      status: status,
      isTransitSale: isTransitSaleFlag,
    })

    const shipment: Shipment = {
      id: initialData?.id || Date.now().toString(),
      tedarikçi: tedarikciInput,
      product: formData.product || "",
      firmaId: formData.firmaId || "",
      originCountry: countryInput,
      status: status as any,
      estimatedLoading: formData.estimatedLoading || new Date(),
      actualDelivery: formData.actualDelivery,
      createdAt: initialData?.createdAt || new Date(),
      documents: initialData?.documents || [],
      customer: isTransitSale ? customerInput : undefined,
      carrier: carrierInput || undefined,
      ourOrderNumber: formData.ourOrderNumber,
      supplierOrderNumber: formData.supplierOrderNumber,
      invoiceNumber: inv || undefined,
      invoiceNo: inv || undefined,
      faturaNo: inv || undefined,
      billOfLadingNumbers: validBillOfLadingNumbers.length > 0 ? validBillOfLadingNumbers : undefined,
      billOfLading: bl || undefined,
      bl: bl || undefined,
      blNo: bl || undefined,
      konsimento: bl || undefined,
      estimatedDepartureDate: formData.estimatedDepartureDate,
      estimatedArrivalDate: formData.estimatedArrivalDate,
      isTransitSale: isTransitSaleFlag,
      courierCompany: courierCompanyInput || undefined,
      courierTrackingNumber: formData.courierTrackingNumber || undefined,
    } as any
    onSubmit(shipment)
  }

  const showAddNewSupplier =
    ENABLE_SUPPLIER_QUICK_ADD && filteredTedarikci.length === 0 && tedarikciInput.trim().length >= 2

  const showAddNewCarrier = ENABLE_CARRIER_QUICK_ADD && filteredCarriers.length === 0 && carrierInput.trim().length >= 2

  const carrierTrackingUrl = (name: string, bl: string): string => {
    const n = (name || "").toString().trim().toLowerCase()
    const blNum = (bl || "").toString().trim()

    // Known carriers (safe public tracking pages)
    if (n.includes("maersk")) {
      return blNum ? `https://www.maersk.com/tracking/${encodeURIComponent(blNum)}` : "https://www.maersk.com/tracking/"
    }
    if (n.includes("msc")) return "https://www.msc.com/track-a-shipment"
    if (n.includes("cma")) return "https://www.cma-cgm.com/ebusiness/tracking/search"
    if (n.includes("hapag")) return "https://www.hapag-lloyd.com/en/online-business/tracing/tracing-by-booking.html"
    if (n.includes("cosco")) return "https://elines.coscoshipping.com/ebusiness/cargoTracking"
    if (n.includes("evergreen")) return "https://ct.shipmentlink.com/servlet/TDB1_CargoTracking.do"
    if (n.includes("one")) return "https://ecomm.one-line.com/one-ecom/manage-tracking"

    // Fallback: Google search with carrier + "tracking"
    const q = encodeURIComponent(`${name} tracking`)
    return `https://www.google.com/search?q=${q}`
  }

  const trackingLink = useMemo(() => {
    const carrierName = carrierInput || ""
    const bl = billOfLadingInputs.length > 0 ? billOfLadingInputs[0] : ""
    const href = carrierTrackingUrl(carrierName, bl)

    console.log("[v0] TRACK_LINK", { carrierName, bl, href })

    return { href, carrierName, bl }
  }, [carrierInput, billOfLadingInputs])

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-4 p-4 border rounded-2xl">
        <h3 className="text-lg font-semibold">Basic Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Tedarikçi field */}
          <div className="relative">
            <label className="block text-sm font-medium mb-1">Supplier</label>
            <div className="relative">
              <Input
                type="text"
                value={tedarikciInput}
                onChange={handleTedarikciChange}
                onKeyDown={handleTedarikciKeyDown}
                onFocus={() => setShowTedarikciSuggestions(true)}
                onBlur={() => setTimeout(() => setShowTedarikciSuggestions(false), 200)}
                placeholder="Enter supplier name"
                required
                className={
                  firstTedarikciMatch && tedarikciInput && tedarikciInput !== firstTedarikciMatch
                    ? "text-transparent"
                    : ""
                }
              />
              {firstTedarikciMatch && tedarikciInput && tedarikciInput !== firstTedarikciMatch && (
                <div className="absolute top-0 left-0 right-0 px-3 py-2 text-sm pointer-events-none overflow-hidden whitespace-nowrap">
                  <span className="text-gray-900">{tedarikciInput}</span>
                  <span className="text-gray-400">{firstTedarikciMatch.slice(tedarikciInput.length)}</span>
                </div>
              )}
            </div>
            {showTedarikciSuggestions && filteredTedarikci.length > 0 && (
              <div className="absolute top-full left-0 right-0 bg-white border rounded-md mt-1 z-10 shadow-lg">
                {filteredTedarikci.map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => {
                      setTedarikciInput(t)
                      setShowTedarikciSuggestions(false)
                    }}
                    className="w-full text-left px-3 py-2 hover:bg-gray-100 text-sm"
                  >
                    {t}
                  </button>
                ))}
              </div>
            )}
            {showTedarikciSuggestions && showAddNewSupplier && onAddNewSupplier && (
              <div className="absolute top-full left-0 right-0 bg-white border rounded-md mt-1 z-10 shadow-lg">
                <button
                  type="button"
                  onClick={() => {
                    onAddNewSupplier(tedarikciInput)
                    setShowTedarikciSuggestions(false)
                  }}
                  className="w-full text-left px-3 py-2 hover:bg-blue-50 text-sm text-blue-600 font-medium flex items-center gap-2"
                >
                  <Plus className="h-4 w-4" />
                  <span>'Add new supplier '{tedarikciInput}'</span>
                </button>
              </div>
            )}
          </div>

          {/* Product field */}
          <div>
            <label className="block text-sm font-medium mb-1">Product</label>
            <select
              value={formData.product || ""}
              onChange={(e) => setFormData({ ...formData, product: e.target.value })}
              className="w-full px-3 py-2 border rounded-md"
              required
            >
              <option value="">Select product</option>
              {["Cashew", "Almonds", "Dates", "Pistachios", "Walnuts", "Raisins", "Dried Fruits", "Other"].map(
                (product) => (
                  <option key={product} value={product}>
                    {product}
                  </option>
                ),
              )}
            </select>
          </div>

          {/* Firma field */}
          <div>
            <label className="block text-sm font-medium mb-1">Company</label>
            <select
              value={formData.firmaId || ""}
              onChange={(e) => setFormData({ ...formData, firmaId: e.target.value })}
              className="w-full px-3 py-2 border rounded-md"
              required
            >
              <option value="">Select company</option>
              {companies.map((company) => (
                <option key={company.id} value={company.id}>
                  {company.name}
                </option>
              ))}
            </select>
          </div>

          {/* Menşei Ülke field */}
          <div className="relative">
            <label className="block text-sm font-medium mb-1">Origin Country</label>
            <div className="relative">
              <Input
                type="text"
                value={countryInput}
                onChange={handleCountryChange}
                onKeyDown={handleCountryKeyDown}
                onFocus={() => setShowCountrySuggestions(true)}
                onBlur={() => setTimeout(() => setShowCountrySuggestions(false), 200)}
                placeholder="Enter country name"
                required
                className={
                  firstCountryMatch && countryInput && countryInput !== firstCountryMatch ? "text-transparent" : ""
                }
              />
              {firstCountryMatch && countryInput && countryInput !== firstCountryMatch && (
                <div className="absolute top-0 left-0 right-0 px-3 py-2 text-sm pointer-events-none overflow-hidden whitespace-nowrap">
                  <span className="text-gray-900">{countryInput}</span>
                  <span className="text-gray-400">{firstCountryMatch.slice(countryInput.length)}</span>
                </div>
              )}
            </div>
            {showCountrySuggestions && filteredCountries.length > 0 && (
              <div className="absolute top-full left-0 right-0 bg-white border rounded-md mt-1 z-10 shadow-lg">
                {filteredCountries.map((country) => (
                  <button
                    key={country}
                    type="button"
                    onClick={() => {
                      setCountryInput(country)
                      setShowCountrySuggestions(false)
                    }}
                    className="w-full text-left px-3 py-2 hover:bg-gray-100 text-sm"
                  >
                    {country}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Durum field */}
          <div>
            <label className="block text-sm font-medium mb-1">Status</label>
            <select
              value={formData.status || "toLoad"}
              onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
              className="w-full px-3 py-2 border rounded-md min-w-[160px] text-center"
            >
              {[
                { value: "toLoad", label: "To Load" },
                { value: "onTheWay", label: "On the Way" },
                { value: "arrived", label: "Arrived" },
                { value: "completed", label: "Import Completed" },
              ].map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>

          {/* Armatör field */}
          <div className="relative">
            <label className="block text-sm font-medium mb-1">Shipping Line</label>
            <div className="relative">
              <Input
                type="text"
                value={carrierInput}
                onChange={handleCarrierChange}
                onKeyDown={handleCarrierKeyDown}
                onFocus={() => setShowCarrierSuggestions(true)}
                onBlur={() => setTimeout(() => setShowCarrierSuggestions(false), 200)}
                placeholder="Enter shipping line name (e.g., Maersk, CMA CGM, Arkas)"
                className={
                  firstCarrierMatch && carrierInput && carrierInput !== firstCarrierMatch ? "text-transparent" : ""
                }
              />
              {firstCarrierMatch && carrierInput && carrierInput !== firstCarrierMatch && (
                <div className="absolute top-0 left-0 right-0 px-3 py-2 text-sm pointer-events-none overflow-hidden whitespace-nowrap">
                  <span className="text-gray-900">{carrierInput}</span>
                  <span className="text-gray-400">{firstCarrierMatch.slice(carrierInput.length)}</span>
                </div>
              )}
            </div>
            {showCarrierSuggestions && filteredCarriers.length > 0 && (
              <div className="absolute top-full left-0 right-0 bg-white border rounded-md mt-1 z-10 shadow-lg max-h-48 overflow-y-auto">
                {filteredCarriers.map((carrier) => (
                  <button
                    key={carrier}
                    type="button"
                    onClick={() => {
                      setCarrierInput(carrier)
                      setShowCarrierSuggestions(false)
                    }}
                    className="w-full text-left px-3 py-2 hover:bg-gray-100 text-sm"
                  >
                    {carrier}
                  </button>
                ))}
              </div>
            )}
            {showCarrierSuggestions && showAddNewCarrier && onAddNewCarrier && (
              <div className="absolute top-full left-0 right-0 bg-white border rounded-md mt-1 z-10 shadow-lg">
                <button
                  type="button"
                  onClick={() => {
                    onAddNewCarrier(carrierInput)
                    setShowCarrierSuggestions(false)
                  }}
                  className="w-full text-left px-3 py-2 hover:bg-blue-50 text-sm text-blue-600 font-medium flex items-center gap-2"
                >
                  <Plus className="h-4 w-4" />
                  <span>'Add new shipping line '{carrierInput}'</span>
                </button>
              </div>
            )}
          </div>

          {/* Transit Sale toggle */}
          {showTransitSaleOption && (
            <div className="md:col-span-2 flex items-center space-x-2 p-4 bg-blue-50 rounded-md border border-blue-200">
              <Switch id="transit-sale" checked={isTransitSale} onCheckedChange={setIsTransitSale} />
              <Label htmlFor="transit-sale" className="text-sm font-medium cursor-pointer">
                Transit Sale?
              </Label>
            </div>
          )}

          {/* Customer field (if transit sale) */}
          {isTransitSale && (
            <div className="md:col-span-2 relative">
              <label className="block text-sm font-medium mb-1">
                Customer <span className="text-xs text-gray-500">(Transit Sale)</span>
              </label>
              <div className="relative">
                <Input
                  type="text"
                  value={customerInput}
                  onChange={handleCustomerChange}
                  onKeyDown={handleCustomerKeyDown}
                  onFocus={() => setShowCustomerSuggestions(true)}
                  onBlur={() => setTimeout(() => setShowCustomerSuggestions(false), 200)}
                  placeholder="Enter customer name"
                  required
                  className={
                    firstCustomerMatch && customerInput && customerInput !== firstCustomerMatch
                      ? "text-transparent"
                      : ""
                  }
                />
                {firstCustomerMatch && customerInput && customerInput !== firstCustomerMatch && (
                  <div className="absolute top-0 left-0 right-0 px-3 py-2 text-sm pointer-events-none overflow-hidden whitespace-nowrap">
                    <span className="text-gray-900">{customerInput}</span>
                    <span className="text-gray-400">{firstCustomerMatch.slice(customerInput.length)}</span>
                  </div>
                )}
              </div>
              {showCustomerSuggestions && filteredCustomers.length > 0 && (
                <div className="absolute top-full left-0 right-0 bg-white border rounded-md mt-1 z-10 shadow-lg">
                  {filteredCustomers.map((customer) => (
                    <button
                      key={customer}
                      type="button"
                      onClick={() => {
                        setCustomerInput(customer)
                        setShowCustomerSuggestions(false)
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-gray-100 text-sm"
                    >
                      {customer}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Courier Tracking Information section */}
      <div className="space-y-4 p-4 border rounded-2xl">
        <h3 className="text-lg font-semibold">Courier Tracking Information</h3>
        <p className="text-sm text-muted-foreground">
          For express shipments via courier companies (DHL, Aramex, FedEx, etc.)
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Courier Company field */}
          <div className="relative">
            <label className="block text-sm font-medium mb-1">Courier Company</label>
            <div className="relative">
              <Input
                type="text"
                value={courierCompanyInput}
                onChange={handleCourierCompanyChange}
                onKeyDown={handleCourierCompanyKeyDown}
                onFocus={() => setShowCourierCompanySuggestions(true)}
                onBlur={() => setTimeout(() => setShowCourierCompanySuggestions(false), 200)}
                placeholder="Enter courier company (e.g., DHL, Aramex)"
                className={
                  firstCourierCompanyMatch && courierCompanyInput && courierCompanyInput !== firstCourierCompanyMatch
                    ? "text-transparent"
                    : ""
                }
              />
              {firstCourierCompanyMatch && courierCompanyInput && courierCompanyInput !== firstCourierCompanyMatch && (
                <div className="absolute top-0 left-0 right-0 px-3 py-2 text-sm pointer-events-none overflow-hidden whitespace-nowrap">
                  <span className="text-gray-900">{courierCompanyInput}</span>
                  <span className="text-gray-400">{firstCourierCompanyMatch.slice(courierCompanyInput.length)}</span>
                </div>
              )}
            </div>
            {showCourierCompanySuggestions && filteredCourierCompanies.length > 0 && (
              <div className="absolute top-full left-0 right-0 bg-white border rounded-md mt-1 z-10 shadow-lg max-h-48 overflow-y-auto">
                {filteredCourierCompanies.map((company) => (
                  <button
                    key={company}
                    type="button"
                    onClick={() => {
                      setCourierCompanyInput(company)
                      setShowCourierCompanySuggestions(false)
                    }}
                    className="w-full text-left px-3 py-2 hover:bg-gray-100 text-sm"
                  >
                    {company}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Tracking Number field */}
          <div>
            <label className="block text-sm font-medium mb-1">Tracking Number</label>
            <Input
              type="text"
              value={formData.courierTrackingNumber || ""}
              onChange={(e) => setFormData({ ...formData, courierTrackingNumber: e.target.value })}
              placeholder="Enter tracking number"
            />
          </div>
        </div>
      </div>

      <div className="space-y-4 p-4 border rounded-2xl">
        <h3 className="text-lg font-semibold">Bill of Lading Details</h3>
        <p className="text-sm text-muted-foreground">
          Bill of Lading/B/L number - Document number used in sea freight transportation
        </p>
        <div className="space-y-3">
          {billOfLadingInputs.map((blNumber, index) => (
            <div key={index} className="flex gap-2 items-start">
              <div className="flex-1">
                <Label htmlFor={`bl-${index}`} className="text-sm font-medium mb-1 block">
                  Bill of Lading No {billOfLadingInputs.length > 1 ? `#${index + 1}` : ""}
                </Label>
                <Input
                  id={`bl-${index}`}
                  type="text"
                  value={blNumber}
                  onChange={(e) => updateBillOfLadingInput(index, e.target.value)}
                  placeholder="Enter bill of lading/B/L number"
                  className="w-full"
                />
                <p className="text-xs text-muted-foreground mt-1">Bill of Lading/B/L number</p>
              </div>
              {billOfLadingInputs.length > 1 && (
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  onClick={() => removeBillOfLadingInput(index)}
                  className="mt-7"
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
          ))}
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={addBillOfLadingInput}
            className="mt-2 bg-transparent"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Bill of Lading
          </Button>
        </div>
      </div>

      <div className="space-y-4 p-4 border rounded-2xl">
        <h3 className="text-lg font-semibold">Order and Document Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Bizdeki Sipariş Numarası */}
          <div>
            <label className="block text-sm font-medium mb-1">Our Order Number</label>
            <Input
              type="text"
              value={formData.ourOrderNumber || ""}
              onChange={(e) => setFormData({ ...formData, ourOrderNumber: e.target.value })}
              placeholder="E.g., ORD-2024-001"
            />
          </div>

          {/* Tedarikçi Sipariş Numarası */}
          <div>
            <label className="block text-sm font-medium mb-1">Supplier Order Number</label>
            <Input
              type="text"
              value={formData.supplierOrderNumber || ""}
              onChange={(e) => setFormData({ ...formData, supplierOrderNumber: e.target.value })}
              placeholder="Supplier's order number"
            />
          </div>

          {/* Fatura Numarası */}
          <div>
            <label className="block text-sm font-medium mb-1">Invoice Number</label>
            <Input
              type="text"
              value={formData.invoiceNumber || ""}
              onChange={(e) => setFormData({ ...formData, invoiceNumber: e.target.value })}
              placeholder="Invoice number"
            />
          </div>

          {/* Estimated Arrival Date field with tracking link */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-sm font-medium">Estimated Arrival Date</label>
              {carrierInput && (
                <a
                  href={trackingLink.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-blue-600 hover:text-blue-800 flex items-center gap-1"
                >
                  <ExternalLink className="h-3 w-3" />
                  Tracking page
                </a>
              )}
            </div>
            <Input
              type="date"
              value={
                formData.estimatedArrivalDate ? new Date(formData.estimatedArrivalDate).toISOString().split("T")[0] : ""
              }
              onChange={(e) =>
                setFormData({
                  ...formData,
                  estimatedArrivalDate: e.target.value ? new Date(e.target.value) : undefined,
                })
              }
            />
          </div>
        </div>
      </div>

      <div className="sticky bottom-4 z-50 flex gap-2 justify-end bg-white p-3 md:p-4 rounded-lg shadow-lg border mt-6 mb-20">
        {onCancel && (
          <Button type="button" variant="outline" onClick={onCancel} className="min-w-[80px] bg-transparent">
            Cancel
          </Button>
        )}
        <Button type="submit" className="min-w-[100px]">
          {initialData ? "Update" : "Add Shipment"}
        </Button>
      </div>
    </form>
  )
}

function toCanonStatus(status: string): string {
  // Implement status canonicalization logic here
  return status
}
