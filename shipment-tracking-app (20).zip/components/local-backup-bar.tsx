"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Download, Upload } from "lucide-react"
import { useRef } from "react"

export function LocalBackupBar() {
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleExport = () => {
    try {
      // Collect all localStorage data
      const backup: Record<string, string> = {}
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i)
        if (key) {
          const value = localStorage.getItem(key)
          if (value) {
            backup[key] = value
          }
        }
      }

      // Create and download JSON file
      const dataStr = JSON.stringify(backup, null, 2)
      const dataBlob = new Blob([dataStr], { type: "application/json" })
      const url = URL.createObjectURL(dataBlob)
      const link = document.createElement("a")
      link.href = url
      link.download = `shipmentracker-backup-${new Date().toISOString().split("T")[0]}.json`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      URL.revokeObjectURL(url)

      console.log("[v0] Backup exported successfully", Object.keys(backup).length, "keys")
    } catch (error) {
      console.error("[v0] Export failed:", error)
      alert("Backup failed. Please try again.")
    }
  }

  const handleImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string
        const backup = JSON.parse(content)

        // Restore all keys to localStorage
        let restoredCount = 0
        for (const [key, value] of Object.entries(backup)) {
          if (typeof value === "string") {
            localStorage.setItem(key, value)
            restoredCount++
          }
        }

        console.log("[v0] Backup restored successfully", restoredCount, "keys")
        alert(`Backup restored successfully! (${restoredCount} items)\n\nPage will reload.`)
        location.reload()
      } catch (error) {
        console.error("[v0] Import failed:", error)
        alert("Could not read backup file. Please select a valid backup file.")
      }
    }
    reader.readAsText(file)

    // Reset input so same file can be selected again
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  return (
    <div className="bg-muted/50 border rounded-lg p-4 mb-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex-1">
          <h3 className="font-medium text-sm mb-1">Data Backup</h3>
          <p className="text-xs text-muted-foreground">You can restore from file even if browser data is deleted.</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={handleExport} variant="outline" size="sm" className="gap-2 bg-transparent">
            <Download className="h-4 w-4" />
            Backup (.json)
          </Button>
          <Button onClick={() => fileInputRef.current?.click()} variant="outline" size="sm" className="gap-2">
            <Upload className="h-4 w-4" />
            Restore
          </Button>
          <input ref={fileInputRef} type="file" accept=".json" onChange={handleImport} className="hidden" />
        </div>
      </div>
    </div>
  )
}
