"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

interface ShippingLine {
  id: string
  name: string
  code?: string
  website?: string
  createdAt: Date
}

interface ShippingLineFormProps {
  onSubmit: (shippingLine: ShippingLine) => void
  initialData?: ShippingLine
  onCancel?: () => void
  initialName?: string
}

export function ShippingLineForm({ onSubmit, initialData, onCancel, initialName }: ShippingLineFormProps) {
  const [formData, setFormData] = useState({
    name: initialData?.name || initialName || "",
    code: initialData?.code || "",
    website: initialData?.website || "",
  })

  useEffect(() => {
    if (initialName && !initialData) {
      setFormData((prev) => ({ ...prev, name: initialName }))
    }
  }, [initialName, initialData])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const shippingLine: ShippingLine = {
      id: initialData?.id || Date.now().toString(),
      name: formData.name,
      code: formData.code || undefined,
      website: formData.website || undefined,
      createdAt: initialData?.createdAt || new Date(),
    }
    onSubmit(shippingLine)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium mb-1">Shipping Line Name *</label>
        <Input
          type="text"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          placeholder="E.g: Maersk, CMA CGM, MSC"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Shipping Line Code</label>
        <Input
          type="text"
          value={formData.code}
          onChange={(e) => setFormData({ ...formData, code: e.target.value })}
          placeholder="E.g: MAEU, CMDU, MSCU"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Website</label>
        <Input
          type="url"
          value={formData.website}
          onChange={(e) => setFormData({ ...formData, website: e.target.value })}
          placeholder="https://www.example.com"
        />
      </div>

      <div className="flex gap-2 justify-end">
        {onCancel && (
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        )}
        <Button type="submit">{initialData ? "Update" : "Add Shipping Line"}</Button>
      </div>
    </form>
  )
}
