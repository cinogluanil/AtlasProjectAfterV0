"use client"

import type React from "react"
import { useState, useEffect } from "react"
import type { Supplier } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

interface SupplierFormProps {
  onSubmit: (supplier: Supplier) => void
  initialData?: Supplier
  onCancel?: () => void
  initialName?: string
}

export function SupplierForm({ onSubmit, initialData, onCancel, initialName }: SupplierFormProps) {
  const [formData, setFormData] = useState<Partial<Supplier>>(
    initialData || {
      name: initialName || "",
      email: "",
      phone: "",
      address: "",
      city: "",
      country: "",
    },
  )

  useEffect(() => {
    if (initialName && !initialData) {
      setFormData((prev) => ({ ...prev, name: initialName }))
    }
  }, [initialName, initialData])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const supplier: Supplier = {
      id: initialData?.id || Date.now().toString(),
      name: formData.name || "",
      email: formData.email || "",
      phone: formData.phone || "",
      address: formData.address || "",
      city: formData.city || "",
      country: formData.country || "",
      createdAt: initialData?.createdAt || new Date(),
    }
    onSubmit(supplier)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Supplier Name</label>
          <Input
            type="text"
            value={formData.name || ""}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            placeholder="Enter supplier name"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Email</label>
          <Input
            type="email"
            value={formData.email || ""}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            placeholder="supplier@example.com"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Phone</label>
          <Input
            type="tel"
            value={formData.phone || ""}
            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
            placeholder="+1 (555) 000-0000"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Address</label>
          <Input
            type="text"
            value={formData.address || ""}
            onChange={(e) => setFormData({ ...formData, address: e.target.value })}
            placeholder="Street address"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">City</label>
          <Input
            type="text"
            value={formData.city || ""}
            onChange={(e) => setFormData({ ...formData, city: e.target.value })}
            placeholder="City"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Country</label>
          <Input
            type="text"
            value={formData.country || ""}
            onChange={(e) => setFormData({ ...formData, country: e.target.value })}
            placeholder="Country"
            required
          />
        </div>
      </div>
      <div className="flex gap-2 justify-end">
        {onCancel && (
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        )}
        <Button type="submit">{initialData ? "Update Supplier" : "Add Supplier"}</Button>
      </div>
    </form>
  )
}
