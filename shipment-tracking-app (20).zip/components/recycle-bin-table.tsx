"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import type { Company } from "@/lib/types"
import { displayInvoiceBL } from "@/lib/display"

interface DeletedShipment {
  id: string
  tedarikçi: string
  product: string
  firmaId: string
  deletedAt: Date
  reason?: string
  invoiceNo?: string
  faturaNo?: string
  billOfLading?: string
  bl?: string
  blNo?: string
  konsimento?: string
}

interface RecycleBinTableProps {
  deletedShipments: DeletedShipment[]
  companies: Company[]
  onRestore: (id: string) => void
  onPermanentDelete: (id: string) => void
}

export function RecycleBinTable({ deletedShipments, companies, onRestore, onPermanentDelete }: RecycleBinTableProps) {
  if (deletedShipments.length === 0) {
    return (
      <Card className="p-6 sm:p-8 flex items-center justify-center min-h-[200px]">
        <p className="text-muted-foreground text-sm opacity-60">No records yet</p>
      </Card>
    )
  }

  const getCompanyName = (companyId: string) => {
    return companies.find((c) => c.id === companyId)?.name || "Unknown"
  }

  return (
    <>
      <div className="hidden md:block overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b">
              <th className="text-left py-3 px-4 font-semibold text-sm">Supplier</th>
              <th className="text-left py-3 px-4 font-semibold text-sm">Invoice No • BL No</th>
              <th className="text-left py-3 px-4 font-semibold text-sm">Company</th>
              <th className="text-left py-3 px-4 font-semibold text-sm">Deleted At</th>
              <th className="text-left py-3 px-4 font-semibold text-sm">Reason</th>
              <th className="text-right py-3 px-4 font-semibold text-sm">Actions</th>
            </tr>
          </thead>
          <tbody>
            {deletedShipments.map((shipment) => (
              <tr key={shipment.id} className="border-b hover:bg-muted/50">
                <td className="py-3 px-4 text-sm">{shipment.tedarikçi}</td>
                <td className="py-3 px-4 text-sm">{displayInvoiceBL(shipment)}</td>
                <td className="py-3 px-4 text-sm">{getCompanyName(shipment.firmaId)}</td>
                <td className="py-3 px-4 text-sm">{new Date(shipment.deletedAt).toLocaleDateString("tr-TR")}</td>
                <td className="py-3 px-4 text-sm text-muted-foreground">{shipment.reason || "-"}</td>
                <td className="py-3 px-4 text-right">
                  <div className="flex gap-2 justify-end">
                    <Button size="sm" variant="outline" onClick={() => onRestore(shipment.id)}>
                      Restore
                    </Button>
                    <Button size="sm" variant="destructive" onClick={() => onPermanentDelete(shipment.id)}>
                      Delete Forever
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="md:hidden space-y-3">
        {deletedShipments.map((shipment) => (
          <Card key={shipment.id} className="p-4">
            <div className="space-y-2">
              <div className="flex justify-between items-start gap-2">
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm truncate">{shipment.tedarikçi}</p>
                  <p className="text-xs text-muted-foreground truncate">{displayInvoiceBL(shipment)}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <p className="text-muted-foreground">Company</p>
                  <p className="font-medium truncate">{getCompanyName(shipment.firmaId)}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Deleted At</p>
                  <p className="font-medium">{new Date(shipment.deletedAt).toLocaleDateString("tr-TR")}</p>
                </div>
                {shipment.reason && (
                  <div className="col-span-2">
                    <p className="text-muted-foreground">Reason</p>
                    <p className="font-medium">{shipment.reason}</p>
                  </div>
                )}
              </div>

              <div className="flex gap-2 pt-2">
                <Button size="sm" variant="outline" onClick={() => onRestore(shipment.id)} className="flex-1 text-xs">
                  Restore
                </Button>
                <Button
                  size="sm"
                  variant="destructive"
                  onClick={() => onPermanentDelete(shipment.id)}
                  className="flex-1 text-xs"
                >
                  Delete Forever
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </>
  )
}
