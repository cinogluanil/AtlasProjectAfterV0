"use client"

import type { Shipment, Company } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { ChevronDown } from "lucide-react"
import { useState, useRef, useEffect } from "react"
import { toCanonStatus } from "@/lib/store"
import { displayInvoiceBL } from "@/lib/display"

interface ShipmentsTableProps {
  shipments: Shipment[]
  companies: Company[]
  onEdit: (shipment: Shipment) => void
  onDelete: (id: string) => void
  onViewDocuments: (shipment: Shipment) => void
  selectedIds?: string[]
  onSelectionChange?: (ids: string[]) => void
  onStatusChange?: (shipmentId: string, newStatus: Shipment["status"]) => void
}

const STATUS_LABELS: Record<string, string> = {
  toLoad: "To Load",
  onTheWay: "On the Way",
  arrived: "Arrived",
  completed: "Import Completed",
}

const STATUS_COLORS: Record<string, string> = {
  toLoad: "bg-blue-100 text-blue-800",
  onTheWay: "bg-amber-100 text-amber-800",
  arrived: "bg-green-100 text-green-800",
  completed: "bg-green-100 text-green-800",
}

const nextStatus: Record<string, string | null> = {
  toLoad: "onTheWay",
  onTheWay: "arrived",
  arrived: "completed",
  completed: null,
}

function StatusDropdown({
  currentStatus,
  onStatusChange,
}: {
  currentStatus: Shipment["status"]
  onStatusChange: (status: Shipment["status"]) => void
}) {
  const [isOpen, setIsOpen] = useState(false)
  const [position, setPosition] = useState({ top: 0, left: 0 })
  const buttonRef = useRef<HTMLButtonElement>(null)

  const allStatuses: string[] = ["toLoad", "onTheWay", "arrived", "completed"]

  useEffect(() => {
    if (isOpen && buttonRef.current) {
      const rect = buttonRef.current.getBoundingClientRect()
      setPosition({
        top: rect.bottom + 4,
        left: rect.left,
      })
    }
  }, [isOpen])

  const normalizedStatus = toCanonStatus(currentStatus)
  const displayLabel = STATUS_LABELS[normalizedStatus] || normalizedStatus
  const displayColor = STATUS_COLORS[normalizedStatus] || "bg-gray-100 text-gray-800"

  return (
    <div className="relative">
      <button
        ref={buttonRef}
        onClick={() => setIsOpen(!isOpen)}
        className={`flex items-center gap-1 px-2 py-1 rounded text-xs font-semibold ${displayColor} hover:opacity-80 transition-opacity min-w-[140px] text-center justify-center`}
      >
        {displayLabel}
        <ChevronDown className="h-3 w-3" />
      </button>

      {isOpen && (
        <>
          <div className="fixed inset-0 z-[9999]" onClick={() => setIsOpen(false)} />
          <div
            className="fixed z-[10000] min-w-[160px]"
            style={{
              top: `${position.top}px`,
              left: `${position.left}px`,
            }}
          >
            <Card className="p-1 shadow-lg bg-popover border">
              {allStatuses.map((status) => (
                <button
                  key={status}
                  onClick={() => {
                    onStatusChange(status as Shipment["status"])
                    setIsOpen(false)
                  }}
                  className={`w-full text-center px-3 py-2 rounded text-xs font-semibold hover:bg-muted transition-colors ${
                    status === normalizedStatus ? STATUS_COLORS[status] : "text-foreground"
                  }`}
                >
                  {STATUS_LABELS[status]}
                </button>
              ))}
            </Card>
          </div>
        </>
      )}
    </div>
  )
}

export function ShipmentsTable({
  shipments,
  companies,
  onEdit,
  onDelete,
  onViewDocuments,
  selectedIds = [],
  onSelectionChange,
  onStatusChange,
}: ShipmentsTableProps) {
  if (shipments.length === 0) {
    return (
      <Card className="p-6 sm:p-8 flex items-center justify-center min-h-[200px]">
        <p className="text-muted-foreground text-sm opacity-60">No records yet</p>
      </Card>
    )
  }

  const getCompanyName = (companyId: string) => {
    return companies.find((c) => c.id === companyId)?.name || "Unknown"
  }

  const handleSelectAll = (checked: boolean) => {
    if (!onSelectionChange) return
    if (checked) {
      onSelectionChange(shipments.map((s) => s.id))
    } else {
      onSelectionChange([])
    }
  }

  const handleSelectOne = (id: string, checked: boolean) => {
    if (!onSelectionChange) return
    if (checked) {
      onSelectionChange([...selectedIds, id])
    } else {
      onSelectionChange(selectedIds.filter((sid) => sid !== id))
    }
  }

  const handleNextStatus = (shipment: Shipment) => {
    if (!onStatusChange) return
    const next = nextStatus[shipment.status]
    if (next) {
      onStatusChange(shipment.id, next)
    }
  }

  const allSelected = shipments.length > 0 && selectedIds.length === shipments.length
  const someSelected = selectedIds.length > 0 && selectedIds.length < shipments.length

  // Helper function to calculate days remaining until ETA
  const getETABadge = (shipment: Shipment) => {
    // Only show for in-transit shipments
    if (shipment.status !== "onTheWay") return null

    const eta = (shipment as any).estimatedArrival || shipment.estimatedArrivalDate || (shipment as any).eta

    if (!eta) {
      return (
        <Badge variant="secondary" className="ml-2 text-xs">
          N/A
        </Badge>
      )
    }

    // Validate date
    const etaDate = new Date(eta)
    if (isNaN(etaDate.getTime())) {
      return (
        <Badge variant="secondary" className="ml-2 text-xs">
          N/A
        </Badge>
      )
    }

    // Calculate days remaining (ceiling to include partial days)
    const daysLeft = Math.ceil((etaDate.setHours(23, 59, 59, 999) - Date.now()) / (1000 * 60 * 60 * 24))

    console.log("[v0] ETA_BADGE", shipment.id, { eta, daysLeft, status: shipment.status })

    // Render badge based on days remaining
    if (daysLeft === 0) {
      // Today - show "Today" in neutral
      return (
        <Badge variant="secondary" className="ml-2 text-xs">
          Today
        </Badge>
      )
    } else if (daysLeft < 0) {
      // Overdue - show "X Days Late" in red
      const daysLate = Math.abs(daysLeft)
      return (
        <Badge variant="destructive" className="ml-2 text-xs">
          {daysLate} {daysLate === 1 ? "Day" : "Days"} Late
        </Badge>
      )
    } else if (daysLeft < 7) {
      // Less than 7 days - show "X Days Left" in red
      return (
        <Badge variant="destructive" className="ml-2 text-xs">
          {daysLeft} {daysLeft === 1 ? "Day" : "Days"} Left
        </Badge>
      )
    } else {
      // 7+ days - show "X Days Left" in neutral
      return (
        <Badge variant="secondary" className="ml-2 text-xs">
          {daysLeft} {daysLeft === 1 ? "Day" : "Days"} Left
        </Badge>
      )
    }
  }

  const handleStatusChange = (shipmentId: string, newStatus: Shipment["status"]) => {
    if (!onStatusChange) return

    const shipment = shipments.find((s) => s.id === shipmentId)
    const beforeStatus = shipment?.status
    const normalizedStatus = toCanonStatus(newStatus)

    console.log("[v0] STATUS_UPDATE", {
      shipmentId,
      before: beforeStatus,
      after: normalizedStatus,
      isTransitSale: (shipment as any)?.isTransitSale,
    })

    onStatusChange(shipmentId, normalizedStatus as Shipment["status"])
  }

  return (
    <>
      <div className="hidden md:block overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b">
              {onSelectionChange && (
                <th className="text-left py-3 px-4 w-12">
                  <Checkbox
                    checked={allSelected}
                    onCheckedChange={handleSelectAll}
                    aria-label="Select all"
                    className={someSelected ? "data-[state=checked]:bg-primary/50" : ""}
                  />
                </th>
              )}
              <th className="text-left py-3 px-4 font-semibold text-sm">Supplier</th>
              <th className="text-left py-3 px-4 font-semibold text-sm">Invoice No • BL No</th>
              <th className="text-left py-3 px-4 font-semibold text-sm">Origin Country</th>
              <th className="text-left py-3 px-4 font-semibold text-sm">Company</th>
              <th className="text-left py-3 px-4 font-semibold text-sm">Status</th>
              <th className="text-left py-3 px-4 font-semibold text-sm">Estimated Loading</th>
              <th className="text-right py-3 px-4 font-semibold text-sm">Actions</th>
            </tr>
          </thead>
          <tbody>
            {shipments.map((shipment) => {
              const normalizedStatus = toCanonStatus(shipment.status)

              return (
                <tr key={shipment.id} className="border-b hover:bg-muted/50">
                  {onSelectionChange && (
                    <td className="py-3 px-4">
                      <Checkbox
                        checked={selectedIds.includes(shipment.id)}
                        onCheckedChange={(checked) => handleSelectOne(shipment.id, checked as boolean)}
                        aria-label={`${shipment.product} select`}
                      />
                    </td>
                  )}
                  <td className="py-3 px-4 text-sm">{shipment.tedarikçi}</td>
                  <td className="py-3 px-4 text-sm">{displayInvoiceBL(shipment)}</td>
                  <td className="py-3 px-4 text-sm">{shipment.originCountry}</td>
                  <td className="py-3 px-4 text-sm">{getCompanyName(shipment.firmaId)}</td>
                  <td className="py-3 px-4">
                    {onStatusChange ? (
                      <StatusDropdown
                        currentStatus={normalizedStatus}
                        onStatusChange={(newStatus) => handleStatusChange(shipment.id, newStatus)}
                      />
                    ) : (
                      <span
                        className={`px-2 py-1 rounded text-xs font-semibold ${
                          STATUS_COLORS[normalizedStatus] || "bg-gray-100 text-gray-800"
                        }`}
                      >
                        {STATUS_LABELS[normalizedStatus] || normalizedStatus}
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-sm">
                    <div className="flex items-center">
                      {new Date(shipment.estimatedLoading).toLocaleDateString("tr-TR")}
                      {getETABadge(shipment)}
                    </div>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex gap-2 justify-end">
                      <Button size="sm" variant="outline" onClick={() => onViewDocuments(shipment)}>
                        Documents
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => onEdit(shipment)}>
                        Edit
                      </Button>
                      <Button size="sm" variant="destructive" onClick={() => onDelete(shipment.id)}>
                        Delete
                      </Button>
                    </div>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      <div className="md:hidden space-y-3">
        {shipments.map((shipment) => {
          const normalizedStatus = toCanonStatus(shipment.status)

          return (
            <Card key={shipment.id} className="p-4">
              <div className="space-y-2">
                <div className="flex justify-between items-start gap-2">
                  <div className="flex items-start gap-2 flex-1 min-w-0">
                    {onSelectionChange && (
                      <Checkbox
                        checked={selectedIds.includes(shipment.id)}
                        onCheckedChange={(checked) => handleSelectOne(shipment.id, checked as boolean)}
                        aria-label={`${shipment.product} select`}
                        className="mt-1"
                      />
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm truncate">{shipment.tedarikçi}</p>
                      <p className="text-xs text-muted-foreground truncate">{displayInvoiceBL(shipment)}</p>
                    </div>
                  </div>
                  {onStatusChange ? (
                    <StatusDropdown
                      currentStatus={normalizedStatus}
                      onStatusChange={(newStatus) => handleStatusChange(shipment.id, newStatus)}
                    />
                  ) : (
                    <span
                      className={`px-2 py-1 rounded text-xs font-semibold whitespace-nowrap ${
                        STATUS_COLORS[normalizedStatus] || "bg-gray-100 text-gray-800"
                      }`}
                    >
                      {STATUS_LABELS[normalizedStatus] || normalizedStatus}
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <p className="text-muted-foreground">Origin</p>
                    <p className="font-medium">{shipment.originCountry}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Company</p>
                    <p className="font-medium truncate">{getCompanyName(shipment.firmaId)}</p>
                  </div>
                  <div className="col-span-2">
                    <p className="text-muted-foreground">Estimated Loading</p>
                    <div className="flex items-center">
                      <p className="font-medium">{new Date(shipment.estimatedLoading).toLocaleDateString("tr-TR")}</p>
                      {getETABadge(shipment)}
                    </div>
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => onViewDocuments(shipment)}
                    className="flex-1 text-xs"
                  >
                    Documents
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => onEdit(shipment)} className="flex-1 text-xs">
                    Edit
                  </Button>
                  <Button size="sm" variant="destructive" onClick={() => onDelete(shipment.id)} className="text-xs">
                    Delete
                  </Button>
                </div>
              </div>
            </Card>
          )
        })}
      </div>
    </>
  )
}
