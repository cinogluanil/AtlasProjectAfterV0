"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import type { ShippingLine } from "@/lib/types"

interface ShippingLinesTableProps {
  shippingLines: ShippingLine[]
  shipmentCounts: Record<string, number>
  onEdit: (line: ShippingLine) => void
  onDelete: (id: string) => void
}

function norm(s: string | undefined | null): string {
  return (s || "").toString().trim().toLowerCase().replace(/\s+/g, " ")
}

export function ShippingLinesTable({ shippingLines, shipmentCounts, onEdit, onDelete }: ShippingLinesTableProps) {
  const sortedLines = [...shippingLines].sort((a, b) => {
    const countA = shipmentCounts[norm(a.name)] || 0
    const countB = shipmentCounts[norm(b.name)] || 0
    return countB - countA
  })

  if (sortedLines.length === 0) {
    return (
      <Card className="p-4 sm:p-6">
        <p className="text-muted-foreground text-center py-8">No shipping lines added yet</p>
      </Card>
    )
  }

  return (
    <Card className="p-4 sm:p-6">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b">
              <th className="text-left p-3 font-medium">Shipping Line</th>
              <th className="text-left p-3 font-medium">Code</th>
              <th className="text-left p-3 font-medium">Shipment Count</th>
              <th className="text-right p-3 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {sortedLines.map((line) => {
              const count = shipmentCounts[norm(line.name)] || 0
              return (
                <tr key={line.id} className="border-b last:border-0 hover:bg-muted/50">
                  <td className="p-3">
                    <div>
                      <p className="font-medium">{line.name}</p>
                      {line.website && (
                        <a
                          href={line.website}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-sm text-blue-600 hover:underline"
                        >
                          {line.website}
                        </a>
                      )}
                    </div>
                  </td>
                  <td className="p-3 text-sm text-muted-foreground">{line.code || "-"}</td>
                  <td className="p-3">
                    <span className="inline-flex items-center justify-center min-w-[2rem] px-2 py-1 text-sm font-medium bg-blue-100 text-blue-800 rounded-full">
                      {count}
                    </span>
                  </td>
                  <td className="p-3">
                    <div className="flex gap-2 justify-end">
                      <Button variant="outline" size="sm" onClick={() => onEdit(line)}>
                        Edit
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => onDelete(line.id)}>
                        Delete
                      </Button>
                    </div>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </Card>
  )
}
